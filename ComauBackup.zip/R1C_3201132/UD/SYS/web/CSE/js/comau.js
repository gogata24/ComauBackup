﻿var emoi_data = null;
var emoi_changed = false;
var sys_state = 0;					//OK
var sl_state = 0;					//OK
var stroke_end = null;
var sys_name = null;				//OK
var arm_mask = null;
var arm_safe_mask = null;
var ack_status = null;
var Buffer_APC_SL = null;			//OK



var INDEX_AX7 = 7;				// Asse 7

var SAFE_NO_EXEC = 0xF0;
var SAFE_LOGIC_RUN = 0x66;


var SAFE_TURN_SET_BIT = 92;

var ACK_OFF_MESSAGE = "Reload software CSE";
var ACK_RUN_MESSAGE = "No action needed";

var btn_sel = '#f0E68C';
var btn_rel = '#f2f2f2';
var btn_sel_w = '#CC0000';
var btn_rel_w = '#4D4D4D';

var emoi_in_progress = false;
var emoi_completed = false;
var ack_in_progress = false;
var turn_set_in_progress = false;
var turn_set_req_in_progress = false;
var emoi_stm_changed = false;
var restore_in_progress = false;

var emoi_user_confirm = false;

var reset_mask_TS;
var reset_connect;
var reset_connect_pres = null;

var bit_comm_text = null;


//*****************************************************************************
//    Show Communication Buffer Value between APC and SL (CSE)
//*****************************************************************************

function showCommBufValue()
{	

		var html = '<table id="info_table"><th colspan=3 > Display buffer communication SL-APC </th>';
		html += '<tr id="info_table_title"><td colspan=3><b>CSE Command (Controller output - SL input)</b></td></tr>';
		html += '<tr id="info_table_title"><td width="10%"><i>bit</i></td><td width="70%"><i>signal</i></td><td width="20%"><i>status</i></td></tr>';
		
		for (var j=0;j<8;j++)
		{
			html += '<tr id="info_table_tr"><td>' + (j+1) + '</td><td>' + bit_comm_text.bits[j] + '</td><td>' + /*checkBitComm(j)*/ 't.b.d.' + '</td></tr>';
		}
		
		//html += '<tr  id="info_table_tr"><td colspan=3>&nbsp</td></tr>';
		html += '<tr id="info_table_title"><td colspan=3><b>CSE Status (Controller input - SL output)</b></td></tr>';
		html += '<tr id="info_table_title"><td width="10%"><i>bit</i></td><td width="70%"><i>signal</i></td><td width="20%"><i>status</i></td></tr>';
		
		for (var x=0;x<32;x++)
		{
			html += '<tr id="info_table_tr"><td>' + (x+1) + '</td><td>' + bit_comm_text.bits[j+x] + '</td><td>' + checkBitComm(x) + '</td></tr>';
		}
		
	return html;
}

//*****************************************************************************
//    Check Status of Communication Bit from SL to APC and viceversa
//*****************************************************************************

function checkBitComm(bit_num)
{
	
	if(Buffer_APC_SL == null)
	{
		return status_bit = 'Wait...';
	}
	else
	{
		if(Buffer_APC_SL[bit_num] == 1)
		{
			return status_bit = 'ON';
		}
		else
		{
			return status_bit = 'OFF';
		}
	}

}

/*****************************************************************************/


function show_time()
{
	var monthNames = [ "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" ]; 
	var dayNames= ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"]

	var newDate = new Date();

	newDate.setDate(newDate.getDate());
	
	$('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

	setInterval( function() {
		// Create a newDate() object and extract the seconds of the current time on the visitor's
		var seconds = new Date().getSeconds();
		// Add a leading zero to seconds value
		$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
	},1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the minutes of the current time on the visitor's
		var minutes = new Date().getMinutes();
		// Add a leading zero to the minutes value
		$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
    },1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the hours of the current time on the visitor's
		var hours = new Date().getHours();
		// Add a leading zero to the hours value
		$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
    }, 1000);	           
}

function actionNeeded(action)
{
  $('#ack_message').html(action);
}

function getAcknowledgeStatus()
{
	if (ack_in_progress || emoi_in_progress || turn_set_req_in_progress || restore_in_progress)
		return;
		
	$.ajax(
	{
		url: 'run?ack=0',
		cache: false,
		success: function(data) {
			ack_status = $.parseJSON(data);

			if (ack_status.safeOsState == 0)
			{
				actionNeeded(' Please Reload software CSE ');
				/*$('#ack_down_li').css('background-color', '#ffff00');
				$('#ack_skey_li').css('background-color', '#eee');
				$('#ack_mod1_li').css('background-color', '#eee');
				$('#ack_mod2_li').css('background-color', '#eee');
				$('#ack_mod3_btn').css('background-color', '#eee');
				$('#ack_mod4_btn').css('background-color', '#eee');
				$('#ack_modn_btn').css('background-color', '#eee');
				$('#ack_firm_li').css('background-color', '#eee');*/
				if(document.URL.indexOf('pages/serviceTP') != -1){
					$('#download_prj_btn_TP').css('background-color', '#ffff00');
				}
				else{
					$('#ack_down_btn').css('background-color', '#ffff00');
				}
				$('#ack_skey_btn').css('background-color', '#eee');
				$('#ack_mod1_btn').css('background-color', '#eee');
				$('#ack_mod2_btn').css('background-color', '#eee');
				$('#ack_mod3_btn').css('background-color', '#eee');
				$('#ack_mod4_btn').css('background-color', '#eee');
				$('#ack_modn_btn').css('background-color', '#eee');
				$('#ack_firm_btn').css('background-color', '#eee');
			}
			else
			{
				if(document.URL.indexOf('pages/serviceTP') != -1){
					$('#download_prj_btn_TP').css('background-color', '#eee');
				}
				else{
					$('#ack_down_btn').css('background-color', '#eee');
				}
				//$('#ack_down_li').css('background-color', '#eee');

				if (ack_status.safeKeyChanged)
				{
					actionNeeded('Please acknowledge Safe-Key change');
					/*$('#ack_skey_li').css('background-color', '#ffff00');
					$('#ack_mod1_li').css('background-color', '#eee');
					$('#ack_mod2_li').css('background-color', '#eee');
					$('#ack_mod3_btn').css('background-color', '#eee');
					$('#ack_mod4_btn').css('background-color', '#eee');
					$('#ack_modn_btn').css('background-color', '#eee');
					$('#ack_firm_li').css('background-color', '#eee');*/
					
					$('#ack_skey_btn').css('background-color', '#ffff00');
					$('#ack_mod1_btn').css('background-color', '#eee');
					$('#ack_mod2_btn').css('background-color', '#eee');
					$('#ack_mod3_btn').css('background-color', '#eee');
					$('#ack_mod4_btn').css('background-color', '#eee');
					$('#ack_modn_btn').css('background-color', '#eee');
					$('#ack_firm_btn').css('background-color', '#eee');
				}
				else
				{
					//$('#ack_skey_li').css('background-color', '#eee');
					$('#ack_skey_btn').css('background-color', '#eee');

					if (ack_status.moduleMismatch > 0)
					{
						//$('#ack_firm_li').css('background-color', '#eee');
						$('#ack_firm_btn').css('background-color', '#eee');
						if (ack_status.moduleMismatch == 1)
						{
							actionNeeded('Please acknowledge 1 new module');
							$('#ack_mod1_btn').css('background-color', '#ffff00');							
							$('#ack_mod2_btn').css('background-color', '#eee');
							$('#ack_mod3_btn').css('background-color', '#eee');
							$('#ack_mod4_btn').css('background-color', '#eee');
							$('#ack_modn_btn').css('background-color', '#eee');
						}
						else if (ack_status.moduleMismatch == 2)
						{
							actionNeeded('Please acknowledge 2 new modules');							
							$('#ack_mod1_btn').css('background-color', '#eee');						
							$('#ack_mod2_btn').css('background-color', '#ffff00');
							$('#ack_mod3_btn').css('background-color', '#eee');
							$('#ack_mod4_btn').css('background-color', '#eee');
							$('#ack_modn_btn').css('background-color', '#eee');
						}
						else if (ack_status.moduleMismatch == 3)
						{
							actionNeeded('Please acknowledge 3 new modules');
							$('#ack_mod1_btn').css('background-color', '#eee');
							$('#ack_mod2_btn').css('background-color', '#eee');
							$('#ack_mod3_btn').css('background-color', '#ffff00');
							$('#ack_mod4_btn').css('background-color', '#eee');
							$('#ack_modn_btn').css('background-color', '#eee');							
						}
						else if (ack_status.moduleMismatch == 4)
						{
							actionNeeded('Please acknowledge 4 new modules');
							$('#ack_mod1_btn').css('background-color', '#eee');
							$('#ack_mod2_btn').css('background-color', '#eee');
							$('#ack_mod3_btn').css('background-color', '#eee');
							$('#ack_mod4_btn').css('background-color', '#ffff00');
							$('#ack_modn_btn').css('background-color', '#eee');							
						}
						else
						{
							actionNeeded('Please acknowledge N new modules');
							$('#ack_mod1_btn').css('background-color', '#eee');
							$('#ack_mod2_btn').css('background-color', '#eee');
							$('#ack_mod3_btn').css('background-color', '#eee');
							$('#ack_mod4_btn').css('background-color', '#eee');
							$('#ack_modn_btn').css('background-color', '#ffff00');
						}
					}
					else
					{
						$('#ack_mod1_btn').css('background-color', '#eee');
						$('#ack_mod2_btn').css('background-color', '#eee');
						$('#ack_mod3_btn').css('background-color', '#eee');
						$('#ack_mod4_btn').css('background-color', '#eee');
						$('#ack_modn_btn').css('background-color', '#eee');

						if (ack_status.firmwareMismatch > 0)
						{                
							actionNeeded('Please acknowledge firmware');
							$('#ack_firm_btn').css('background-color', '#ffff00');
						}
						else
						{
							$('#ack_firm_btn').css('background-color', '#eee');
							if(sl_state != 0x66)
							{
								actionNeeded('Please wait');
								reset_mask_TS = 0;
							}
							else
							{
								actionNeeded('No action needed');
							}
						}
					}
				}			
			}
		}
	});
}


function getSafeLogicState()
{
	$.ajax(
	{
	    url: 'get?sl_state', 
	    cache: false,	    
	    success: function(data)
	    {        
	    	var sts = $.parseJSON(data);
	    	var text = "";
	    	var img = "led_off.png";
	    		
			
			if(sts.sl_state == -1)
			{
				//SL not declared
				text = "SL NOT DECLARED";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					//actionNeeded('Safe Logic device non present into Comau devices declaration');
					$('#no_sl_pres_TP').overlay().load();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().load();
					$('#no_sl_conn').overlay().close();
				}
			}
	    	else if (sts.sl_state == 0)
	    	{
	    		text = "OFF";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}	
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	else if (sts.sl_state == 0x33)
	    	{
	    		text = "BOOT";
	    		img = "led_yellow.png";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	else if (sts.sl_state == 0x55)
	    	{
	    		text = "STOP";
	    		img = "led_red.png";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else				
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	else if (sts.sl_state == 0x66)
	    	{
	    		text = "RUN";
				img = "led_green.png";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}	
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}	
	    	}
	    	else if (sts.sl_state == 0xAA)
	    	{
	    		text = "STOP (D)";
	    		img = "led_yellow.png";	   
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	else if (sts.sl_state == 0xCC)
	    	{
	    		text = "RUN (D)";
	    		img = "led_yellow.png";
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	else if (sts.sl_state == 0xF0)
	    	{
	    		text = "NO EXEC";
	    		img = "led_yellow.png";	
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
			else if (sts.sl_state == 0xFF)
	    	{
				//not connected to PowerLink network
	    		text = "SL NOT CONNECTED";	
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					//actionNeeded('Safe Logic device not present over PowerLink network');
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().load();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().load();
				}
	    	}
	    	else
	    	{
	    	 	text = sts.sl_state.toString(16);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#no_sl_pres_TP').overlay().close();
					$('#no_sl_conn_TP').overlay().close();
				}
				else
				{
					$('#no_sl_pres').overlay().close();
					$('#no_sl_conn').overlay().close();
				}
	    	}
	    	
			
	    	if (sts.sl_state != sl_state)
	    	{
	    		$('#safe_led').attr('src', '../images/' + img);
	    		$('#safe_led_small').attr('src', '../images/' + img);

	    		// salvo
	    		sl_state = sts.sl_state;	    	      			    	      		
	      	}

	      	// salvo
	      	sys_state = sts.sys_state;
			
			// resetto connessione
			conn_rest();
	    },
		error: function()
		{
			conn_lost();
		}
	});  
}

function getbufferSL()
{
	$.ajax(
	{
	    url: 'get?safe_in_aboo', 
	    cache: false,	    
	    success: function(data)
	    {      
	    	Buffer_APC_SL = $.parseJSON(data);
			$('#info_div').html(showCommBufValue());
	    }
	});  
}

function getAppList()
{
        $.getJSON('get?app_list', function(data)
        {
		var appList = JSON.parse(JSON.stringify(data));
   
                $.each(appList, function(index, value)
                {
                	$("#leftContent ul").append('<li><a href="' + value.home + '/index.html">' + value.name + '</a></li>');			
                });
                
	});
}

function conn_rest()
{
	reset_connect = 0;
	if(reset_connect_pres != 0)
	{
		reset_connect_pres = 0;
		if(document.URL.indexOf('pages/serviceTP') != -1)
		{
			$('#no_connect_TP').overlay().close();
		}
		else
		{
			$('#no_connect').overlay().close();
		}
	}
}
		
function conn_lost()
{
	if(reset_connect > 3)
	{
		if(reset_connect_pres == 0)	
		{
			reset_connect_pres = 1;
			
			if(document.URL.indexOf('pages/serviceTP') != -1)
			{
				$('#no_connect_TP').overlay().load();
			}
			else
			{
				$('#no_connect').overlay().load();
			}
		}
	}
	else
	{
		reset_connect++;
	}
}

function formatKey()
{
	$.ajax({
		type: "POST",
		url: 'run?format_key',						

		success: function(data) {
			changeSafePwd();
		}
	});
}

function changeSafePwd()
{
	$.ajax({
		type: "POST",
		url: 'run?change_passw',

		success: function(data) {
			ack_in_progress = false;
			if(document.URL.indexOf('pages/serviceTP') != -1)
			{
				$('#wait_TP').overlay().close();
			}
			else{
				$('#wait').overlay().close();
			}
		}
	});
}

function downloadSafePrj()
{
	$.ajax({
		type: "POST",
		url: 'run?download_code',

		success: function(data) {
			ack_in_progress = false;
			if(document.URL.indexOf('pages/serviceTP') != -1)
			{
				$('#wait_TP').overlay().close();
			}
			else{
				$('#wait').overlay().close();
			}
		},

		error: function(data) {
			ack_in_progress = false;
			if(document.URL.indexOf('pages/serviceTP') != -1)
			{
				$('#wait_TP').overlay().close();
			}
			else{
				$('#wait').overlay().close();
			}
			alert('Reload software CSE procedure failed');
		}
	});
}

function acknowledgeSafe(set)
{
	$.ajax({
		type: "POST",
		url: 'run?ack=' + set,

		success: function(data) {
			ack_in_progress = false;
			if(document.URL.indexOf('pages/serviceTP') != -1)
			{
				$('#wait_TP').overlay().close();
			}
			else{
				$('#wait').overlay().close();
			}
		}
	});
}


//+++++++++++++++++ IE identification +++++++++++++++++++++++++++
//Identification of web browser
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

function IE_ident()
{
	if (navigator.appName == "Microsoft Internet Explorer")
	{	
		return true;
	}
	else
	{
		return false;
	}
}


function sl_run_ok()
{
	if(sl_state != 0x66)
	{
		alert('Please first complete all of the steps highlighted into the page');
		return false;
	}
	return true;
	//RIUTILIZZARE PER CONDIZIONARE LA VISUALIZZAZIONE DELLA PAGINA INFO
}



// when the DOM is ready...
$(document).ready(function () {

	show_time();

	// menu di navigazione principale
	$('#m_home').click(function() {	
		location.assign('../../index.html');
	});
	
	$('#m_cse').click(function() {
		location.assign('home.html');
	});		

	// pagina safe
	if (document.URL.indexOf('CSE') != -1)
	{
		
		// attivo la lettura dello stato della safe logic
		setInterval(getSafeLogicState, 2000);

		// carico le informazioni di sistema
		$.getJSON('get?home_info', function(data)
		{
			sys_name = data;			
			sessionStorage.setItem('sys_name', JSON.stringify(sys_name));
			$('#bloc1').html(sys_name[0][0] + ": " + sys_name[0][1]);
			
		});
		
/*
		            ##       ##     ##  #######  ##     ## ######## 
		             ##      ##     ## ##     ## ###   ### ##       
		              ##     ##     ## ##     ## #### #### ##       
		    #######    ##    ######### ##     ## ## ### ## ######   
		              ##     ##     ## ##     ## ##     ## ##       
		             ##      ##     ## ##     ## ##     ## ##       
		            ##       ##     ##  #######  ##     ## ######## 
 */

		// verifico se è stata caricata la pagina home
		if (document.URL.indexOf('pages/home') != -1)
		{			

			if(IE_ident())
			{
				location.href = "IE_identif.html";
			}
			else
			{

				$.getJSON('bit_comm.json', function(data) {
					bit_comm_text = data;
					sessionStorage.setItem('bit_comm_text', JSON.stringify(bit_comm_text));
				}); 
			
				$('#no_connect').overlay(
				{
					top: 250,
	
					onBeforeLoad: function () {
					
					},
				
					onClose: function () {
						
					},
					
					mask: {
						color: '#ebecff',
						loadSpeed: 200,
						opacity: 0.5
					},
	
					closeOnClick: false
				});
				
				$('#no_sl_pres').overlay(
				{
	
					top: 250,
	
					onBeforeLoad: function () {
					
					},
				
					onClose: function () {
						
					},
					
					mask: {
						color: '#ebecff',
						loadSpeed: 200,
						opacity: 0.5
					},
	
					closeOnClick: false
				});
				
				$('#no_sl_conn').overlay(
				{
	
					top: 250,
	
					onBeforeLoad: function () {
					
					},
				
					onClose: function () {
						
					},
					
					mask: {
						color: '#ebecff',
						loadSpeed: 200,
						opacity: 0.5
					},
	
					closeOnClick: false
				});
				
			}
		} // cse > home

/*
		            ##        ######  ######## ########  ##     ## ####  ######  ######## 
		             ##      ##    ## ##       ##     ## ##     ##  ##  ##    ## ##       
		              ##     ##       ##       ##     ## ##     ##  ##  ##       ##       
		    #######    ##     ######  ######   ########  ##     ##  ##  ##       ######   
		              ##           ## ##       ##   ##    ##   ##   ##  ##       ##       
		             ##      ##    ## ##       ##    ##    ## ##    ##  ##    ## ##       
		            ##        ######  ######## ##     ##    ###    ####  ######  ########
*/

		if (document.URL.indexOf('pages/service') != -1)
		{
			setInterval(getAcknowledgeStatus, 2000);		
			
			bit_comm_text = JSON.parse(sessionStorage.getItem('bit_comm_text'));
			
			
		

			$('#ack_skey_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(7);				
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Safe-Key acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Safe-Key acknowledge in progress...');
				}
				
			});			

			$('#ack_mod1_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(1);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Modules acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Modules acknowledge in progress...');
				}
			});			

			$('#ack_mod2_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(2);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Modules acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Modules acknowledge in progress...');
				}
			});			

			$('#ack_mod3_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(3);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Modules acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Modules acknowledge in progress...');
				}
			});			

			$('#ack_mod4_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(4);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Modules acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Modules acknowledge in progress...');
				}
			});			

			$('#ack_modn_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(5);
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Modules acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Modules acknowledge in progress...');
				}
			});			

			$('#ack_firm_btn').click(function() {
				ack_in_progress = true;
				acknowledgeSafe(6);				
				
				if(document.URL.indexOf('pages/serviceTP') != -1)
				{
					$('#wait_TP').overlay().load();
					$('#wait_message_TP').text('Firmware acknowledge in progress...');
				}
				else{
					$('#wait').overlay().load();
					$('#wait_message').text('Firmware acknowledge in progress...');
				}
			});			
				
				
			$('#ack_format_btn').click(function() {
				$('#format_key_dlg').overlay().load();
			});			

			$('#ack_down_btn').click(function() {
				$('#download_prj_dlg').overlay().load();					
			});				
			
			$('#format_key_btn_TP').click(function() {
				$('#format_key_dlg_TP').overlay().load();
			});
			
			$('#download_prj_btn_TP').click(function() {
				$('#download_prj_dlg_TP').overlay().load();
			});			
				
				
			$('#format_key_dlg').overlay({

				top: 250,			

				onBeforeLoad: function () {

					$('#format_key_q').html('Are you sure you want to format Safe-Key?');
				},

				onClose: function () {

					if (ack_in_progress)
					{
						setTimeout(function() {
							$('#wait').overlay().load();
							$('#wait_message').text('Safe-Key format in progress...');
						}, 100);
					}
				},

				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},

				closeOnClick: false
			});

			$("#format_key_dlg form").submit(function(e) {
							
				ack_in_progress = true;
				formatKey();

				$('#format_key_dlg').overlay().close()
					
				return e.preventDefault();
			});
			
			/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
			
			$('#format_key_dlg_TP').overlay({

				top: 125,
				left: 200,

				onBeforeLoad: function () {

					$('#format_key_q_TP').html('Are you sure you want to format Safe-Key?');
				},

				onClose: function () {

					if (ack_in_progress)
					{
						setTimeout(function() {
							$('#wait_TP').overlay().load();
							$('#wait_message_TP').text('Safe-Key format in progress...');
						}, 100);
					}
				},

				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},

				closeOnClick: false
			});

			$("#format_key_dlg_TP form").submit(function(e) {
							
				ack_in_progress = true;
				formatKey();

				$('#format_key_dlg_TP').overlay().close()
					
				return e.preventDefault();
			});
			
			
			/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

			$('#download_prj_dlg').overlay({

				top: 250,			

				onBeforeLoad: function () {

					$('#download_prj_q').html('Are you sure you want to reload software CSE?');
				},

				onClose: function () {

					if (ack_in_progress)
					{
						setTimeout(function() {
							$('#wait').overlay().load();
							$('#wait_message').text('Software CSE reload in progress...');
						}, 100);
					}
				},

				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},

				closeOnClick: false
			});

			$("#download_prj_dlg form").submit(function(e) {						

				ack_in_progress = true;
				downloadSafePrj();

				$('#download_prj_dlg').overlay().close()
					
				return e.preventDefault();
			});
			
			/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
			
			$('#download_prj_dlg_TP').overlay({

				top: 125,
				left: 200,

				onBeforeLoad: function () {

					$('#download_prj_q_TP').html('Are you sure you want to reload software CSE?');
				},

				onClose: function () {

					if (ack_in_progress)
					{
						setTimeout(function() {
							$('#wait_TP').overlay().load();
							$('#wait_message_TP').text('Software CSE reload in progress...');
						}, 100);
					}
				},

				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},

				closeOnClick: false
			});

			$("#download_prj_dlg_TP form").submit(function(e) {						

				ack_in_progress = true;
				downloadSafePrj();

				$('#download_prj_dlg_TP').overlay().close()
					
				return e.preventDefault();
			});
			
			/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

			$('#no_connect').overlay(
			{
		
				top: 250,
		
				onBeforeLoad: function () {
						
				},
					
				onClose: function () {
							
				},
						
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
		
				closeOnClick: false
			});
			
			$('#no_sl_pres').overlay(
			{
	
				top: 250,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
						
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
				
			$('#no_sl_conn').overlay(
			{
	
				top: 250,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
					
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
			
			/*  TP  */
			
			$('#no_connect_TP').overlay(
			{
		
				top: 125,
		
				onBeforeLoad: function () {
						
				},
					
				onClose: function () {
							
				},
						
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
		
				closeOnClick: false
			});
			
			$('#no_sl_pres_TP').overlay(
			{
	
				top: 125,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
						
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
			
			$('#no_sl_conn_TP').overlay(
			{
	
				top: 125,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
					
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
				
		}	// CSE > service
	      
/*
		            ##       #### ##    ## ########  #######  
		             ##       ##  ###   ## ##       ##     ## 
		              ##      ##  ####  ## ##       ##     ## 
		    #######    ##     ##  ## ## ## ######   ##     ## 
		              ##      ##  ##  #### ##       ##     ## 
		             ##       ##  ##   ### ##       ##     ## 
		            ##       #### ##    ## ##        #######  
*/	      
		if ((document.URL.indexOf('pages/information') != -1))
		{	
			bit_comm_text = JSON.parse(sessionStorage.getItem('bit_comm_text'));
			
			setInterval(getbufferSL, 2000);
			
			$('#info_div').html(showCommBufValue());

			
				
			$('#no_connect').overlay(
			{
		
				top: 250,
		
				onBeforeLoad: function () {
						
				},
					
				onClose: function () {
							
				},
						
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
		
				closeOnClick: false
			});
				
			$('#no_sl_pres').overlay(
			{
	
				top: 250,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
						
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
				
			$('#no_sl_conn').overlay(
			{
	
				top: 250,
	
				onBeforeLoad: function () {
					
				},
				
				onClose: function () {
						
				},
					
				mask: {
					color: '#ebecff',
					loadSpeed: 200,
					opacity: 0.5
				},
	
				closeOnClick: false
			});
				
		} // CSE > information

		$('#wait').overlay({
			top: 250,
			closeOnEsc: false,
							
			mask: {
				color: '#ebecff',
				loadSpeed: 200,
				opacity: 0.5
			},
			
			onClose: function () {
				turn_set_req_in_progress = false;      
				turn_set_in_progress = false;
				restore_in_progress = false;
				emoi_stm_changed = false;
			},

			closeOnClick: false
		});
		
		$('#wait_TP').overlay({
			top: 125,
			left: 200,
			closeOnEsc: false,
							
			mask: {
				color: '#ebecff',
				loadSpeed: 200,
				opacity: 0.5
			},
			
			onClose: function () {
				turn_set_req_in_progress = false;      
				turn_set_in_progress = false;
				restore_in_progress = false;
				emoi_stm_changed = false;
			},

			closeOnClick: false
		});
		
	} // CSE
});

﻿var sys_name = null;


function show_time()
{
	var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "august", "September", "October", "November", "December" ]; 
	var dayNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

	var newDate = new Date();

	newDate.setDate(newDate.getDate());
	
	$('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

	setInterval( function() {
		// Create a newDate() object and extract the seconds of the current time on the visitor's
		var seconds = new Date().getSeconds();
		// Add a leading zero to seconds value
		$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
	},1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the minutes of the current time on the visitor's
		var minutes = new Date().getMinutes();
		// Add a leading zero to the minutes value
		$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
    },1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the hours of the current time on the visitor's
		var hours = new Date().getHours();
		// Add a leading zero to the hours value
		$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
    }, 1000);	           
}

function getAppList()
{
    $.getJSON('get?app_list', function(data)
    {
		var appList = JSON.parse(JSON.stringify(data));
   
		if(appList.app1 == null)
		{
			$("#bottomContent table").append('<td><li style="background-image: url(/index/images/No_app.png); border: none; box-shadow: none" ></li></td>');
			$("#bottomContent table").append('<td><li style="background-color: transparent; border: none; box-shadow: none; width: 200px" ><b> No applications installed </b></li></td>');
		}
		else
		{
			var i = 0;
			$.each(appList, function(index, value)
			{
				findImg(value, i);
				i++;
			});
		}
	});
	
}

function findImg(src_img, i_count)
{
	var prova = 0;
	
	$.ajax(
	{
	url: src_img.image,
	cache: false,
	data: {},
	success: function()
		{
			$("#app"+i_count).append('<a href="' + src_img.home + '/index.html"><li style="background-image: url(' + src_img.image + ')" ></li></a><li style="border: none;height: 18px; background-color: transparent; box-shadow: none ">' + src_img.name + '</li>');
		},
		
	error: function(xhr, status)
		{
			if(xhr.status == 401)
			{
					$("#app"+i_count).append('<a href="' + src_img.home + '/index.html"><li style="background-image: url(' + '/index/images/logo_min_use.png' + ')" ></li></a><li style="border: none;height: 18px; background-color: transparent; box-shadow: none ">' + src_img.name + '</li>');
			}
			else
			{
					$("#app"+i_count).append('<a href="' + src_img.home + '/index.html"><li style="background-image: url(' + '/index/images/logo_min.png' + ')" ></li></a><li style="border: none;height: 18px; background-color: transparent; box-shadow: none ">' + src_img.name + '</li>');
			}
		}
	});
	
}


// when the DOM is ready...
$(document).ready(function () {

	show_time();

	$.getJSON('get?home_info', function(data)
	{
		sys_name = data;			
		sessionStorage.setItem('sys_name', JSON.stringify(sys_name));
		//row 1
		$('#cell_cusid_v1').html(sys_name[2][1]);
		$('#cell_arm_v1').html(sys_name[1][1]);
		$('#cell_sysid_v').html(sys_name[9][1]);
		//row 2
		$('#cell_cusid_v2').html(sys_name[4][1]);
		$('#cell_arm_v2').html(sys_name[3][1]);
		$('#cell_c5gid_v').html(sys_name[0][1]);
		//row 3
		$('#cell_cusid_v3').html(sys_name[6][1]);
		$('#cell_arm_v3').html(sys_name[5][1]);
		$('#cell_ver_v').html(sys_name[10][1]);
		//row 4
		$('#cell_cusid_v4').html(sys_name[8][1]);
		$('#cell_arm_v4').html(sys_name[7][1]);
	});
	
});

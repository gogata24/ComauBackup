var emoi_text = null;
var emoi_data = null;
var sys_state = 0;
var sl_state = 0;
var safeOsState = 0;
var img_old = null;
var stroke_end = null;
var cal_sys_pos = null;
var cal_usr_pos = null;
var sys_name = null;
var arm_mask = null;
var arm_safe_mask = null;
var safe_cart_keyen = null;
var arm_type = null;
var tool_data = null;
var ack_status = null;
var C1_cal_sys_quote = null;
var C1_ideal_sys_quote = null;
var C2_cal_sys_quote = null;
var Buffer_APC_SL = null;
var sys_id = "";
var isSafeKeyen = false;
var genericWait = undefined;

var CAL_SYS_tol = 0.005;					//tolleranza accettata per posizione di calibrazione
var CAL_SYS_tol_r = 0.525;					//tolleranza accettata per posizione di calibrazione - rail

var INDEX_AX7 = 7;				// Asse 7

var SAFE_NO_EXEC = 0xF0;
var SAFE_LOGIC_RUN = 0x66;
var ROBOT_PROG_MODE = 0x8000;
var ROBOT_DRIVES_OFF = 0x40000000;

var SAFE_TURN_SET_BIT = 412;
var SAFE_TURN_REQ = 130;

var ACK_OFF_MESSAGE = "Reload software RS and then Restore configuration (or configure Safe Parameters from configuration page)";
var ACK_RUN_MESSAGE = "No action needed";

var emoi_in_progress = false;
var emoi_completed = false;
var ack_in_progress = false;
var turn_set_in_progress = false;
var turn_set_req_in_progress = false;
var emoi_stm_changed = false;
var restore_in_progress = false;

//var emoi_user_confirm = false;

var reset_mask_TS;
var reset_connect;
var reset_connect_pres = null;

var emoi_already_read = false;

var isMapSafety = false;
var isNoVRC = true;

var isTP = undefined;
var isRedirecting = false;
const LOGOUT_TIMEOUT = 600000; //10 min

const ACTUAL_RECOVERY = 'Current State: <font style="font-weight: bold;" color="#f1c100">RECOVERY</font>. ';
const ACTUAL_NORMAL = 'Current State: <font style="font-weight: bold;" color="green">NORMAL</font>. ';

const jsonSysIdIdentifier = "SysID_identifier";

var flag_login_safe  = 'safe';
var flag_login_service = 'service';
var cs_flag = null;
var SSK_RBT_CYBER_SECURITY = 0x01000000; /* 25 : System has Cyber security enabled */

function b64toByteArr(b64Data) {
	var byteCharacters = atob(b64Data);

	var charStr = byteCharacters.split(",");
	var byteNumbers = new Array(charStr.length);
	for (var i = 0; i < charStr.length; i++) {
		byteNumbers[i] = parseInt(charStr[i]);
	}

	var byteArray = new Uint8Array(byteNumbers);

	return byteArray;
}

function getCntrlSize() {
  
  $.ajax(
  {
    url: 'get?sysvar=CNTRL_SIZE', 
    cache : false,
    async: false,
    success: function(data)
    {
      try {
        var ctrlsize = JSON.parse(data); 
        ctrlsize = parseInt(ctrlsize);    
        
        isMapSafety = (ctrlsize > 0);
      } catch (e) {
        isMapSafety = false;
      }
    }
  });
};


var _cssClass = {
	dialog_hidden: "scr_dialog_hidden",
	dialog_shown: "scr_dialog_shown",
	dialog_content: "scr_dialog_content",
	dialog_title: "scr_dialog_title",
	dialog_formtitle: "scr_dialog_formtitle",
	dialog_button: "scr_dialog_button",
	dialog_row: "scr_dialog_formrow",
	dialog_cell: "scr_cell_100_popup"
};


//TSK1356 common dialogs graphics in service and configuration pages
var _utility = function() {

	function catchFocus(parentElem) {
		var focusElem = parentElem.find(".FocusElem");
		if (focusElem.length > 0) {
			focusElem[0].focus();
		}
	}

	var _messagebox = function(title, message, showOkButton) {

		function privateCreateDialog(title, message, showOkButton) {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')

					.text(title)
					
				)
				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')

							.html(message)
						)
						.append ( showOkButton ? '' : $('<img src="/safe/images/gear.png" class="FocusElem" />'))
					)
				);
			
			
			if ( showOkButton ) {

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')
					
					.click( function () {
						dialogElement.Hide();
					})
				);
			}

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append(dialogContent);
			
			return dialogElement;
		};

		function privateShow() {

			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			this.remove();
		};

		var dialog = privateCreateDialog(title, message, showOkButton);
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		
		return dialog;
		
	};
    
    var _abortbox = function(title, message, showOkButton, abortFunction) {

		function privateCreateDialog(title, message, showOkButton, abortFunction) {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')

					.text(title)
					
				)
				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')

							.html(message)
						)
						.append ( showOkButton ? '' : $('<img src="/safe/images/gear.png" class="FocusElem" />'))
					)
				);
			
			
			if ( showOkButton ) {

				dialogContent.append($('<input type="button" value="Abort" class="' + _cssClass.dialog_button + ' FocusElem"/>')
					
					.click( function () {
                        if(abortFunction != undefined && abortFunction instanceof Function){
                            abortFunction();
                        }
						dialogElement.Hide();
					})
				);
			}

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append(dialogContent);
			
			return dialogElement;
		};

		function privateShow() {

			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			this.remove();
		};

		var dialog = privateCreateDialog(title, message, showOkButton, abortFunction);
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		
		return dialog;
		
	};

	var _confirmbox = function(title, message, confirmFunction) {

		function privateCreateDialog(title, message, confirmFunction) {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')

					.text(title)
					
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')

							.html(message)
						)
					)
				);

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						dialogElement.Hide();
						
						if(confirmFunction != undefined && confirmFunction instanceof Function){
							//call passed parameter function
							confirmFunction();
						}
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};

		function privateShow() {

			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			this.remove();
		};

		var dialog = privateCreateDialog(title, message, confirmFunction);
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		
		return dialog;
	};
	
	var _restoreConfigBox = function(){

		function privateCreateDialog() {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')

					.text("Restore configuration")
					
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')

							.html("Please choose configuration backup file")
						)
						.append($('<input type="file" id="upload_file" accept=".bson" name="file" class="FocusElem"/>'))
					)
				);

				dialogContent.append( $('<input type="button" value="Ok" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						//Upload the bson file if present
						if(progAndDrivesOff()){
							
							var file = $("#upload_file")[0].files[0];
							restoreConfiguration(file);
							
						}
						
						dialogElement.Hide();
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};

		function privateShow() {

			//resetting input file content
			//$(this > "#upload_file").val('');
			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);

			this.remove();
		};

		var dialog = privateCreateDialog();
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		
		return dialog;
	};
	
	var _turnSetBox = function(){

		function privateCreateDialog(title, message) {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')

					.text(title)
					
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')

							.html(message)
						)
						
					)
				);

				dialogContent.append($('<input type="button" value="Yes" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						var set = ''
						if(isSafeOperational()){
							if (isRecovery())
							{
								set = 'off';
								$('#turn_set_btn').html('Activate');
								$('#turn_set_lbl').html('Safe Turn-set: Not active');
								emoi_data.bits[SAFE_TURN_SET_BIT] = 0;
							}
							else
							{
								set = 'on';
								$('#turn_set_btn').html('Deactivate');
								$('#turn_set_lbl').html('Safe Turn-set: Active');
								emoi_data.bits[SAFE_TURN_SET_BIT] = 1;
							}
							// salvo la modifica
							sessionStorage.setItem('emoi_data', JSON.stringify(emoi_data));

							turn_set_req_in_progress = true;
						
							$.post('set?safe_turn_set=' + set);	
						
						}
						
						if (turn_set_req_in_progress)
						{
							setTimeout(function()
							{
								
								turn_set_in_progress = true;							
								
								if (isSafeOperational() && isRecovery())	//restore mode
								{	
									$('#wait_message').text('Setting Recovery mode in progress...');
									$('#safe_led_small_R').attr('src', '../images/led_yellow.png');
									$('#safe_led_small_N').attr('src', '../images/led_off.png');
									$('#safe_turn_set_warn_msg').show();
									
								}
								else  //normal mode
								{	
									$('#wait_message').text('Setting Normal mode in progress...');
									$('#safe_led_small_R').attr('src', '../images/led_off.png');
									$('#safe_led_small_N').attr('src', '../images/led_green.png');
									$('#safe_turn_set_warn_msg').hide();
									
								}

								_dialogs.Wait.Show();								
								
							}, 500);
						}
						
						dialogElement.Hide();
					})
				);
				
				dialogContent.append( $('<input type="button" value="No" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};

		function privateShow() {
			
			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);

			this.remove();
		};

		var message;
		var title;
		
		if(isSafeOperational() && !isRecovery())
		{
			title = "RECOVERY MODE";
			if(Buffer_APC_SL[SAFE_TURN_REQ] == 1)
			{
				message = 'It is not required to switch the system into Recovery mode.<br />To return in Normal mode the robot must be moved into SAFE LINE UP position.<br /><br />Are you sure you want to switch the system into Recovery mode?';
			}
			else
			{
				message = 'Are you sure you want to switch the system into RECOVERY MODE?';
			}
		}
		else
		{
			title = "NORMAL MODE";
			message = 'Are you sure you want to switch the system into NORMAL MODE?';
		}
		
		var dialog = privateCreateDialog(title, message);
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		
		return dialog;
	};
	
	var _changePasswordBox = function() {

	var isCyberSecOn = getCybersecurityFlag();

		if(!isCyberSecOn)	// CASO CYBER_SI
		{
			function privateCreateDialog() {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')
					.text("Change password")
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')
							.html("User<br />")
							.append( $('<select id="user_select">')
							.append( '<option value="safe">safe</option>' )
							.append( '<option value="service">service</option>' ) )
						)
						.append( $('<p/>')
							.html("Old password<br />")
							.append( $('<input id="old_pwd" type="password" />') )
						)
						.append( $('<p/>')
							.html("New password<br />")
							.append( $('<input id="new_pwd" type="password" />') )
						)
						.append( $('<p/>')
							.html("Confirm new password<br />")
							.append( $('<input id="new_pwd_2" type="password" />') )
						)
						
						.append( $('<p id="response_message" style="color:red;"/>')
						)
						
					)
				);

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						//Call change password routine
						changePassword();
						//do not close the dialog... will be closed by the method itself
						
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
			};
		}
		else	// CASO CYBER_NO
		{
			function privateCreateDialog() {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')
					.text("Change password")
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')
							.html("Access rights<br />")
							.append( $('<select id="user_rights">')
							.append( '<option value="safe">safe</option>' )
							.append( '<option value="service">service</option>' ) )
						)
						.append( $('<p/>')
							.html("User<br />")
							.append( $('<input id="usr" type="user" />') )
						)
						.append( $('<p/>')
							.html("Old password<br />")
							.append( $('<input id="old_pwd" type="password" />') )
						)
						.append( $('<p/>')
							.html("New password<br />")
							.append( $('<input id="new_pwd" type="password" />') )
						)
						.append( $('<p/>')
							.html("Confirm new password<br />")
							.append( $('<input id="new_pwd_2" type="password" />') )
						)
						
						.append( $('<p id="response_message" style="color:red;"/>')
						)
						
					)
				);

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						//Call change password routine
						changePassword();
						//do not close the dialog... will be closed by the method itself
						
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};
		}

		function privateShow() {
			
			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			
			this.remove();
		};
		
		function privateShowResponse(response){
			var respMess = this.find('#response_message');
			respMess.empty();
			respMess.html(response);
		};

		var dialog = privateCreateDialog();
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		dialog.ShowResponse = privateShowResponse;
		
		return dialog;
	};

	var _configLoginBox = function() {

		function privateCreateDialog() {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')
					.text("Configuration Login")
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')
							.html("User<br />")
							.append( $('<input id="config_user" />') )
						)
						.append( $('<p/>')
							.html("Password<br />")
							.append( $('<input id="config_pwd" type="password" />') )
						)
						
						.append( $('<p id="response_message" style="color:red;"/>')
						)
						
					)
				);

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						//Call configuration login routine
						configurationLogin();
						//do not close the dialog... will be closed by the method itself
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};

		function privateShow() {
			
			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			
			this.remove();
		};
		
		function privateShowResponse(response){
			var respMess = this.find('#response_message');
			respMess.empty();
			respMess.html(response);
		};

		var dialog = privateCreateDialog();
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		dialog.ShowResponse = privateShowResponse;
		
		return dialog;
	};

	var _serviceLoginBox = function() {

		function privateCreateDialog() {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append( $('<p class="' + _cssClass.dialog_title + '"/>')
					.text("Service Login")
				)

				.append( $('<div class="'+ _cssClass.dialog_row +'"/>')
						
					.append( $('<div class="'+ _cssClass.dialog_cell +'"/>') 

						.append( $('<p/>')
							.html("User<br />")
							.append( $('<input id="service_user" />') )
						)
						.append( $('<p/>')
							.html("Password<br />")
							.append( $('<input id="service_pwd" type="password" />') )
						)
						
						.append( $('<p id="response_message" style="color:red;"/>')
						)
						
					)
				);

				dialogContent.append($('<input type="button" value="Ok" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click( function () {
						//Call configuration login routine
						serviceLogin();
						//do not close the dialog... will be closed by the method itself
					})
				);
				
				dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						dialogElement.Hide();
					})
				);
				

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

			return dialogElement;
		};

		function privateShow() {
			
			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
		};

		function privateHide() {
			this.removeClass(_cssClass.dialog_shown);
			
			this.remove();
		};
		
		function privateShowResponse(response){
			var respMess = this.find('#response_message');
			respMess.empty();
			respMess.html(response);
		};

		var dialog = privateCreateDialog();
		
		$('body').append( dialog );

		dialog.Show = privateShow;
		dialog.Hide = privateHide;
		dialog.ShowResponse = privateShowResponse;
		
		return dialog;
	};
	
	var _countdownBox = function (title, message, timeout, functionCallback) {

		var timer = undefined;

		var count = timeout / 1000;

		function privateCreateDialog(title, message) {

			var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

				.append($('<p class="' + _cssClass.dialog_title + '"/>')

					.text(title)

				)
				.append($('<div class="' + _cssClass.dialog_row + '"/>')

					.append($('<div class="' + _cssClass.dialog_cell + '"/>')

						.append($('<p/>')

							.html(message)
						)
						.append($('<h5 id="TimerContainer"/>').html(count + ' s.'))
					)
				);

				dialogContent.append($('<input type="button" value="Stay logged in" class="' + _cssClass.dialog_button + ' FocusElem"/>')

					.click(function () {
						dialogElement.Hide();
					})
				);
			

			var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append(dialogContent);

			return dialogElement;
		};

		function intervalTrigger() {
			count--;
			$("#TimerContainer").html(count + ' s.')
			if(count <= 0){
				if(functionCallback != undefined){
					functionCallback();
				}
			}
		}

		function privateShow() {

			this.addClass(_cssClass.dialog_shown);
			catchFocus(this);
			timer = setInterval(intervalTrigger, 1000);
		};

		function privateHide() {
			if (timer != undefined) {
				clearInterval(timer);
			}
			this.removeClass(_cssClass.dialog_shown);
			this.remove();
		};

		var dialog = privateCreateDialog(title, message);

		$('body').append(dialog);

		dialog.Show = privateShow;
		dialog.Hide = privateHide;

		return dialog;

	};

	return {
		
		MessageBox:			_messagebox,
		ConfirmBox:			_confirmbox,
		RestoreConfigBox : 	_restoreConfigBox,
		TurnSetBox: 		_turnSetBox,
		ChangePasswordBox:	_changePasswordBox,
		ConfigLoginBox:		_configLoginBox,
		ServiceLoginBox:	_serviceLoginBox,
		CountdownBox:		_countdownBox,
		AbortBox:    		_abortbox
	};
}();

function customAlert(text, title)
{
	if(text != undefined || title != undefined){
		setTimeout(function() {
			_utility.MessageBox(title,text,true).Show();
		}, 250);
   	}
}

function customConfirm(text, title, callbackFunction)
{
	if(text != undefined || title != undefined){
		setTimeout(function() {
			_utility.ConfirmBox(title,text,callbackFunction).Show();
		}, 250);
	}
}

function customAbort(text, title, showOkButton, callbackFunction)
{
    var customPopup;
	if(text != undefined || title != undefined){
        customPopup = _utility.AbortBox(title,text,showOkButton,callbackFunction);
		setTimeout(function() {
			customPopup.Show();
		}, 250);
        return customPopup;
    }
}

function showGenericWait(message){
	
	if(genericWait == undefined){
		genericWait = _utility.MessageBox(message,"",false);
		genericWait.Show();
	}
	return genericWait;
}

function closeGenericWait(){
	
	if(genericWait != undefined){
		genericWait.Hide();	
	}
	genericWait = undefined;
}

var _dialogs = function(){
	
	var changePwdDlg;
	var configLoginDlg;
	var waitDlg;
	var noConnectDlg;
	var loadingDialog = _utility.MessageBox("Data loading from controller in progress...", "Please wait",false);
	
	var privWait = function(){
		
		var waitClose= function(){
			if(waitDlg!=undefined){
				waitDlg.Hide();
			}
			turn_set_req_in_progress = false;      
			turn_set_in_progress = false;
			emoi_stm_changed = false;
		};
		
		var waitShow = function(message){
			
			if(message == undefined ){
				message= "Safe Logic restart in progress...";
			}
			
			waitDlg = _utility.MessageBox(message,"",false);
			
			if(waitDlg!=undefined){
				waitDlg.Show();
			}
			
		};
		
		return {
			Close: waitClose,
			Show: waitShow
		}
	}();
	
	var privNoConnect = function(){
		
		var noConnectClose= function(){
			if(noConnectDlg!=undefined){
				noConnectDlg.Hide();
			}
		};
		
		var noConnectShow = function(){
			var title = "Please, check network connection."
			var	message= "An error has occurred during the communication with Comau control cabinet.";
			
			noConnectDlg = _utility.MessageBox(title,message,false);
			
			if(noConnectDlg!=undefined){
				noConnectDlg.Show();
			}
			
		};
		
		return {
			Close: noConnectClose,
			Show:  noConnectShow
		}
	}();
	
	var privChangePasswd = function(){
		
		var changePwdClose = function (){
			if(changePwdDlg!=undefined){
				changePwdDlg.Hide();
			}
		};
		
		var changePwdShow = function (){
			changePwdDlg = _utility.ChangePasswordBox();
			
			if(changePwdDlg!=undefined){
				changePwdDlg.Show();
			}
		};
		
		var privShowResponse = function (response){
			
			if(changePwdDlg!=undefined){
				changePwdDlg.ShowResponse(response);
			}
		};
		
		return {
			Close: 			changePwdClose,
			Show:  			changePwdShow,
			ShowResponse: 	privShowResponse
		}
	}();
	
	var privConfigLogin = function(){
		
		var configLoginClose = function (){
			if(configLoginDlg!=undefined){
				configLoginDlg.Hide();
			}
		};
		
		var configLoginShow = function (){
			configLoginDlg = _utility.ConfigLoginBox();
			
			if(configLoginDlg!=undefined){
				configLoginDlg.Show();
			}
		};
		
		var privShowResponse = function (response){
			
			if(configLoginDlg!=undefined){
				configLoginDlg.ShowResponse(response);
			}
		};
		
		return {
			Close: 			configLoginClose,
			Show:  			configLoginShow,
			ShowResponse: 	privShowResponse
		}
	}();

	var privServiceLogin = function(){
		
		var serviceLoginClose = function (){
			if(serviceLoginDlg!=undefined){
				serviceLoginDlg.Hide();
			}
		};
		
		var serviceLoginShow = function (){
			serviceLoginDlg = _utility.ServiceLoginBox();
			
			if(serviceLoginDlg!=undefined){
				serviceLoginDlg.Show();
			}
		};
		
		var privShowResponse = function (response){
			
			if(serviceLoginDlg!=undefined){
				serviceLoginDlg.ShowResponse(response);
			}
		};
		
		return {
			Close: 			serviceLoginClose,
			Show:  			serviceLoginShow,
			ShowResponse: 	privShowResponse
		}
	}();

	return {
		Wait: 				privWait,
		NoConnect: 			privNoConnect,
		ChangePassword:		privChangePasswd,
		ConfigurationLogin: privConfigLogin,
		ServiceLogin:		privServiceLogin,
		LoadingDialog: function() {return loadingDialog;}
	};
}();

////// Backup & restore method //////

function getBackupFileName(extension)
{
	var date = getDateTime();

	if(!extension){
		extension='.bson';
	}
	return sys_id + '_' + date + extension;
}

function getDateTime() {
    var value = '';
    $.ajax(
    {
        url: '/get?date_time',
        cache: false,
        async: false,
        success: function (data) {
            value = JSON.parse(data).date;
        }
    });

    return value;
}

function sendJsonToCRC(blob) {
	var configurationFileName = "cartesian.json";
	var formData = new FormData();
	formData.append("cartesianCfg", blob, configurationFileName);

	var request = new XMLHttpRequest();
	request.open("POST", "run?cartesian_config");
	request.send(formData);
}

function sendBinaryJsonToCRC(blob) {
	var bsonFileName = "safe_bck.bson";
	var formDataBson = new FormData();
	formDataBson.append("cartesianCfg", blob, bsonFileName);
	
	var bsonRequest = new XMLHttpRequest();
	bsonRequest.open("POST", "run?bson_backup");
	bsonRequest.send(formDataBson);
}

function isRecovery(){
	return (emoi_data.bits[SAFE_TURN_SET_BIT] == 1);
}

function isSafeOperational(){
	return (emoi_data != null);
}

function isSaveInProgress (showMess) {
  var ret = false;
  $.ajax(
	{
		url: 'get?sysvar=RBT2_CNFG', 
		cache : false,
		async: false,
		success: function(data)
		{   
			RBT2_CNFG = parseInt(data);
			//console.log(RBT2_CNFG);
			
			ret = (RBT2_CNFG & 0x00000001) !=0;  /* SSL_RBT2_CNFG_SLBUSY       0x00000001   bit 1; = 1 SafeLogic : Save OR ReloadSW in EXECUTION  */

			if ((ret == true) && (showMess == true)) {
        customAlert('Please wait SAVE procedure or RELOAD RS procedure in progress...','WARNING');
      }
		}
	});
			
	//console.log(ret);
	return ret;
}

//function sendXmlToCRC(blob) {
//	var xmlFileName = "ComauRoboSAFE.xml";
//	var formDataXml = new FormData();
//	formDataXml.append("cartesianCfg", blob, xmlFileName);
//	
//	var xmlRequest = new XMLHttpRequest();
//	xmlRequest.open("POST", "run?xml_backup");
//	xmlRequest.send(formDataXml);
//}

function sendCartesianRun(){
	
	showGenericWait('Parameters download in progress...');    
	
	setTimeout(function() {
		$.ajax({
			type: "POST",
			url: 'run?cartesian_run',
			success: function(data) {
				closeGenericWait();
				waitSLReboot();
			}
		});
	}, 500);
}

function restoreConfiguration(file){
	
	if (!file) 
	{
		//no file found...
		customAlert('Please select a backup file', 'No file found');    
		return;
	}
	if (file.name.endsWith(".bson") || file.name.endsWith(".BSON")) {

		//restoring from the BSON file
		restore_in_progress = true;
		var reader = new FileReader();
		reader.onloadend = function()
		{
			var fileContent = reader.result;
			var BSON = bson().BSON;
			try 
		    {		
				var bArr = b64toByteArr(fileContent);
				var obj = BSON.deserialize( bArr );
				//check if JSON obj contains the correct sys_id field.
				if ( obj.hasOwnProperty(jsonSysIdIdentifier) && obj[jsonSysIdIdentifier] ===  sys_id  ) {
					//restoring backup of the same controller, OK
					
					var jsn = JSON.stringify(obj, null, 2);
					
					var blob = new Blob( [jsn], {type: "text/plain;charset=utf-8"} );
					sendJsonToCRC(blob);
					
					var blobBson = new Blob( [fileContent], {type: "data:application/octet-stream"} );
					sendBinaryJsonToCRC(blobBson);
					
					sendCartesianRun();
					
				} else {
					//restoring backup of a different controller. not allowed
					customAlert('Error during configuration restore, is not allowed to restore configuration from a different controller', 'Error restoring configuration'); 
					console.log('impossible to restore backup of a different controller');
				}
							
		      } catch (e) {
				customAlert('Error during backup file parsing, the backup file is corrupt', 'Error parsing backup'); 
				console.log(e.name + ' : ' + e.message);
		      }
		      restore_in_progress = false;
		};
		
		//read the file passed as param
		reader.readAsText(file);
	}else{
		customAlert('Invalid file format, <br />please choose only the correct backup file', 'Warning'); 
	}
}

function downloadBSONBackup(){
	var BSON = bson().BSON;
	var _configurationFileName = "cartesian.json";
	var _configurationFilePath = "../data/";
	
	//show wait dialog
	showGenericWait('Please wait, Backup building in progress...');
	
	$.ajax({
		dataType: "json",
		url: _configurationFilePath + _configurationFileName,
		cache: false,
		async: true,
		success: function( data ) {	
			
			//insert SYS_ID in the JSON object before serializing it in BSON format.
			data[jsonSysIdIdentifier] = sys_id;
			
		    // convert to bson
	        var bsn = BSON.serialize(data, false, true, false);
			  
	        //generate fake link for starting the download
	        var link = document.createElement('a');
	        link.href = 'data:application/octet-stream,' + btoa(bsn);
	        link.download = getBackupFileName('.bson');
	        
	        //close wait dialog
	    	closeGenericWait()
	    	
	    	if (document.createEvent) {
		        var event = document.createEvent('MouseEvents');
		        event.initEvent('click', true, true);
		        link.dispatchEvent(event);
		    }
		    else {
		        link.click();
		    }
		},
		error: function(xhr, textStatus, errorThrown){
		//download of the json failed
		}
	});
}

function waitSLReboot() {

	showGenericWait('Please wait, SafeLogic restart in progress...');
	
	var _interval = setInterval(function() {
		if (sl_state == 240) {
			clearInterval(_interval);
			closeGenericWait();
		}
	}, 500);
};

////// END Backup & restore method //////

function show_time()
{
	var monthNames = [ "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" ]; 
	var dayNames= ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"]

	var newDate = new Date();

	newDate.setDate(newDate.getDate());
	
	$('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

	setInterval( function() {
		// Create a newDate() object and extract the seconds of the current time on the visitor's
		var seconds = new Date().getSeconds();
		// Add a leading zero to seconds value
		$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
	},1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the minutes of the current time on the visitor's
		var minutes = new Date().getMinutes();
		// Add a leading zero to the minutes value
		$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
    },1000);
	
	setInterval( function() {
		// Create a newDate() object and extract the hours of the current time on the visitor's
		var hours = new Date().getHours();
		// Add a leading zero to the hours value
		$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
    }, 1000);	           
}

function isSafeOsStop() 
{
	return ack_status != null && ack_status.safeOsState == 170;
}

/*
function getSysState()
{
	$.ajax(
	{
	    url: 'get?sys_state', 
	    cache : false,
	    success: function(data)
	    {        
      		sys_state = parseInt(data);      		     
	    }
	});  
}
*/

function actionNeeded(action)
{
	var actualState = isRecovery() ? ACTUAL_RECOVERY : ACTUAL_NORMAL;
	$('#ack_message').html(actualState + action);
}

function getAcknowledgeStatus()
{
	
	if (ack_in_progress || turn_set_req_in_progress || restore_in_progress)
		return;

	$.ajax(
	{
		url: 'run?ack=0',
		cache: false,
		success: function(data) {
			ack_status = $.parseJSON(data);

			// **** eliminato temporaneamente Restore *****************
			//$('#ack_restore_li').css('background-color', '#eee');
			// ********************************************************

			if (ack_status.safeOsState == 0 || ack_status.safeOsState == 170)
			{
				actionNeeded(' Please Reload software RS and then Restore configuration (or configure Safe Parameters from configuration page)');
				$('#ack_down_li').css('background-color', '#ffff00');
				$('#li_turn_set_R').css('background-color', '#eee');
				//la var locale safeOsState viene aggiornata nella get sl_state per poter aggiornare il led
			}
			else
			{
				$('#ack_down_li').css('background-color', '#eee');
				//$('#ack_restore_li').css('background-color', '#eee');

				if (ack_status.safeKeyChanged)
				{
					actionNeeded('Please acknowledge Safe-Key change');
					$('#ack_skey_li').css('background-color', '#ffff00');
					$('#li_turn_set_R').css('background-color', '#eee');
				}
				else
				{
					$('#ack_skey_li').css('background-color', '#eee');

					if (ack_status.moduleMismatch > 0)
					{
						$('#li_turn_set_R').css('background-color', '#eee');
						if (ack_status.moduleMismatch == 1)
						{
							actionNeeded('Please acknowledge 1 new module');
							$('#ack_mod1_li').css('background-color', '#ffff00');							
							$('#ack_mod2_li').css('background-color', '#eee');
							$('#ack_mod3_li').css('background-color', '#eee');
							$('#ack_mod4_li').css('background-color', '#eee');
							$('#ack_modn_li').css('background-color', '#eee');
						}
						else if (ack_status.moduleMismatch == 2)
						{
							actionNeeded('Please acknowledge 2 new modules');							
							$('#ack_mod1_li').css('background-color', '#eee');						
							$('#ack_mod2_li').css('background-color', '#ffff00');
							$('#ack_mod3_li').css('background-color', '#eee');
							$('#ack_mod4_li').css('background-color', '#eee');
							$('#ack_modn_li').css('background-color', '#eee');
						}
						else if (ack_status.moduleMismatch == 3)
						{
							actionNeeded('Please acknowledge 3 new modules');
							$('#ack_mod1_li').css('background-color', '#eee');
							$('#ack_mod2_li').css('background-color', '#eee');
							$('#ack_mod3_li').css('background-color', '#ffff00');
							$('#ack_mod4_li').css('background-color', '#eee');
							$('#ack_modn_li').css('background-color', '#eee');							
						}
						else if (ack_status.moduleMismatch == 4)
						{
							actionNeeded('Please acknowledge 4 new modules');
							$('#ack_mod1_li').css('background-color', '#eee');
							$('#ack_mod2_li').css('background-color', '#eee');
							$('#ack_mod3_li').css('background-color', '#eee');
							$('#ack_mod4_li').css('background-color', '#ffff00');
							$('#ack_modn_li').css('background-color', '#eee');							
						}
						else
						{
							actionNeeded('Please acknowledge N new modules');
							$('#ack_mod1_li').css('background-color', '#eee');
							$('#ack_mod2_li').css('background-color', '#eee');
							$('#ack_mod3_li').css('background-color', '#eee');
							$('#ack_mod4_li').css('background-color', '#eee');
							$('#ack_modn_li').css('background-color', '#ffff00');
						}
					}
					else
					{
						$('#ack_mod1_li').css('background-color', '#eee');
						$('#ack_mod2_li').css('background-color', '#eee');
						$('#ack_mod3_li').css('background-color', '#eee');
						$('#ack_mod4_li').css('background-color', '#eee');
						$('#ack_modn_li').css('background-color', '#eee');

						
						if (ack_status.firmwareMismatch > 0)
						{                
							actionNeeded('Please acknowledge firmware');
							$('#ack_firm_li').css('background-color', '#ffff00');
							$('#li_turn_set_R').css('background-color', '#eee');							
						}
						else
						{
							$('#ack_firm_li').css('background-color', '#eee');
							if(sl_state != 0x66)
							{
								$('#li_turn_set_R').css('background-color', '#eee');
								
								if(ack_status.scanning)
								{
									actionNeeded('Please wait: Scanning modules...');
								}else{
									actionNeeded('Please wait');
								}	
								reset_mask_TS = 0;
							}
							else
							{
								var isSafe = hasSafeAxes();

								/*+++++++++++++++++++++++++++++++++++++++++ Inserire +++++++++++++++++++++++++++++++++++++++++++++++++*/
									
								if(isSafe && isRecovery())
								{
									actionNeeded('Please complete recovery procedure to recover safe position');
									$('#li_turn_set_R').css('background-color', '#eee');
									reset_mask_TS = 0;
								}
								else
								{											
									if (isSafe && Buffer_APC_SL[SAFE_TURN_REQ] == 0)
									{
										//if (reset_mask_TS < 4)
										//{
										//	actionNeeded('Please wait');
										//	$('#li_turn_set_R').css('background-color', '#eee');
										//	reset_mask_TS ++;
										//}
										//else
										//{
											actionNeeded('Please execute recovery procedure to recover safe position');
											$('#li_turn_set_R').css('background-color', '#ffff00');
										//}
									}
									else
									{
										actionNeeded('No action needed');
										$('#li_turn_set_R').css('background-color', '#eee');		//mettere anche altrove
									}											
								}
									
								/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
								//E' possibile implementare una sorta di diagnostica anche nel web server.
								//Magari all'interno di una pagina dedicata
							}
						}
					}
				}			
			}
		}
	});
}

function getSetupModeStatus () {
  
	$.ajax({
		type: "POST",
		url: 'run?setupmode_info',						

		success: function(data) {
		  updateSetupModeStatus ();
		}
	});
}
  
  
function updateSetupModeStatus () {
  var ret = false;
  $.ajax(
	{
		url: 'get?sysvar=RBT2_CNFG', 
		cache : false,
		async: false,
		success: function(data)
		{   
			RBT2_CNFG = parseInt(data);
			//console.log(RBT2_CNFG);
			
			ret = (RBT2_CNFG & 0x00000002) !=0;  /* SSL_RBT2_CNFG_SL_SETMODE   0x00000002   /* 2; = 1 SafeLogin in SetupMode enable */

		}
	});
			
	//console.log(ret);
	
	
	if (ret==true) {
	  //ENABLED
    $('#setup_mode_disable').css('background-color', '#ffff00');
  } else {
    //DISABLED
    $('#setup_mode_disable').css('background-color', '#eee');
  }
  
}

function getSafeMask() 
{
	var ret = JSON.parse(sessionStorage.getItem('arm_safe_mask'));

	if(ret!=null){
		return ret;
	}else{
		// carico la configurazione safe degli assi
		$.ajax(
			{
				url: 'get?arm_safe_mask', 
				cache : false,
				async: false,
				success: function(data)
				{   
					arm_safe_mask = JSON.parse(data);			
					sessionStorage.setItem('arm_safe_mask', JSON.stringify(arm_safe_mask));	
				}
			});  
		ret = arm_safe_mask;
		return ret;
	}

}

function getCybersecurityFlag()
{
	$.ajax(
	{
	  url: 'get?sysvar=RBT_CNFG',
	  cache: false,
	  async: false,
	  success: function( data ) 
	  {
		cs_flag = data;
	  }
	});

	if((cs_flag & SSK_RBT_CYBER_SECURITY) == SSK_RBT_CYBER_SECURITY)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function hasSafeAxes()
{

	var safe_mask = getSafeMask();

	for (var i = 0;i< safe_mask.length; i++) {
        if(safe_mask[i] != "-"){
           	return true;
        }
    }
    return false;
}

function getSafeLogicState()
{
	
	$.ajax(
	{
	    url: 'get?sl_state', 
	    cache: false,	    
	    success: function(data)
	    {        
	    	var sts = $.parseJSON(data);
	    	var text = "";
	    	var img = "led_off.png";
	    	
	    	// salvo
	      	sys_state = sts.sys_state;	
			
			if(sts.sl_state == -1)
			{
				//SL not declared
				text = "SL NOT DECLARED";
			}
	    	else if (sts.sl_state == 0)
	    	{
	    		if(isSafeOsStop()){
	    			text = "STOP";
	    			img = "led_red.png";
	    		}else{
	    			text = "OFF";
	    			img = "led_off.png";
	    		}
	    	}
	    	else if (sts.sl_state == 0x33)
	    	{
	    		text = "BOOT";
	    		img = "led_yellow.png";
	    	}
	    	else if (sts.sl_state == 0x55 || isSafeOsStop())
	    	{
	    		text = "STOP";
	    		img = "led_red.png";
	    	}
	    	else if (sts.sl_state == SAFE_LOGIC_RUN)
	    	{
	    		text = "RUN";
				
				if(!hasSafeAxes()){
					img = "led_green.png";
				}else{


					if(isRecovery())
					{
						img = "led_yellow_TURN.png";
						//img = "led_green.png";
					}
					else
					{
						if(Buffer_APC_SL[SAFE_TURN_REQ] == 0)
						{
							//if (reset_mask_TS < 4)
							//{
							//	img = "led_yellow.png";
							//}
							//else
							//{
							img = "led_yellow_TURN.png";
							//}
						}
						else
						{
							img = "led_green.png";
						}
					}
				}
				//aggiornare variabile per aggiornare valore led
				if(img_old != img)
				{
					img_old = img;
					$('#safe_led').attr('src', '../images/' + img);
					$('#safe_led_h').attr('src', '../images/' + img);
					$('#safe_led_small').attr('src', '../images/' + img);
				}
				
	    	}
	    	else if (sts.sl_state == 0xAA)
	    	{
	    		text = "STOP (D)";
	    		img = "led_yellow.png";	   
	    	}
	    	else if (sts.sl_state == 0xCC)
	    	{
	    		text = "RUN (D)";
	    		img = "led_yellow.png";
	    	}
	    	else if (sts.sl_state == 0xF0)
	    	{
	    		text = "NO EXEC";
	    		img = "led_yellow.png";	
	    	}
			else if (sts.sl_state == 0xFF)
	    	{
				//not connected to PowerLink network
	    		text = "SL NOT CONNECTED";	
	    	}
	    	else
	    	{
	    	 	text = sts.sl_state.toString(16);
	    	}
			
	    	if (sts.sl_state != sl_state || (ack_status!= null && safeOsState !== ack_status.safeOsState))
	    	{
	    		$('#safe_led').attr('src', '../images/' + img);
	    		$('#safe_led_h').attr('src', '../images/' + img);
	    		$('#safe_led_small').attr('src', '../images/' + img);
	    		
	    		// salvo
	    		sl_state = sts.sl_state;
	    		safeOsState = ack_status != null ? ack_status.safeOsState : 0;
	      	}

	      	if (turn_set_in_progress || restore_in_progress)
	      	{
	      		if(sts.emoi_stm != 0) {
	      			emoi_stm_changed = true;
	      		}	      		

	      		if (sts.emoi_stm == 0 && emoi_stm_changed == true) {   
	      			_dialogs.Wait.Close();
	      		}
	      	}
	    }
	});
}

function getC2()
{
	$.ajax(
	{
	    url: 'get?arm_jntp', 
	    cache: false,	    
	    success: function(data)
	    {      
	    	C2_cal_sys_quote = $.parseJSON(data);
	    }
	});  
}

function getBufferSL()
{
	$.ajax(
	{
	    url: 'get?safe_in_aboo', 
	    cache: false,    
	    success: function(data)
	    {      
	    	Buffer_APC_SL = $.parseJSON(data);
			conn_rest();
	    },
		error: function()
		{
			conn_lost();		
		}
		
	});  
}

function conn_lost()
{
	if(reset_connect > 3)
	{
		if(reset_connect_pres == 0)	
		{
			reset_connect_pres = 1;
			_dialogs.NoConnect.Show();
		}
	}
	else
	{
		reset_connect++;
	}
}

function conn_rest()
{
	reset_connect = 0;
	if(reset_connect_pres != 0)
	{
		reset_connect_pres = 0;
		_dialogs.NoConnect.Close();
	}
}

function checkOpenConfigure(){
	// verifico che il Recovery mode non sia attivo.
		
	if (document.URL.indexOf('pages/cartesian') != -1) {
		
		var force = document.URL.indexOf("?force=true");
		
		if (force == -1) {
		
			if(!isSafeOperational()){
				_utility.MessageBox('SafeLogic not operational.','Please follow instructions in Service page to restore normal safety functionalities.',false).Show();
				setTimeout(function() {
					//redirect to homepage, safe cannot be configured
					//logoff
					window.location.href = "home.html";
				
					$.ajax({
						type: "POST",
						url: 'cartesian.html',
						username: 'logout',
						password: 'logout'
					});
				}, 2500);
			}
			else if (isRecovery())
			{
				_utility.MessageBox('Complete Recovery','To make a right configuration of safety parameters, system must not be in Recovery mode.<br /><br />Please complete recovery procedure first to restore normal safety functionalities.',false).Show();
				setTimeout(function() {
					//redirect to homepage, safe cannot be configured
					//logoff
					window.location.href = "home.html";
				
					$.ajax({
						type: "POST",
						url: 'cartesian.html',
						username: 'logout',
						password: 'logout'
					});
				}, 2500);
			}
		}
	}
}

function changePassword()
{
	var rv = false;
	var flag_login;
	var user = $('#usr').val();
	var oldPwd = $('#old_pwd').val();
	var newPwd = $('#new_pwd').val();
	var newPwd2 = $('#new_pwd_2').val();

	if(($('#user_rights').val().localeCompare(flag_login_safe)) == 0)
	{
		flag_login = flag_login_safe;
	}
	else if(($('#user_rights').val().localeCompare(flag_login_service)) == 0)
	{
		flag_login = flag_login_service;
	}
	else
	{
		_dialogs.ChangePassword.ShowResponse("Invalid flag!");
	}

	if (!user)
	{	
		_dialogs.ChangePassword.ShowResponse("Please insert username!");
	}

	if (!oldPwd)
	{	
		_dialogs.ChangePassword.ShowResponse("Please insert old password!");
	}
	else if (!newPwd)
	{
		_dialogs.ChangePassword.ShowResponse("Please insert new password!");	
	}
	else
	{
		if (newPwd.localeCompare(newPwd2) != 0)
		{
			_dialogs.ChangePassword.ShowResponse("Password does not match!");
		}
		else
		{
			// Parsing strings to avoid sending special characters
			var enc_newPwd = encodeURIComponent(newPwd);
			var enc_oldPwd = encodeURIComponent(oldPwd);
			newPwd = enc_newPwd.replace("%26", "%");	// Replacing '&'
			oldPwd = enc_oldPwd.replace("%26", "%");	// Replacing '&'
			
			_dialogs.ChangePassword.ShowResponse("Changing password!");	//FIXME: rimuovere a fine debug
			changeUserPwd(user, oldPwd, newPwd, flag_login);
		}
	}

	return rv;
}

function configurationLogin()
{
	var rv = false;

	var CUsr = $('#config_user').val();
	var CPwd = $('#config_pwd').val();

	if (!CUsr)
	{	
		_dialogs.ConfigurationLogin.ShowResponse("Please insert username!");
	}
	else if (!CPwd)
	{
		_dialogs.ConfigurationLogin.ShowResponse("Please insert password!");	
	}
	else
	{
		var enc_pwd = encodeURIComponent(CPwd);
		CPwd = enc_pwd.replace("%26", "%");		// Replacing '&'
		configurationLoginFnct(CUsr, CPwd);
	}

	return rv;
}

function serviceLogin()
{
	var rv = false;

	var SUsr = $('#service_user').val();
	var SPwd = $('#service_pwd').val();

	if (!SUsr)
	{	
		_dialogs.ServiceLogin.ShowResponse("Please insert username!");
	}
	else if (!SPwd)
	{
		_dialogs.ServiceLogin.ShowResponse("Please insert password!");	
	}
	else
	{
		var enc_pwd = encodeURIComponent(SPwd);
		SPwd = enc_pwd.replace("%26", "%");		// Replacing '&'
		serviceLoginFnct(SUsr, SPwd);
	}

	return rv;
}

function formatKey()
{
	$.ajax({
		type: "POST",
		url: 'run?format_key',						

		success: function(data) {
			changeSafePwd();
		}
	});
}

function changeSafePwd()
{
	$.ajax({
		type: "POST",
		url: 'run?change_passw',

		success: function(data) {
			ack_in_progress = false;
			_dialogs.Wait.Close();
		}
	});
}

function downloadSafePrj()
{
	$.ajax({
		type: "POST",
		url: 'run?download_code',

		success: function(data) {
			ack_in_progress = false;
			_dialogs.Wait.Close();
			location.reload();
		},

		error: function(data) {
			ack_in_progress = false;
			_dialogs.Wait.Close();
			customAlert('','Reload software RS procedure failed');
		}
	});
}

function acknowledgeSafe(set)
{
	$.ajax({
		type: "POST",
		url: 'run?ack=' + set,

		success: function(data) {
			ack_in_progress = false;
			_dialogs.Wait.Close();
		},
		error: function(data) {
			ack_in_progress = false;
			_dialogs.Wait.Close();
		},
		timeout: 15000
	});
}

/*++++++++++++++++++++++++++++++*/
//$.post('set?safe_turn_set=' + set);	
/*function set_normal()
{
	var set = 'off';
	$.ajax(
	{
		type: "POST",
		url: 'set?safe_turn_set=' + set,
		
		success: function(data)
		{
			turn_set_in_progress = false;
			$('#wait').overlay().close();
		}
	});
}*/

/*+++++++++++++++++++++++++++++*/

function changeUserPwd(user, old, _new, flag_login)
{
	$.ajax({
		type: "POST",
		async: false,		//	A Boolean value indicating whether the request should be handled asynchronous or not. Default is true.
		url: 'set?new_pwd=' + _new + '&old_pwd=' + old + '&user=' + user + '&flag_login=' +flag_login
	})
	.success(function(response) {

		if (response.localeCompare("OK") == 0)
		{
			_dialogs.ChangePassword.Close();				
		}
		else
		{		
			_dialogs.ChangePassword.ShowResponse(response);
		}
	});
}

function configurationLoginFnct(user, psw)
{
	var destUrl = "cartesian.html?nocache=" + (new Date()).getTime();
	$.ajax({
		type: "POST",
		url: 'set?safe_login&user=' + user + '&safe_pwd=' + psw + '&flag_login=' +flag_login_safe
	})
	.success(function(response) {
		if (response.localeCompare("OK_SAFE") == 0) 
		{
			window.location.replace(destUrl);
			_dialogs.ConfigurationLogin.Close();
		}
		else if (response.localeCompare("WRONG USER") == 0)
		{		
			customAlert("User not authorized" , "Login failed");
		}
		else if (response.localeCompare("EXPIRED") == 0)
		{		
			customAlert("Expired credentials" , "Login failed");
		}
		else
		{
			customAlert("Login failed, please insert correct username and password" , "Login failed");
		}
	})
	.fail(function(xhr, status, error){
			customAlert("Login failed, please insert correct username and password" , "Login failed");
	});
}

function serviceLoginFnct(user, psw)
{
	var destUrl = "service.html?nocache=" + (new Date()).getTime();
	$.ajax({
		type: "POST",
		url: 'set?service_login&user=' + user + '&service_pwd=' + psw + '&flag_login=' +flag_login_service
	})
	.success(function(response) {
		if (response.localeCompare("OK_SERVICE") == 0)
		{
			window.location.replace(destUrl);
			_dialogs.ConfigurationLogin.Close();		
		}
		else if (response.localeCompare("WRONG USER") == 0)
		{		
			customAlert("User not authorized" , "Login failed");
		}
		else if (response.localeCompare("EXPIRED") == 0)
		{		
			customAlert("Expired credentials" , "Login failed");
		}
		else
		{
			customAlert("Login failed, please insert correct username and password" , "Login failed");
		}
	})
	.fail(function(xhr, status, error){
			customAlert("Login failed, please insert correct username and password" , "Login failed");
	});
}

function logoutTrick()
{
	if ($.browser.msie)
	{
		document.execCommand('ClearAuthenticationCache');
	}
	else
	{
		$.ajax({
				type: "POST",
				url: 'configuration.html',
				username: 'logout',
				password: 'logout'
			});		
	}	
}

function progAndDrivesOff()
{
	// verifico che sia in programmazione
	if ((sys_state & ROBOT_PROG_MODE) == 0)
	{
		customAlert('Please switch the selector to PROGR','System must be in PROGR mode');
		return false;
	}
	
	// verifico che sia in drive off
	if ((sys_state & ROBOT_DRIVES_OFF) == 0)
	{
		customAlert('Please turn OFF the drives','System must be in drives OFF');
		return false;
	}

	return true;
}


function prog()
{
	// verifico che sia in programmazione
	if ((sys_state & ROBOT_PROG_MODE) == 0)
	{
		customAlert('Please switch the selector to PROGR','System must be in PROGR mode');
		return false;
	}

	return true;
}

/*+++++++++++++++++ Turn-set mode +++++++++++++++++++++++++++*/
// Controllo di non essere in Turn-set
function no_turn_set_mode()
{
	var sts = true;

	// verifico che il Recovery mode non sia attivo
	if(!isSafeOperational()){
		customAlert('Please follow instructions in Service page to restore normal safety functionalities.' , 'SafeLogic not operational.');
		sts = false;
	}
	else if (isRecovery())
	{
		customAlert('To make a right configuration of safety parameters, system must not be in Recovery mode.<br /><br />Please complete recovery procedure first to restore normal safety functionalities.','Complete recovery');
		sts = false;
	}

	return sts;
}

/*+++++++++++++++++ Buffer_on +++++++++++++++++++++++++++++++++++*/
// Controllo che il buffer di comunicazione non sia 0
function buffer_on()
{
	var res = 0;
	var i;
	
	for (i = 1 ; i < 96+1 ; i++)
	{
		res = res + parseInt(Buffer_APC_SL[i]);
	}

	return res;
}

/*+++++++++++++++++ Turn-set request? +++++++++++++++++++++++++++*/
// Sconsiglio di rieffettuare il turn-set se non necessario
/*function ck_turn_req()
{
	if (Buffer_APC_SL[SAFE_TURN_REQ] == 1 && emoi_data.bits[SAFE_TURN_SET_BIT ] == 0)
	{
		alert('It is not required to switch the system into Recovery mode.\n\nIt is not advisable to start recovery procedure.');
	}
}*/

/*+++++++++++++++++ IE identification +++++++++++++++++++++++++++*/
// 
function IE_ident()
{
	if (navigator.appName == "Microsoft Internet Explorer")
	{	
		return true;
	}
	else
	{
		return false;
	}
}

/*+++++++++++++++++ C1 aligned +++++++++++++++++++++++++++++++*/
// verifica che le quote C1 (ACOPOS) corrispondano alla posizione di calibrazione
/*function C1_aligned()
{

	//Get valori C1 ideali del controllo
	$.getJSON('get?read giquo', function(data) {
		//C1_ideal_sys_quote = $.parseJSON(data);
		C1_ideal_sys_quote = data;			
		//sessionStorage.setItem('C1_ideal_sys_quote', JSON.stringify(C1_ideal_sys_quote));
	});
	
	//Set lettura ParID 91
	$.post('set?request qc1');
	
	//Timeout impostato a 200ms
	setTimeout(function()
	{
	
		//Get valori assi
		$.getJSON('get?read qc1', function(data) {
			C1_cal_sys_quote = data;			
			//sessionStorage.setItem('C1_cal_sys_quote', JSON.stringify(C1_cal_sys_quote));
		});
		
		setTimeout(function()
		{
		

		
			//Check allineamento
			var j;
			var C1_err = 0 ;							//rilevato errore nelle C1
			var C1_err_string = ['','','','','','',''];	//valore da scrivere nell'alert
			
			for(j = 0; j < 6; j++)
			{
				C1_ideal_sys_quote[0][j+1][1] = C1_ideal_sys_quote[0][j+1][1] * 10000;
				if((C1_cal_sys_quote[0][j+1][1] > (C1_ideal_sys_quote[0][j+1][1] + 150)) || (C1_cal_sys_quote[0][j+1][1] < (C1_ideal_sys_quote[0][j+1][1] - 150)))
				{
					C1_err = 1;
					var a= (C1_ideal_sys_quote[0][j+1][1]).toFixed(0);
					C1_err_string[j] = '\nAxis ' + ( j + 1 ) + ' turn reference:  System= ' + a + ' Drive= ' + (C1_cal_sys_quote[0][j + 1][1]);
				}
			}
			//aggiungere eventuale verifica asse 7
			if(arm_mask[INDEX_AX7 - 1] != '-' && arm_safe_mask[INDEX_AX7 - 1] != '-')
			{
				C1_ideal_sys_quote[0][7][1] = C1_ideal_sys_quote[0][7][1] * 10000;
				if((C1_cal_sys_quote[0][7][1] > (C1_ideal_sys_quote[0][7][1] + 150)) || (C1_cal_sys_quote[0][7][1] < (C1_ideal_sys_quote[0][7][1] - 150)))
				{
					C1_err = 1;
					var a= (C1_ideal_sys_quote[0][7][1]).toFixed(0);
					C1_err_string[j] = '\nRail turn reference:  System= ' + a + ' Drive= ' + (C1_cal_sys_quote[0][7][1]);
				}
			}
				
			//Messaggio errore
			if (C1_err == 1)
			{
				alert('An error has been detected into the reference of below axes:\n'
				+ C1_err_string[0] 
				+ C1_err_string[1]
				+ C1_err_string[2]
				+ C1_err_string[3]
				+ C1_err_string[4]
				+ C1_err_string[5]
				+ C1_err_string[6]
				+ '\n\n\nPlease, execute Turn-set action over highlighted axes.'
				);
			}
			else
			{
				$('#turn_set_dlg').overlay().load();
			}
			
		}, 100);
	
	}, 100);		
	
}*/

/*+++++++++++++++++ C2 aligned +++++++++++++++++++++++++++++++*/
// verifica che le quote C2 (sistema) corrispondano alla posizione di calibrazione
function C2_aligned()
{
	/* PLA -> forzo aggiornamento $CAL_USER */
	$.ajax({
		dataType: "json",
		url: 'get?arm_cal_usr',
		cache: false,
		async: false,
		success: function( data ) {			
			cal_usr_pos = data;
		}
	});

	var check_cal_sys_pos = 0;		// 0 --> CAL_SYS
	var C2_err_string = ['','','','','','',''];	//valore da scrivere nell'alert
	
	var CAL_USR_JNT = [0,0,0,0,0,0,0];
	
	for (var x = 0; x < 7; x++)
	{
		cal_usr_pos[0][x+1][1] = cal_usr_pos[0][x+1][1] * 1;
		CAL_USR_JNT[x] = (cal_usr_pos[0][x+1][1]).toFixed(3);  
	}
	
	var C2_rounded = [CAL_USR_JNT[0], CAL_USR_JNT[1], CAL_USR_JNT[2], CAL_USR_JNT[3], CAL_USR_JNT[4], CAL_USR_JNT[5], CAL_USR_JNT[6]];
	var j;
	
	//Verifico che sia in posizione di Safe Turn-set
	for(j = 0; j < 6; j++)
	{
		if((parseFloat(C2_cal_sys_quote[j][1])) > (parseFloat(CAL_USR_JNT[j]) + CAL_SYS_tol) || (parseFloat(C2_cal_sys_quote[j][1])) < (parseFloat(CAL_USR_JNT[j]) - CAL_SYS_tol))	
		{
			check_cal_sys_pos = 1;
			C2_rounded[j] = (parseFloat(C2_cal_sys_quote[j][1])).toFixed(3);
			C2_err_string[j] = '<br />Axis ' + ( j + 1 ) + ' position:    SAFE LINE UP=' + CAL_USR_JNT[j] + ' Actual=' + C2_rounded[j];
		}
	}
	
	if(arm_mask[INDEX_AX7 - 1] != '-' && arm_safe_mask[INDEX_AX7 - 1] != '-')
	{
		if((parseFloat(C2_cal_sys_quote[6][1])) > (parseFloat(CAL_USR_JNT[6]) + CAL_SYS_tol_r) || (parseFloat(C2_cal_sys_quote[6][1])) < (parseFloat(CAL_USR_JNT[6]) - CAL_SYS_tol_r))	
		{
			check_cal_sys_pos = 1;
			C2_rounded[6] = (parseFloat(C2_cal_sys_quote[6][1])).toFixed(3);
			C2_err_string[j] = '<br />Rail position:    SAFE LINE UP=' + CAL_USR_JNT[6] + ' Actual=' + C2_rounded[6];
		}
	}
	
	
	if (check_cal_sys_pos)
	{
		customAlert(''
		+ C2_err_string[0] 
		+ C2_err_string[1]
		+ C2_err_string[2]
		+ C2_err_string[3]
		+ C2_err_string[4]
		+ C2_err_string[5]
		+ C2_err_string[6]
		+ '<br /><br />Please move robot in SAFE LINE UP position.'
		, 'System not in SAFE LINE UP position.');

		return false;
	}
	
	return true;
}

function sl_run_ok()
{
	if(sl_state != 0x66)
	{
		customAlert('','Please first complete all of the steps highlighted into the page');
		return false;
	}
	return true;
}


////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////																			////
////																			////
////						SERVICE Utility function							////
////																			////
////																			////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

function doAckFormat(){
	if (progAndDrivesOff()) {
		customConfirm("Are you sure you want to format Safe-Key?","Format Safe Key", function(){
			
			ack_in_progress = true;
			formatKey();

			setTimeout(function() {
				_dialogs.Wait.Show('Safe-Key format in progress...');
			}, 100);
		});
	}
}

function doDownloadPrj(){
  
	if (isSaveInProgress(true)){
	  return;
	}
			
	if (progAndDrivesOff()) {
		customConfirm('Are you sure you want to reload software RS? </br>' + 
            (hasSafeAxes() ? '<div style="color:red;">NOTE: after having reloaded the RS software the safe logic will boot up in recovery mode,</br> a restart cold is required</div>' : ''), "Reload Software RS", function () {
			
			ack_in_progress = true;
			downloadSafePrj();

			setTimeout(function() {
				_dialogs.Wait.Show('Software RS reload in progress...');
			}, 100);
		});					
	}
}

function doRestoreCfg(){
	if (progAndDrivesOff()) {
		_utility.RestoreConfigBox().Show();
	}
}

function doSafeKeyAcknowledge(){
	ack_in_progress = true;
	acknowledgeSafe(7);
	_dialogs.Wait.Show('Safe-Key acknowledge in progress...');
}

function doModuleAcknowledge(numModules){
	ack_in_progress = true;
	acknowledgeSafe(numModules);
	_dialogs.Wait.Show('Modules acknowledge in progress...');
}

function doFirmwareAcknowledge(){
	ack_in_progress = true;
	acknowledgeSafe(6);
	_dialogs.Wait.Show('Firmware acknowledge in progress...');
}

var checkMoveInterval;

function moveToSafeCalUser(){
  if(prog())
	{
		var popupMoveInProg = customAbort('Move to SAFE LINE UP POSITION in progress...','SAFE LINE UP POSITION', true, function(){
			$.ajax(
			{
				url:"run?program_deact&prog=UD:/sys/util/move_to_cal_user",
				async:false,
				success:function()
				{
					console.log('Abort della move');
				}
			});
		});
		
		
		$.ajax({url:"run?program_go=UD:/sys/util/move_to_cal_user",async:false,success:function(result){	
		}}); 
		
		setTimeout(function() {   
			$.ajax(
			{
				url:"set?var=vb_move_to_cal_user&prog=move_to_cal_user&value=true",
				async:false,
				success:function()
				{
					setTimeout(function() {
						var checkMoveInterval = setInterval( function(){
							$.ajax(
							{
								url:"get?var=vb_move_to_cal_user&prog=move_to_cal_user",
								async:false,
								success:function(data)
								{
									//console.log('Stato move = ', data);
									vb_move_to_cal_user = data;
									
									if (vb_move_to_cal_user==1)
									{
										//console.log('Stato move aspetto 500 ms e richiamo la waitForMoveInProgr');
									}
									else{
										clearInterval(checkMoveInterval);
										popupMoveInProg.Hide();
									}
								}
							});
						}, 1500);
					},200);
				}
			});
		},500);    
	}
}

function setupModeDisableCommand(){
  if(prog())
	{
	  
	  showGenericWait('Disabling Setup Mode in progress...');   
		$.ajax(
		{
			url:"run?setupmode_dsbl",
			async:true,
			success:function()
			{
			  closeGenericWait();
			},
		  error: function(data) {
			  closeGenericWait();
		  }
		});
	}
}

function onRecoveryClick(){
	if (isSafeOperational() && !isRecovery()) {
		//ck_turn_req();
		if (progAndDrivesOff()) {
			if(sl_run_ok()) {
				_utility.TurnSetBox().Show();
			}
		}
	}
	else
	{
		customAlert('','System is already in Recovery mode.');
	}
}

function onNormalClick(){
	if (isSafeOperational() && isRecovery())		
	{
		if (progAndDrivesOff())
		{
			if(sl_run_ok())
			{
				if (C2_aligned())
				{
					//C1_aligned();
					_utility.TurnSetBox().Show();
				}
			}
		}
	}
	else
	{
		customAlert('','System is already in Normal mode.');
	}
}

function isServicePage(){
	return document.URL.indexOf('pages/service') != -1;
}

// gestione logout automatico
function isTPConnected(){
	if(isTP == undefined){
		$.ajax({
			url: 'get?is_tp', 
			cache : false,
			async: false,
			success: function(data)
			{        
				isTP = data == "true";
			}
		}); 
	}
	return isTP;
}

function is_NoVRC(){
	$.ajax({
    url: 'get?sysvar=GLOOP_ALONG_1D',
    cache: false,
    async: false,    
		success: function(data) {
		  obj = $.parseJSON(data);
		  GLOOP_ALONG_1D = obj.GLOOP_ALONG_1D;
      if (GLOOP_ALONG_1D[78 - 1] == 2)
      {
        isNoVRC = false;
      }
		}
	});
}

//per informare altre pagine dell'inizio del tentativo di logout temporizzato
function isTimeoutRedirecting(){
	return isRedirecting;
}

function redirect(){

	//show Countdown Popup TSK2251
	_utility.CountdownBox("The session is going to be terminated", "Press the button to stay logged in", 60000, function () {
		var redirectUrl = "/index/errorPages/SessionTimeout.html";
		if (isTPConnected()) {
			redirectUrl = "http://10.3.12.2/index/errorPages/SessionTimeout.html";
		}

		isRedirecting = true;

		$(window).on('beforeunload', function () {
			//per non far comparire il prompt del browser che impedisce il redirect in caso di modifiche alla pagina
			return undefined;
		});

		$.ajax({
			type: "POST",
			url: 'cartesian.html',
			username: 'logout',
			password: 'logout'
		})
		.fail(function () {
			window.location.replace(redirectUrl);
		});
	}).Show();

	
}

////////////////////////////////////////////////////END SERVICE UTILITY function///////////////////////////////////////////

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

// when the DOM is ready...
$(document).ready(function () {

	show_time();	

	var isCyberSecOn = getCybersecurityFlag();
	
	// pagina safe
	if (document.URL.indexOf('safe') != -1)
	{
		getBufferSL();  //questa informazione è usata per determinare lo stato della safe quindi viene chiesta una volta per prima
		// attivo la lettura dello stato della safe logic
		setInterval(getSafeLogicState, 1000);
		// attivo la lettura delle variabili del buffer APC_SL (ogni 5 secondi)
		setInterval(getBufferSL, 2000);

		// carico le informazioni di sistema
		$.getJSON('get?home_info', function(data)
		{
			sys_name = data;			
			sessionStorage.setItem('sys_name', JSON.stringify(sys_name));
			$('#bloc1_h').html(sys_name[0][0] + ": " + sys_name[0][1]);
			$('#bloc1').html(sys_name[0][0] + ": " + sys_name[0][1]);
			
		});
		
		if (document.URL.indexOf('pages/loginSafe') == -1) {
			//in pagina login non viene mostrato questo alert
			showGenericWait("Contacting SafeLogic, please wait.");
		}
		// carico gli emoi in maniera sincrona se sono in pagina service
		$.ajax({
			dataType: "json",
			url: 'get?emoi=all',
			cache: false,
			async: !isServicePage(),
			success: function( data ) {			
				emoi_data = data;
				emoi_already_read = true;
				sessionStorage.setItem('emoi_data', JSON.stringify(emoi_data));
				closeGenericWait();
				//disabilitato, la pagina ora si apre anche in recovery (TSK2076)
				//checkOpenConfigure();
			},
			error: function() {
				emoi_data = null;
				emoi_already_read = true;
				closeGenericWait();
				//disabilitato, la pagina ora si apre anche in recovery (TSK2076)
				//checkOpenConfigure();
			}
			
		});
		
		$.ajax({
			url: 'get?sysvar=SYS_ID',
			cache: false,
			async: false,
			success: function( data ) {			
				sys_id = data;
			}
		});
		
		//CHIEDO UNA VOLTA ack0 per avere il valore di safeOS state
		$.getJSON('run?ack=0', function(data)
		{
			ack_status = data;			
		});
		
		if (document.URL.indexOf('pages/loginSafe') != -1) { //TSK2061 login da TP5 migliorato
			
			
			var isSetup = document.URL.indexOf("destination=setup");
			var isService = document.URL.indexOf("destination=service");
			var destUrl = "";
			
			if(!isCyberSecOn)
			{
				$("#login_form").submit(function() {
					//try to perform the login
					var user = $("#id_username").val();
					var pass = $("#id_password").val();
				
					if (isSetup >= 0) {
						destUrl = "cartesian.html?nocache=" + (new Date()).getTime();
					} else if (isService >= 0) {
						destUrl = "service.html?nocache=" + (new Date()).getTime();
					} else {
						//show an error message and return, this shouldn't happens
						customAlert("Login Failed, invalid parameters" , "Login failed");
						return;
					}

					if(user != undefined && user != "" && pass != undefined && pass!= ""){

						$.ajax({
							type: "POST",		// Specifies the type of request. (GET or POST).
							url: destUrl,		// Specifies the URL to send the request to. Default is the current page.
							username: user,		// Specifies a username to be used in an HTTP access authentication request.
							password: pass		// Specifies a password to be used in an HTTP access authentication request.
						})
						.success(function(){
							//redirect to destination page.
							window.location.replace(destUrl);
						})
						.fail(function(xhr, status, error){
							//show an error message
							customAlert("Login Failed, please insert the correct username and password" , "Login failed");
						});
					}else{
						//show message "Complete all field"
						customAlert("Please insert username and password" , "Incomplete fields");
					}
				
				});
			}
			
		}
		
/*
		 ######     ###    ######## ########            ##       ##     ##  #######  ##     ## ######## 
		##    ##   ## ##   ##       ##                   ##      ##     ## ##     ## ###   ### ##       
		##        ##   ##  ##       ##                    ##     ##     ## ##     ## #### #### ##       
		 ######  ##     ## ######   ######      #######    ##    ######### ##     ## ## ### ## ######   
		      ## ######### ##       ##                    ##     ##     ## ##     ## ##     ## ##       
		##    ## ##     ## ##       ##                   ##      ##     ## ##     ## ##     ## ##       
		 ######  ##     ## ##       ########            ##       ##     ##  #######  ##     ## ######## 
 */

		// verifico se è stata caricata la pagina safe home
		if (document.URL.indexOf('pages/home') != -1)
		{
			if(IE_ident())
			{
				location.href = "IE_identif.html";
			}
			else
			{
				var logout = sessionStorage.getItem('logout');

				if (logout == '1')
				{
					sessionStorage.setItem('logout', '0');
					logoutTrick();
				}


				var isCyberSecOn = getCybersecurityFlag();

				if(isCyberSecOn)
				{
					$("#li_configuration_login").click(function() {
					_dialogs.ConfigurationLogin.Show();
					});

					$("#li_service_login").click(function() {
						_dialogs.ServiceLogin.Show();
					});
				}
				else
				{
					$('#li_configuration_login').click(function () {
						if(emoi_already_read){
							location.href = "loginSafe.html?destination=setup&nocache=" + (new Date()).getTime();
						}else{
							customAlert('Please wait, SafeLogic not ready', 'SafeLogic not ready');
						}
					});	

					$('#li_service_login').click(function () {		
						location.href = "loginSafe.html?destination=service&nocache=" + (new Date()).getTime();
					});
				}

				$("#li_change_pwd").click(function() {
					_dialogs.ChangePassword.Show();
				});

//				$.getJSON('emoi.json', function(data) {
//					emoi_text = data;
//					sessionStorage.setItem('emoi_text', JSON.stringify(emoi_text));
//				});
				
				// carico la licenza safe cartesian
				$.getJSON('get?safe_cart_keyen',  function(data) {        
					var safe_cart_keyen = JSON.parse(data);
					isSafeKeyen= (safe_cart_keyen != undefined && safe_cart_keyen == "1") 
				});

//				// carico gli stroke-end
//				$.getJSON('get?stroke_end', function(data) {
//					stroke_end = data;			
//					sessionStorage.setItem('stroke_end', JSON.stringify(stroke_end));
//				});
				
				// carico la posizione di calibrazione
				$.getJSON('get?arm_cal_sys', function(data) {
					cal_sys_pos = data;			
					sessionStorage.setItem('cal_sys_pos', JSON.stringify(cal_sys_pos));
				});

				// carico la posizione di calibrazione utente
				$.getJSON('get?arm_cal_usr', function(data) {
					cal_usr_pos = data;			
					sessionStorage.setItem('cal_usr_pos', JSON.stringify(cal_usr_pos));
				});
			
				/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
				// carico la configurazione degli assi
				$.getJSON('get?arm_mask', function(data) {
					arm_mask = data;			
					sessionStorage.setItem('arm_mask', JSON.stringify(arm_mask));
				});
			
				// carico la tipologia degli assi
				$.getJSON('get?arm_type', function(data) {
					arm_type = data;			
					sessionStorage.setItem('arm_type', JSON.stringify(arm_type));
				});
				/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

				// carico le dimensioni del tool
				$.getJSON('get?tool', function(data) {
					tool_data = data;			
					sessionStorage.setItem('tool_data', JSON.stringify(tool_data));
				});

				$('#li_report').click(function() {

					if (isSafeOperational()) {
						if (!isRecovery()) {
							
							showGenericWait("Generating report, please wait.");
							document.body.style.cursor = 'wait';
							
							var isSafe = hasSafeAxes();
							
							if (isSafeKeyen) {
								location.assign('run?report=cartesian');
							} else if (isSafe) {
								location.assign('run?report=joint');
							} else {
								location.assign('run?report=system');
							}
						} else {
							customAlert('Please follow instructions in Service page to restore normal safety functionalities.', 'Report not available in Recovery Mode');
						}
					} else {
						if(emoi_already_read){
							customAlert('Please follow instructions in Service page to restore normal safety functionalities.', 'Report not available when SafeLogic is formatted');
						}else{
							customAlert('Please wait, SafeLogic not ready', 'SafeLogic not ready');
						}
						
					}
				});
				
				$('#li_configuration_viewer').click(function () {
				
					location.href = "cartesianviewer.html?nocache=" + (new Date()).getTime();
				});	
				
				
				

				/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
				
			}
		} // safe > home

		/*
		safe cartesiano (unito ora con giunti)
		*/

		if (document.URL.indexOf('pages/cartesian') != -1) {
			
			var initial = setTimeout(redirect, LOGOUT_TIMEOUT);

			$(document).click(function(event) {
				clearTimeout(initial);
				initial = setTimeout(redirect, LOGOUT_TIMEOUT);
			});
			
			//tasto visualizzato da PC
			$('#logout_btn_h').click(function() {
				//logoff
				window.location.href = "home.html";

				$.ajax({
					type: "POST",
					url: 'cartesian.html',
					username: 'logout',
					password: 'logout'
				});
			});
			
			sessionStorage.setItem('logout', '0');
	
			arm_mask = JSON.parse(sessionStorage.getItem('arm_mask'));
			arm_safe_mask = JSON.parse(sessionStorage.getItem('arm_safe_mask'));
			arm_type = JSON.parse(sessionStorage.getItem('arm_type'));
				
			/*$('#li_logout').click(function () {
				sessionStorage.setItem('logout', '1');
				location.assign('home.html');
			});	*/
		} // safe > configuration
		
		
/*
		 ######     ###    ######## ########            ##        ######  ######## ########  ##     ## ####  ######  ######## 
		##    ##   ## ##   ##       ##                   ##      ##    ## ##       ##     ## ##     ##  ##  ##    ## ##       
		##        ##   ##  ##       ##                    ##     ##       ##       ##     ## ##     ##  ##  ##       ##       
		 ######  ##     ## ######   ######      #######    ##     ######  ######   ########  ##     ##  ##  ##       ######   
		      ## ######### ##       ##                    ##           ## ##       ##   ##    ##   ##   ##  ##       ##       
		##    ## ##     ## ##       ##                   ##      ##    ## ##       ##    ##    ## ##    ##  ##    ## ##       
		 ######  ##     ## ##       ########            ##        ######  ######## ##     ##    ###    ####  ######  ########
*/

		if (isServicePage())
		{

			setInterval(getAcknowledgeStatus, 2000);		
			setInterval(getC2, 2000); 

			var initial = setTimeout(redirect, LOGOUT_TIMEOUT);

			$(document).click(function(event) {
				clearTimeout(initial);
				initial = setTimeout(redirect, LOGOUT_TIMEOUT);
			});
			
			// Aggiorno lo stato della CNTRL_SIZE per sapere se gestire pulsante "Setup Mode Disable"
			getCntrlSize();
      // TSK6116
      is_NoVRC();
			if ((isMapSafety) && (isNoVRC)) {
			  setInterval(getSetupModeStatus, 2000); 
      }
			
			// carico la configurazione degli assi
			$.getJSON('get?arm_mask', function(data) {
				arm_mask = data;			
				sessionStorage.setItem('arm_mask', JSON.stringify(arm_mask));
			});
		
			// carico la configurazione safe degli assi
			$.getJSON('get?arm_safe_mask', function(data) {
				arm_safe_mask = data;			
				sessionStorage.setItem('arm_safe_mask', JSON.stringify(arm_safe_mask));
			});

			// carico la posizione di calibrazione
			$.getJSON('get?arm_cal_sys', function(data) {
				cal_sys_pos = data;			
				sessionStorage.setItem('cal_sys_pos', JSON.stringify(cal_sys_pos));
			});

			// carico la posizione di calibrazione utente
			$.getJSON('get?arm_cal_usr', function(data) {
				cal_usr_pos = data;			
				sessionStorage.setItem('cal_usr_pos', JSON.stringify(cal_usr_pos));
			});

			//emoi_data = JSON.parse(sessionStorage.getItem('emoi_data'));
			//cal_sys_pos = JSON.parse(sessionStorage.getItem('cal_sys_pos'));		
			//cal_usr_pos = JSON.parse(sessionStorage.getItem('cal_usr_pos'));		
			//arm_mask = JSON.parse(sessionStorage.getItem('arm_mask'));				
			//arm_safe_mask = JSON.parse(sessionStorage.getItem('arm_safe_mask'));	

			var isSafe = hasSafeAxes(); 


			if (isSafeOperational() && isRecovery())		//Sono in Recovery mode
			{
				$('#safe_led_small_R').attr('src', '../images/led_yellow.png');
				$('#safe_led_small_N').attr('src', '../images/led_off.png');
				$('#safe_turn_set_warn_msg').show();
			}		
			else
			{																		//Sono in Normal mode
				$('#safe_led_small_R').attr('src', '../images/led_off.png');
				$('#safe_led_small_N').attr('src', '../images/led_green.png');
				$('#safe_turn_set_warn_msg').hide();
			}

			//tasto visualizzato da PC
			$('#logout_btn_h').click(function() {
				//logoff
				window.location.href = "home.html";

				$.ajax({
					type: "POST",
					url: 'service.html',
					username: 'logout',
					password: 'logout'
				});	
			});		
			
			
			$('#ack_format_li').click(function() { doAckFormat(); });

			$('#ack_down_li').click(function() { doDownloadPrj(); });
			
			if(isSafe && !isTPConnected()){
				$('#ack_restore_li').css("visibility", "visible");
				$('#ack_restore_btn').css("visibility", "visible");
				$('#ack_restore_li').click(function() { doRestoreCfg(); });
				
				$('#ack_backup_li').css("visibility", "visible");
				$('#ack_backup_btn').css("visibility", "visible");
				$('#ack_backup_li').click(function() {
					customConfirm('Download backup of the Safe configuration?','Backup', downloadBSONBackup);
				});

			}else{
				$('#ack_restore_li').css("visibility", "hidden");
				$('#ack_restore_btn').css("visibility", "hidden");
				$('#ack_backup_li').css("visibility", "hidden");
				$('#ack_backup_btn').css("visibility", "hidden");
			}
           
			if(!isSafe || !isTPConnected()){
				$('#move_to_cal_user').css("visibility", "hidden");
				$('#move_to_cal_user_btn').css("visibility", "hidden");
			}
			else{
				$('#move_to_cal_user').css("visibility", "visible");
				$('#move_to_cal_user_btn').css("visibility", "visible");
				$('#move_to_cal_user').click(function() { moveToSafeCalUser(); });
			}
			
			
			      
			if(!isSafe || !isMapSafety){
				$('#setup_mode_disable').css("visibility", "hidden");
				$('#setup_mode_disable_btn').css("visibility", "hidden");
			}
			else{
				$('#setup_mode_disable').css("visibility", "visible");
				$('#setup_mode_disable_btn').css("visibility", "visible");
				$('#setup_mode_disable').click(function() { setupModeDisableCommand(); });
			}
			
			
            

			$('#ack_skey_li').click(function() { doSafeKeyAcknowledge(); });
			//$('#ack_skey_btn').click(function() { doSafeKeyAcknowledge(); });

			$('#ack_mod1_li').click(function() { doModuleAcknowledge(1); });
			//$('#ack_mod1_btn').click(function() { doModuleAcknowledge(1); });

			$('#ack_mod2_li').click(function() { doModuleAcknowledge(2); });
			//$('#ack_mod2_btn').click(function() { doModuleAcknowledge(2); });

			$('#ack_mod3_li').click(function() { doModuleAcknowledge(3); });
			//$('#ack_mod3_btn').click(function() { doModuleAcknowledge(3); });

			$('#ack_mod4_li').click(function() { doModuleAcknowledge(4); });
			//$('#ack_mod4_btn').click(function() { doModuleAcknowledge(4); });

			$('#ack_modn_li').click(function() { doModuleAcknowledge(5); });
			//$('#ack_modn_btn').click(function() { doModuleAcknowledge(5); });

			$('#ack_firm_li').click(function() { doFirmwareAcknowledge(); });
			//$('#ack_firm_btn').click(function() { doFirmwareAcknowledge(); });

			if(isSafe){
				//registro l'evento click sui tasti laterali solo se il sistema ha assi safe
				//rendo visibili i tasti di sinistra
				$('#li_turn_set_R').show();
				$('#li_turn_set_R_btn').show();
				$('#li_turn_set_N').show();
				$('#li_turn_set_N_btn').show();

				$('#li_turn_set_R').click(function() { onRecoveryClick(); });

				$('#li_turn_set_N').click(function() { onNormalClick(); });

			}else{
				//no action, no assi safe
				// se non ci sono assi safe, disabilito i tasti laterali
				$('#li_turn_set_R').hide();
				$('#li_turn_set_R_btn').hide();
				$('#li_turn_set_N').hide();
				$('#li_turn_set_N_btn').hide();
				$('#safe_turn_set_warn_msg').hide();
			}	
				

		}	// safe > service
		
	} // safe
});

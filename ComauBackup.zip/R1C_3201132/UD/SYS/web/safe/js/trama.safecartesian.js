var safe = function ( containerId, readonly ) {
	
	(function($) {
		
		$.fn.goTo = function() {
			var offsetElement = $(this)[0].offsetTop;
			var parentOffset = $(this)[0].offsetParent;
			var bottomPadding = 200;
			if(parentOffset!= undefined){
				parentOffset=parentOffset.offsetTop;
			}else{
				parentOffset=0;
			}
			$('#content').animate({
				scrollTop: parentOffset + offsetElement - bottomPadding + 'px'
			}, 'slow');
			return this; // for chaining...
		}
	})(jQuery);
	
	(function($) {
		$.fn.preventFocus = function() {
			var element = $(this);
			window.setTimeout(function ()
			{
				element.focus();
			}, 0);
		}
	})(jQuery);
	
	var _colors = {
		forbiddenColor: "Gold",
		workColor: "rgba(0, 255, 0, 0.4)",

		getColor: function(type) {

			var c;

			if (type)
			{
				c = _colors.workColor;
			}
			else
			{
				c = _colors.forbiddenColor;
			}

			return c;
		}
	};

	var _cssClass = {
		dialog_hidden: "scr_dialog_hidden",
		dialog_shown: "scr_dialog_shown",
		dialog_content: "scr_dialog_content",
		dialog_title: "scr_dialog_title",
		dialog_formcell_20: "scr_dialog_formcell_20",
		dialog_formcell_25: "scr_dialog_formcell_25",
		dialog_formcell_33: "scr_dialog_formcell_33",
		dialog_formcell_50: "scr_dialog_formcell_50",
		dialog_formcell_75: "scr_dialog_formcell_75",
		dialog_formcell_100: "scr_dialog_formcell_100",
		dialog_form: "scr_dialog_form",
		dialog_formtitle: "scr_dialog_formtitle",
		dialog_formcell_left: "scr_dialog_formcell_left",
		dialog_formcell_right: "scr_dialog_formcell_right",
		dialog_button: "scr_dialog_button",

		menu_rowbutton: "scr_rowbutton",
		menu_rowindex: "scr_rowindex",
		menu_rowdeletebutton: "scr_rowdeletebutton",
		menu_rowdisabledbutton: "scr_rowbuttondisabled",

		menu_button: "scr_menubutton",
		title_button: "scr_titlebutton",
		info_button: "scr_infobutton",

		threedview_loadingtext: "scr_threedview_loadingtext",

		threedview_container: "scr_threedview_container"
	};

	var _callbacks = {
		dynamicVolume: {
			onDynamicVolumeAdded: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();

				itemJson["color"] = _colors.getColor(itemJson.flags.workType);

				if (editor != undefined)
					editor.addCube("dynamicarea", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onDynamicVolumeChanged: function(sender, item) {

				var itemJson = item.ToObjectJSON();

				itemJson["color"] = _colors.getColor(itemJson.flags.workType);

				if (editor != undefined)
					editor.updateCube("dynamicarea", itemJson);

				_navigator.setSomethingToSave(true);

//				var idx = parseInt(itemJson.id) + 1;
//
//				var notify = false;
//
//				if (itemJson.flags.enabled)
//				{
//					var old = _robot.GetOBD(idx);
//
//					if (!old && itemJson.flags.obdOn)
//					{
//						notify = true;
//					}
//
//					_robot.SetOBD(idx, itemJson.flags.obdOn);
//				}
//				else
//				{
//					_robot.SetOBD(idx, false);
//				}
//
//				if (notify)
//				{
//					_robot.NotifyTooManyActiveOBD();
//				}
			},
			onDynamicVolumeFlagsChange: function(sender, newValues) {


				if (editor != undefined) {
					if(newValues.hasOwnProperty("enabled")) {

						if( newValues.enabled ) {

							if (!editor.areWallVisible()) {
								editor.showWalls();
								editor.showCubes("forbiddenvolume");
							}
						} else {
							
							if (editor.areWallVisible()) {
								editor.hideWalls();
								editor.showCubes("forbiddenvolume");
							}
						}
					}
				}

				if (newValues.hasOwnProperty("obdOn"))
				{
					
					//A.R: TODO: è necessaria sta roba, sembra frutto di un copia e incolla???
					if (newValues.obdOn && _robot.HasRailSafe)
					{		
						var v = parseInt($('#zminId').val());

						if (v > -600)
						{
							_utility.MessageBox("Info", "OBD is active. Z (Min) will be set to -600 mm", true).Show();
							// alert("OBD is active. Z (Min) will be set to -600 mm");
							$('#zminId').val('-600');
						}					
					}			
				}

				var v = false;

				if (newValues.enabled)
				{
					v = newValues.obdOn;
				}
				
				if (v != _robot.GetOBD(0))
				{
					//A.R: TODO: sia dynamics che cella scrivono il flag alla posizione 0. non credo sia corretto
					_robot.SetOBD(0, v);
					_robot.NotifyTooManyActiveOBD();
				}

				_navigator.setSomethingToSave(true);
			}
		},
		wallCorner: {
			onWallCornerAdded: function(sender, item) {
				
				if (editor != undefined)
					editor.updateWallsCorners(sender.getItemsAsJsonArray());
				//VLMU_threeDView.roomThreeDView.UpdateBasement( sender.getItemsAsJsonArray() );

				_navigator.setSomethingToSave(true);
				
//				_managers.cellManager.updateTotalIndex(); // scommentare se si vuole abilitare la label con l'indice globale
			},
			onWallCornerChanged: function(sender, item) {
				
				if (editor != undefined)
					editor.updateWallsCorners(sender.getItemsAsJsonArray());
				//VLMU_threeDView.roomThreeDView.UpdateBasement( sender.getItemsAsJsonArray() );

				_navigator.setSomethingToSave(true);
			},
			onWallCornerRemoved: function(sender, item) {
				
				if (editor != undefined)
					editor.updateWallsCorners(sender.getItemsAsJsonArray());
				//VLMU_threeDView.roomThreeDView.UpdateBasement( sender.getItemsAsJsonArray() );

				_navigator.setSomethingToSave(true);
				
//				_managers.cellManager.updateTotalIndex(); // scommentare se si vuole abilitare la label con l'indice globale
			},
			onWallCornerCheckOrder: function(sender) {
				var sortedJSONArray = sender.getItemsAsJsonArray();
				sender.UpdateFromArrayJSON(sortedJSONArray);
				
				if (editor != undefined)
					editor.updateWallsCorners(sortedJSONArray);
				//VLMU_threeDView.roomThreeDView.UpdateBasement( sortedJSONArray );
				
				_navigator.setSomethingToSave(true);
			}
			
		},
		forbiddenVolume: {
			onForbiddenVolumeAdded: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.addCube("forbiddenvolume", itemJson);

				_navigator.setSomethingToSave(true);
				
//				_managers.cellManager.updateTotalIndex(); // scommentare se si vuole abilitare la label con l'indice globale

			},
			onForbiddenVolumeChanged: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.updateCube("forbiddenvolume", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onForbiddenVolumeRemoved: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.removeCube("forbiddenvolume", itemJson);

				_navigator.setSomethingToSave(true);
				
//				_managers.cellManager.updateTotalIndex(); // scommentare se si vuole abilitare la label con l'indice globale
			}
		},
		cellFlags: {
			onCellFlagsChange: function(sender, newValues) {

				if (editor != undefined) {
					if(newValues.hasOwnProperty("enabled")) {

						if( newValues.enabled ) {
							
							if (!editor.areWallVisible()) {
								editor.showWalls();
								editor.showCubes("forbiddenvolume");
							}

						} else {
							
							if (editor.areWallVisible()) {
								editor.hideWalls();
								editor.hideCubes("forbiddenvolume");
							}
						
						}
					}
				}

				if (newValues.hasOwnProperty("obdOn"))
				{
					if (newValues.obdOn && _robot.HasRailSafe)
					{		
						var v = parseInt($('#zminId').val());

						if (v > -600)
						{
							_utility.MessageBox("Info", "OBD is active. Z (Min) will be set to -600 mm", true).Show();
							// alert("OBD is active. Z (Min) will be set to -600 mm");
							$('#zminId').val('-600');
						}					
					}			
				}

				var v = false;

				if (newValues.enabled)
				{
					v = newValues.obdOn;
				}
				
				if (v != _robot.GetOBD(0))
				{
					//A.R: TODO: sia dynamics che cella scrivono il flag alla posizione 0. non credo sia corretto
					_robot.SetOBD(0, v);
					_robot.NotifyTooManyActiveOBD();
				}

				_navigator.setSomethingToSave(true);
			}
		},
		cellLayout: {
			onCellLayoutChange: function(sender, newValues) {

				/*
				 * if (!isNaN(newValues.zmin) || !isNaN(newValues.zmax)) {
				 * alert("Invalid value"); 
				 * newValues.zmin = sender.elementsArray[0]; 
				 * newValues.zmax = sender.elementsArray[1]; 
				 * return; }
				 */
				var v = $('#cellObdId').val();
				if( !isNaN(newValues.zmin)) {
					if (newValues.zmin > -600)
					{
	
						if (v === "true")
						{
							_utility.MessageBox("Info", "OBD is active. Z (Min) will be set to -600 mm", true).Show();
							// alert("OBD is active. Z (Min) will be set to -600 mm");
							newValues.zmin = -600;
							sender.setValues(newValues.zmin, newValues.zmax);
						}
					}
				
					if(newValues.zmin >= -40) {
						_utility.MessageBox("Info", "Z (Min) can't be greater or equal to -40", true).Show();
						// alert("Z (Min) can't be greater or equal to -40");
	
						newValues.zmin = -41;
						sender.setValues(newValues.zmin, newValues.zmax);
					}				
				} else {
					
					_utility.MessageBox("Info", "Only numeric values are allowed for this field", true).Show();
					
					if(v === "true"){
						newValues.zmin = -600;
					}else{
						newValues.zmin = -41;
					}
					sender.setValues(newValues.zmin, newValues.zmax);
				}
				
				if (!isNaN(newValues.zmax)) {
					if(newValues.zmax <= 0) {
	
						_utility.MessageBox("Info", "Z (Max) can't be less or equal to zero", true).Show();
						// alert("Z (Max) can't be less or equal to zero");
	
						newValues.zmax = 3000;
						sender.setValues(newValues.zmin, newValues.zmax);
					}
				} else {
					_utility.MessageBox("Info", "Only numeric values are allowed for this field", true).Show();

					newValues.zmax = 3000;
					sender.setValues(newValues.zmin, newValues.zmax);
				}

				if (editor != undefined)
					editor.updateWallsCornersZMinMax(newValues.zmin, newValues.zmax);

				_navigator.setSomethingToSave(true);
			}
		},
		monitoringPoint: {
			onMonitoringPointAdded: function(sender, item) {

				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateMonitoringPoints(itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onMonitoringPointChanged: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateMonitoringPoints(itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onMonitoringPointRemoved: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateMonitoringPoints(itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			}
		},
		axisMonitoringPoint: {
			onAxisPointAdded: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateAxisMonitoringPoints(itemsArray[0], sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onAxisPointChanged: function(sender, item) {
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateAxisMonitoringPoints(itemsArray[0], sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onAxisPointRemoved: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateAxisMonitoringPoints(itemsArray[0], sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onElbowPointChanged: function(sender, item) {
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateElbowMonitoringPoints(itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			}
		},
		
		toolset1Point: {
			onToolset1PointAdded: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateToolsetPoints(1, itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			},
			onToolset1PointChanged: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined) {
					editor.updateToolsetPoints(1, itemsArray, sender.getColor());
					editor.updateToolsetPointsVisibility(1, item.ToObjectJSON().flags.enabled);
				}

				_navigator.setSomethingToSave(true);
			},
			onToolset1PointRemoved: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateToolsetPoints(1, itemsArray, sender.getColor());

				_navigator.setSomethingToSave(true);
			}
		},
		toolset2Point: {
			onToolset2PointAdded: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateToolsetPoints(2, itemsArray, sender.getColor());
				
				_navigator.setSomethingToSave(true);
			},
			onToolset2PointChanged: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined) {
					editor.updateToolsetPoints(2, itemsArray, sender.getColor());
					editor.updateToolsetPointsVisibility(2, item.ToObjectJSON().flags.enabled);
				}

				_navigator.setSomethingToSave(true);
			},
			onToolset2PointRemoved: function(sender, item) {
				
				var itemsArray = sender.getItemsAsJsonArray();
				
				if (editor != undefined)
					editor.updateToolsetPoints(2, itemsArray, sender.getColor());
				
				_navigator.setSomethingToSave(true);
			}
		},
		functionalSpaceA: {
			onFunctionalSpaceAAdded: function(sender, item) {
				
				//TODO: utilizzare quando disponibile un updateAll che ricrea la lista di cubi a partire dalla nuova lista di elementi
//				var itemsArray = sender.getItemsAsJsonArray();
//				
//				_threeDView.roomThreeDView.UpdateAllCube("functionalspace", itemsArray);
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.addCube("functionalspace", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onFunctionalSpaceAChanged: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.updateCube("functionalspace", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onFunctionalSpaceARemoved: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.removeCube("functionalspace", itemJson);

				_navigator.setSomethingToSave(true);
			}
		},
		functionalSpaceB: {
			onFunctionalSpaceBAdded: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.addCube("functionalspace2", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onFunctionalSpaceBChanged: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.updateCube("functionalspace2", itemJson);

				_navigator.setSomethingToSave(true);
			},
			onFunctionalSpaceBRemoved: function(sender, item) {
				
				var itemJson = item.ToObjectJSON();
					itemJson["color"] = sender.getColor();

				if (editor != undefined)
					editor.removeCube("functionalspace2", itemJson);

				_navigator.setSomethingToSave(true);
			}
		},
		
		//callback generiche per flags che non eseguono azioni specifiche
		genericFlags: {
			onGenericFlagsChange: function (sender, newValues) {
				_navigator.setSomethingToSave(true);
			}
		}
	};

	var Navigator = function ( rootMenuContent ) {

		var _layout = undefined;
		var _pageMenu;
		var _pageContent;
		var _pageTitle;
		var _backbutton;
		var _backButtonContent;

		var _rootMenu;
		var _rootMenuContent = rootMenuContent;
		var _pages = {};
		var _extraButtons = [];
		var _saveButton = undefined;
		var _somethingToSave = false;

		var _backButtonText = "Back";

		var privateInitialize = function ( ) {

			privateInitializeLayout();

			privateInitializePages();
		};

		var privateInitializeLayout = function () {

			_pageMenu = $( '<div id="scr_pagemenu" class="scr_cell_100">' );

			_pageContent = $( '<div id="scr_pagecontent" class="scr_cell_100 scr_height_fill"/>' );

			_pageTitle = $( '<h6 id="scr_pagetitle" style="font-size:13px;">' );

			_backbutton = $( '<div id="scr_backbutton" class="scr_cell_33 scr_height_50">' );

			_backButtonContent = [

							$( '<div>' )

								.append( privateBuildBackButton() )

							];			

			_layout = $('<div id="scr_layout" class="scr_cell_100 scr_height_fill"/>')

					.append( $( '<div class="scr_cell_25 scr_height_fill">' )

						.append( _backbutton )

						.append($( '<div class="scr_cell_50 scr_height_50">' )

							.append( _pageTitle )
						)
						.append($( '<div id="scr_infoButton" style="text-align: center; padding: 5px;">' ))

						.append( _pageMenu )
					)

					.append( $( '<div class="scr_cell_75 scr_height_fill">' )
					
						.append( _pageContent )
					)
			;
		};

		var privateBuildInfoButton = function (text) {

			if (text != undefined) {
				var infoButton = $('<input type="button" class="' + _cssClass.info_button + '" value="i" />')

					.click(function (event) {
						//showInfoWindow
						_utility.MessageBox("Info", text, true).Show();
					}).prop('hidden', false);

				return infoButton;
			}
			return "";
		};

		var privateInitializePages = function () {

			_rootMenu = [];

			_pages[_backButtonText] = {

				menu: _rootMenu,
				content: _rootMenuContent,
				title: "",
				showBack: false
			};
		};

		var privateBuildNavButtonCell = function ( title, clickCallback, icon ) {

			var iconStyle = '';
			
			if (icon != undefined) {
				iconStyle += 'style="background-image: url(' + icon + ');' +
				'background-repeat: no-repeat; background-position: left;" ';
			}
			
			var element = $( '<div class="scr_cell_100">' )

				.append( $( '<input ' + iconStyle + ' type="button" class="scr_menubutton" value="' + title + '">' )
					
					.click( function (event) { 

						if ( clickCallback !== undefined ) {

							clickCallback( title );
						}

					} )			
			);

			return element;
		};


		var privateBuildBackArrow = function () {

			var arrow = $( '<input type="button" class="scr_leftarrow_blue"> value="' + _backButtonText + '">')
				.click( function (event) { 

					privateOpenPage( _backButtonText );
				} );
			return arrow;
		};


		var privateBuildBackButton = function () {

			var btn = $( '<input type="button" class="scr_backbutton" value="' + _backButtonText + '">' )
				.click( function (event) { 

					privateOpenPage( _backButtonText );
				} );

			return btn;
		};

		var privateOpenPage = function ( pageTitle ) {

			var menuTableId = $(_pageMenu).attr('id');
			var menuTable = document.getElementById( menuTableId );
			if ( menuTable !== null ) { 				
				menuTable.innerHTML = ""; 
				$(_pageMenu).append( _pages[pageTitle].menu );
			}

			// if ( _pages[pageTitle].showBack ) {
				var contentId = $(_pageContent).attr('id');
				var content = document.getElementById( contentId );
				if ( content !== null ) { 	
					content.innerHTML = "";
					$(_pageContent).append( _pages[pageTitle].content );
				}
			// }

			var titleId = $(_pageTitle).attr('id');
			var title = document.getElementById( titleId );
			if ( title !== null ) {
				title.innerHTML = _pages[pageTitle].title;
			}

			var backId = $(_backbutton).attr('id');
			var back = document.getElementById( backId );
			if (back !== null) {
				back.innerHTML = "";
				if ( _pages[pageTitle].showBack ) {
					$(_backbutton).append( _backButtonContent );
				}
			}

			var infoContainer = $('#scr_infoButton');
			if (infoContainer != null) {
				infoContainer.html("");
				var infoKey = _pages[pageTitle].title.replace(/\s+/g, '');
				var info = _popupUtility.InfoMessages().getInfoMessage(infoKey);
				if (info != undefined && info != "") {
					infoContainer.append(privateBuildInfoButton(info));
				}
			}

		};

		var privateAddPage = function ( pageName, elementsArray, contentElement, isEnabled, iconPath ) {

			/** ****** Create page menu ********* */

			var pageMenuContent = [];

			for ( var i = 0; i < elementsArray.length; i++ ) {

				pageMenuContent.push( elementsArray[i][0] );
			}

			/** ****** Store menu into dictionary ********* */

			_pages[pageName] = {

				menu: pageMenuContent,
				content: contentElement,
				title: pageName,
				showBack: true
			};

			/** ****** Add to root menu ********* */

			var addedCell = privateBuildNavButtonCell( pageName, privateOpenPage, iconPath );
			var pageBox = addedCell.children().first();
			pageBox.attr("disabled", !isEnabled);
			_rootMenu.push( addedCell );

			_pages[_backButtonText] = {

				menu: _rootMenu,
				content: _rootMenuContent,
				title: "",
				showBack: false
			};
		};

		var privateAddCustomButton = function ( buttonText, callback, isEnabled, iconPath) {

			var addedCell = privateBuildNavButtonCell( buttonText, callback, iconPath );
			var pageBox = addedCell.children().first();
			pageBox.attr("disabled", !isEnabled);
			_extraButtons.push( addedCell );
		};

		var privateGetLayout = function () {

			for( var i = 0; i < _extraButtons.length; i++ ) {

				_rootMenu.push( _extraButtons[i] );
			}

			_pages[_backButtonText] = {

				menu: _rootMenu,
				content: _rootMenuContent,
				title: "",
				showBack: false
			};

			$(_pageMenu).append( _pages[_backButtonText].menu );
			$(_pageContent).append( _pages[_backButtonText].content );

			return _layout;
		};

		var privateAddSaveButton = function ( buttonText, callback, iconPath ) {

			var saveButtonCell = privateBuildNavButtonCell( buttonText, function() {

				privateSetSomethingToSave(false);

				callback();
			}, iconPath );

			_saveButton = saveButtonCell.children().first();

			// _extraButtons.push( _saveButton );
			_extraButtons.push( saveButtonCell );

			privateSetSomethingToSave(false);
		};

		var privateSetSomethingToSave = function ( somethingToSave ) {

			if ( _saveButton != undefined ) {

				_somethingToSave = somethingToSave;

				if ( _somethingToSave ) {

					_saveButton.attr("disabled", false);

				} else {

					_saveButton.attr("disabled", false);
				}
			}
		};

		var privateGetSomethingToSave = function () {

			return _somethingToSave;
		};

		var privateAddSpace = function () {

			var element = $( '<div class="scr_space_cell_100">' )

				.append( $( '<input type="button" class="scr_menubutton" value="' + title + '">' )
					.css({
						'visibility' : 'hidden'
						})
				);

			_extraButtons.push(element);
		};

		privateInitialize();

		return {

			// Properties
			layout: privateGetLayout,

			// Methods
			addPage: privateAddPage,
			addCustomButton: privateAddCustomButton,
			addSaveButton: privateAddSaveButton,
			addSpace: privateAddSpace,
			
			setSomethingToSave: privateSetSomethingToSave,
			getSomethingToSave: privateGetSomethingToSave
		};
	};
	/*
	var _threeDView = function() {

		var _readyToStartCallback = undefined;

		var _containers = {

			roomThreeDViewContainer: $('<div class="' + _cssClass.threedview_container + '" >')
										.append( $('<div class="' + _cssClass.threedview_loadingtext + '"><p>Loading...</p></div>') ),
		
			toolThreeDViewContainer: $('<div class="' + _cssClass.threedview_container + '" >')
										.append( $('<div class="' + _cssClass.threedview_loadingtext + '"><p>Loading...</p></div>') )
		};
		
		var RoomThreeDView = function ( container ) {
		
			var _containerElement = $(container);
			
			var _settings = {

				sceneEdgeSize:  50000,
				zminCoordinate: 0,
				zmaxCoordinate: 3000,
				scalingFactor:  1.0,
				robotmodelname: "robotmodel"
			};

			var _threedEngine = {

				mainView: {
					scene: undefined,
					floorScene: undefined,
					renderer: undefined,
					camera: undefined
				},

				worldAxisView: {
					scene: undefined,
					renderer: undefined,
					camera: undefined
				}
			};

			var _sceneComponents = {

				robotModel: undefined,
				groundPlane: undefined,
				sceneAxis: undefined,
				lights: undefined,	
				componentsGroup: undefined
			};

			var _boundingBoxBSP;

			var _onReadyToStartCallback = null;
			var _resourcesLoaded = false;

			var privateAnimate = function() {

				requestAnimationFrame( privateAnimate );

				_controls3D.update();

				_threedEngine.worldAxisView.camera.position.copy( _threedEngine.mainView.camera.position );
				_threedEngine.worldAxisView.camera.position.sub( _controls3D.target );
				_threedEngine.worldAxisView.camera.position.setLength( 150 );

				_threedEngine.worldAxisView.camera.lookAt( _threedEngine.worldAxisView.scene.position );

				privateRender();
			};

			var privateRender = function() {

				privateUpdateViewSizeWhenNeeded();

				if(_threedEngine.mainView.renderer != undefined){
				  _threedEngine.mainView.renderer.clear();
				  _threedEngine.mainView.renderer.render( _threedEngine.mainView.floorScene, _threedEngine.mainView.camera );
				  _threedEngine.mainView.renderer.clearDepth();
				  //_threedEngine.mainView.renderer.render( _threedEngine.mainView.scene, _threedEngine.mainView.camera );
				  
				  //_threedEngine.worldAxisView.renderer.render( _threedEngine.worldAxisView.scene, _threedEngine.worldAxisView.camera );
				}
			};

			var privateUpdateZMinMax = function (zmin, zmax) {

				if(!_robot.IsTPConnected()){

					// Update internal values
					_settings.zminCoordinate = zmin;
					_settings.zmaxCoordinate = zmax;
	
					// Update floor position
					_sceneComponents.groundPlane.position.z = _settings.zminCoordinate;
	
					// Update axis length
					length = _settings.sceneEdgeSize / 2;
					var vertices = new Float32Array( [
						-length, 0, 0,  length, 0, 0,
						0, -length, 0,  0, length, 0,
						0, 0, _settings.zminCoordinate,  0, 0, length
					] );
					_sceneComponents.sceneAxis.geometry.attributes.position = new THREE.BufferAttribute( vertices, 3 );
					_sceneComponents.sceneAxis.geometry.attributes.needsUpdate = true;
	
					// Update BSP box
					var boxHeight = _settings.zmaxCoordinate - _settings.zminCoordinate;
					var perimeterGeom = new THREE.BoxGeometry(_settings.sceneEdgeSize, _settings.sceneEdgeSize, boxHeight);
						perimeterGeom.applyMatrix( new THREE.Matrix4().makeTranslation( 0, 0, boxHeight / 2 + _settings.zminCoordinate ) );
	
					_boundingBoxBSP = new ThreeBSP(perimeterGeom);
	
					privateWallManager.RefreshWalls();
					privateCubeManager.RefreshCubes();
				}
			};

			var privateBuildThreeDEngine = function () {

				var threeDEngineComponentsBuilder = {

					BuildRenderer: function () {

						if(!_robot.IsTPConnected()){
							var renderer = new THREE.WebGLRenderer( { precision:"lowp", antialias: true, alpha: true } );
							renderer.setSize(650, 600);			
							renderer.setClearColor(0x000000, 0);
							renderer.autoClear = false;

							return renderer;
						}
						return null;
					},

					BuildPerspectivePlaneCamera: function () {

						var camera = new THREE.PerspectiveCamera( 70, 650 / 600, .1, 100000 );
						camera.position.x = 0;
						camera.position.y = 0;
						camera.position.z = 6000;
						camera.up.x = 0;
						camera.up.y = 0;
						camera.up.z = 1;

						camera.lookAt(new THREE.Vector3(0,0,_settings.zminCoordinate));

						return camera;
					},

					Build3DControls: function ( camera, renderer ) {

						var controls3D = new THREE.OrbitControls( camera, renderer.domElement );
						controls3D.damping = 0.2;
						controls3D.maxPolarAngle = Math.PI/2 * 89/90; 
						controls3D.minDistance = 0;
						controls3D.maxDistance = 40000;	

						return controls3D;
					}
				};

				_threedEngine.mainView.renderer = threeDEngineComponentsBuilder.BuildRenderer();
				_threedEngine.mainView.camera = threeDEngineComponentsBuilder.BuildPerspectivePlaneCamera();
				_controls3D = threeDEngineComponentsBuilder.Build3DControls( _threedEngine.mainView.camera, _threedEngine.mainView.renderer );
			};

			var privateBuildBaseScene = function () {

				var baseSceneUtility = {

					BuildGroundPlane: function () {

						var material = new THREE.MeshBasicMaterial( {color:0xaaa89b, transparent: true, opacity: 1} );


						_sceneComponents.groundPlane = new THREE.Mesh(new THREE.PlaneBufferGeometry(_settings.sceneEdgeSize, _settings.sceneEdgeSize), material);
						_sceneComponents.groundPlane.material.side = THREE.DoubleSide;
						_sceneComponents.groundPlane.position.z = _settings.zminCoordinate;

						return _sceneComponents.groundPlane;
					},

					BuildLights: function () {

						var topLight = new THREE.PointLight(0xffffff);
						topLight.position.set(0,0,100000);

						var aLight = new THREE.PointLight(0xf0f0f0);
						aLight.position.set(-100000,-100000,1);

						var bLight = new THREE.PointLight(0xf0f0f0);
						bLight.position.set(100000,-100000,1);

						var cLight = new THREE.PointLight(0xf0f0f0);
						cLight.position.set(100000,100000,1);

						var dLight = new THREE.PointLight(0xf0f0f0);
						dLight.position.set(-100000,100000,1);

						var lights = new THREE.Object3D();
						lights.add(topLight);
						lights.add(aLight);
						lights.add(bLight);
						lights.add(cLight);
						lights.add(dLight);

						return lights;
					},

					BuildSceneAxis: function () {

						length = (_settings.sceneEdgeSize / 2) || 1;

						var vertices = new Float32Array( [
							-length, 0, 0,  length, 0, 0,
							0, -length, 0,  0, length, 0,
							0, 0, _settings.zminCoordinate,  0, 0, length
						] );

						var colors = new Float32Array( [
							1, 0, 0,  1, 0.6, 0,
							0, 1, 0,  0.6, 1, 0,
							0, 0, 1,  0, 0.6, 1
						] );

						var geometry = new THREE.BufferGeometry();
						geometry.addAttribute( 'position', new THREE.BufferAttribute( vertices, 3 ) );
						geometry.addAttribute( 'color', new THREE.BufferAttribute( colors, 3 ) );

						var material = new THREE.LineBasicMaterial( { vertexColors: THREE.VertexColors } );

						var axes = new THREE.Line( geometry, material, THREE.LinePieces );

						return axes;
					},

					BuildRobotModel: function () {

						var bBox = new THREE.Box3().setFromObject(_sceneComponents.robotModel);

						var boxW = bBox.max.y - bBox.min.y;

						// var scale = (1550) / boxW;
						var scale = 797.35104780;

						_sceneComponents.robotModel.scale.x = scale;
						_sceneComponents.robotModel.scale.y = scale;
						_sceneComponents.robotModel.scale.z = scale;

						// _sceneComponents.robotModel.rotation.z = Math.PI / 2;

						_sceneComponents.robotModel.updateMatrix();

						return _sceneComponents.robotModel;
					},

					AddWorldAxes: function () {

						function privateBuildHtmlComponent() {

							var htmlComponent = $('<div class="scr_threedview_worldaxis" />')
							.css({
								'width' : String(edge) + "px",
								'height' : String(edge) + "px",
								'background-color' : 'transparent',
								'border' : 'none',
								'margin' : '5px',
								'padding' : '0px',
								'position' : 'absolute',
								'left' : '0px',
								'bottom' : '0px',
								'z-index' : '100'
							});

							return htmlComponent;						
						};

						function privateBuildWorldAxes3DEngine() {

							// Renderer
							_threedEngine.worldAxisView.renderer = new THREE.WebGLRenderer( { precision:"lowp", antialias: true, alpha: true } );
							_threedEngine.worldAxisView.renderer.setClearColor( 0x000000, 0 );
							_threedEngine.worldAxisView.renderer.setSize( edge, edge );

							// Camera
							_threedEngine.worldAxisView.camera = new THREE.PerspectiveCamera( 25, edge / edge, 1, 500 );
							_threedEngine.worldAxisView.camera.up = _threedEngine.mainView.camera.up;

							// Scene
							_threedEngine.worldAxisView.scene = new THREE.Scene();						
						};

						function privatePopulateWorldAxisScene() {

							function privateBuildArrowAxes(lenght) {

								function buildArrow(x, y, z, color) {

									var headRotMatrix = new THREE.Matrix4();
									if( x > 0 ) {
										headRotMatrix.makeRotationZ((- Math.PI / 2));
									}
									if( z > 0 ) {
										headRotMatrix.makeRotationX((  Math.PI / 2));
									}

									var materialline = new THREE.LineBasicMaterial({color: color});
									var geometryline = new THREE.Geometry();
										geometryline.vertices.push(
											new THREE.Vector3( 0, 0, 0 ),
											new THREE.Vector3( x, y, z )
										);
									var line = new THREE.Line(geometryline, materialline);
									var materialcone = new THREE.MeshBasicMaterial( {color: color} );
									var geometrycone = new THREE.CylinderGeometry( 0, 2, 5 );
										geometrycone.applyMatrix(headRotMatrix);
									var cone = new THREE.Mesh( geometrycone, materialcone );		
										cone.position.x = x;
										cone.position.y = y;
										cone.position.z = z;

									var arrow = new THREE.Object3D();
									arrow.add(line);
									arrow.add(cone);

									return arrow;
								};

								var arrowsGroup = new THREE.Object3D();

								arrowsGroup.add(buildArrow(lenght, 0, 0, 0xff0000)); // X
								arrowsGroup.add(buildArrow(0, lenght, 0, 0x00ff00)); // Y
								arrowsGroup.add(buildArrow(0, 0, lenght, 0x0000ff)); // Z

								return arrowsGroup;
							}

							_threedEngine.worldAxisView.scene.add( privateBuildArrowAxes(30) );
						};

						var edge = 100;

						privateBuildWorldAxes3DEngine();
						privatePopulateWorldAxisScene();

						var htmlComponent = privateBuildHtmlComponent();
						$(_containerElement).append(htmlComponent);
						$(htmlComponent).append(_threedEngine.worldAxisView.renderer.domElement);
					}			
				};
				
				if(!_robot.IsTPConnected()){
					_sceneComponents.groundPlane = baseSceneUtility.BuildGroundPlane();
					_sceneComponents.sceneAxis = baseSceneUtility.BuildSceneAxis();
					_sceneComponents.robotModel = baseSceneUtility.BuildRobotModel();
					_sceneComponents.lights = baseSceneUtility.BuildLights();
	
					_sceneComponents.componentsGroup = new THREE.Object3D();
					_sceneComponents.componentsGroup.add( _sceneComponents.sceneAxis );
					_sceneComponents.componentsGroup.add( _sceneComponents.lights );
					_sceneComponents.componentsGroup.add( _sceneComponents.robotModel );
	
					_threedEngine.mainView.scene = new THREE.Scene();
					_threedEngine.mainView.scene.add( _sceneComponents.componentsGroup );
					baseSceneUtility.AddWorldAxes();
	
					_threedEngine.mainView.floorScene = new THREE.Scene();
					_threedEngine.mainView.floorScene.add( _sceneComponents.groundPlane );
					_threedEngine.mainView.floorScene.add( baseSceneUtility.BuildLights() );

					privateUpdateZMinMax(_settings.zminCoordinate, _settings.zmaxCoordinate);
				}
			};

			var privateCubeManager = function () {

				var _cubes = {};
				var _cubesJsonObjects = {};
				var _cubesGroup = new THREE.Object3D();

				var privateAddCube = function (groupKey, cubeJsonObject) {
					
					var cubeId = (groupKey.toString() + cubeJsonObject.id.toString()).replace(/\s+/g, '').toLowerCase();

					if ( !_cubes.hasOwnProperty(cubeId) ) {

						_cubes[cubeId] = privateBuildCubeMesh(cubeJsonObject);

						_cubesGroup.add(_cubes[cubeId]);
						
						privateStoreCubeJsonObject(groupKey, cubeJsonObject);

						privateRender();
					}
				};

				//TODO: metodi da non utilizzare per implementazioni future
				
				var privateUpdateAllCubesByGroup = function (groupkey, cubeJsonArray) {
					
					clearCubes(groupkey);
					
					//TODO: Riaggiungere tutti gli elementi dall'array passato come parametro
					
				};
				
				function clearCubes(groupkey){
					
					//TODO: Rimuovere tutti gli elementi di quello specifico groupkey

					//_scene.remove(_toolMonitoringPointsGroup);
					//while(_toolMonitoringPointsGroup.children.length > 0) {
					//	_toolMonitoringPointsGroup.children.pop();
					//}
										
				};
				
				//TODO: fine metodi da non utilizzare
				
				var privateUpdateCube = function (groupKey, cubeJsonObject) {

					var cubeId = (groupKey.toString() + cubeJsonObject.id.toString()).replace(/\s+/g, '').toLowerCase();

					if(_cubes.hasOwnProperty(cubeId)) {

						_cubesGroup.remove(_cubes[cubeId]);

						_cubes[cubeId] = privateBuildCubeMesh(cubeJsonObject);
						_cubes[cubeId].visible = cubeJsonObject.flags.enabled;

						_cubesGroup.add(_cubes[cubeId]);

						privateUpdateStoredCubeJsonObject(groupKey, cubeJsonObject);

						privateRender();
					}
				};

				var privateRemoveCube = function (groupKey, cubeJsonObject) {

					var cubeId = (groupKey.toString() + cubeJsonObject.id.toString()).replace(/\s+/g, '').toLowerCase();

					if(_cubes.hasOwnProperty(cubeId)) {

						_cubesGroup.remove(_cubes[cubeId]);

						delete _cubes[cubeId];

						privateRemoveStoredCubeJsonObject(groupKey, cubeJsonObject);
						
						//TSK1357: compacting items id
						compactCubesByGroup(groupKey);
						
						privateCompactStoredCubeJsonObject(groupKey);
						
						refreshCubesByGroup(groupKey);
					}
				};
				
				function compactCubesByGroup(groupKey){
					//compacting cubes id
					var i=0;
					
					for ( var cube in _cubes ) {
						if(cube.startsWith(groupKey.toString())){
							if ( _cubes.hasOwnProperty(cube) ) {
								var newCube = _cubes[cube];
								delete _cubes[cube];
								_cubes[groupKey.toString()+i] = newCube;
								i++;
							}
						}
					}
				};
				
				function refreshCubesByGroup(groupKey){
					if(_cubesJsonObjects.hasOwnProperty(groupKey)){

						for ( var i=0; i < _cubesJsonObjects[groupKey].length; i++ ) {

							privateUpdateCube( groupKey, _cubesJsonObjects[groupKey][i] );

						}
					}
				
				};

				var privateStoreCubeJsonObject = function(groupKey, cubeJsonObject) {

					if ( !_cubesJsonObjects.hasOwnProperty(groupKey) ) {

						_cubesJsonObjects[groupKey] = [];
					}

					_cubesJsonObjects[groupKey].push(cubeJsonObject);
				};

				var privateUpdateStoredCubeJsonObject = function(groupKey, cubeJsonObject) {

					for ( var i=0; i < _cubesJsonObjects[groupKey].length; i++ ) {

						if ( _cubesJsonObjects[groupKey][i].id === cubeJsonObject.id ) {

							_cubesJsonObjects[groupKey][i] = cubeJsonObject;
							return;
						}
					}
				};

				var privateRemoveStoredCubeJsonObject = function(groupKey, cubeJsonObject) {

					for ( var i=0; i < _cubesJsonObjects[groupKey].length; i++ ) {

						if ( _cubesJsonObjects[groupKey][i].id === cubeJsonObject.id ) {

							//this causes a bug //_cubesJsonObjects[groupKey] =
							_cubesJsonObjects[groupKey].splice(i, 1);
							return;
						}
					}
				};

				//TSK1357: compacting items id
				function privateCompactStoredCubeJsonObject(groupKey){
					
					//compacting cubes id and cubes name
					var x=0;
					if ( _cubesJsonObjects.hasOwnProperty(groupKey) ) {
						for ( var i=0; i < _cubesJsonObjects[groupKey].length; i++ ) {
							_cubesJsonObjects[groupKey][i].id = i;
							//il nome delle aree nel 3d non deve essere modificato...
//							var name = _cubesJsonObjects[groupKey][i].name;
//							if(!name.endsWith("idx:"+(i+1))){
//								var res = name.split(" ");
//								res[res.length-1] = "idx:"+(i+1);
//								_cubesJsonObjects[groupKey][i].name = res.join(" "); 
//							}
							x++;
						}
					}
				};
				
				var privateBuildCubeMesh = function (cubeJsonObject) {

					function buildTexturedMaterial(text, backColor) {

						// create a canvas element
						var canvas = document.createElement('canvas');
						var context = canvas.getContext('2d');
						context.font = "40px Arial";

						var textureEdge = context.measureText(text).width;

						canvas.width = textureEdge * 1.5;
						canvas.height = textureEdge * 1.5;
						context = canvas.getContext("2d");
						context.font = "40pt Arial";

						context.textAlign = "center";
						context.textBaseline = "middle";
						context.fillStyle = backColor;
						context.fillRect(0, 0, canvas.width, canvas.height);
						context.fillStyle = 'black';
						context.fillText(text, canvas.width / 2, canvas.height / 2);
						context.lineWidth=5;
						context.beginPath();
						context.moveTo(0,0);
						context.lineTo(canvas.width,0);
						context.lineTo(canvas.width,canvas.height);
						context.lineTo(0,canvas.height);
						context.closePath();
						context.stroke();

						// canvas contents will be used for a texture
						var texture = new THREE.Texture(canvas);
						texture.needsUpdate = true;

						var material = new THREE.MeshBasicMaterial( {map: texture, transparent: true} );

						return material;
					};

					function buildGeometry(cubeProperies) {

						var geometry = new THREE.BoxGeometry(cubeProperies.width / _settings.scalingFactor, cubeProperies.depth / _settings.scalingFactor, cubeProperies.height / _settings.scalingFactor);
						geometry.applyMatrix( new THREE.Matrix4().makeTranslation( (cubeProperies.width / _settings.scalingFactor)/2, (cubeProperies.depth / _settings.scalingFactor)/2, (cubeProperies.height / _settings.scalingFactor)/2 ) );
						
						var cornerPinGeometry = new THREE.SphereGeometry( 50, 16, 16);
						geometry.merge(cornerPinGeometry);

						geometry.applyMatrix( new THREE.Matrix4().makeRotationX( (cubeProperies.roll * Math.PI) / 180 ) );
						geometry.applyMatrix( new THREE.Matrix4().makeRotationY( (cubeProperies.pitch * Math.PI) / 180 ) );
						geometry.applyMatrix( new THREE.Matrix4().makeRotationZ( (cubeProperies.yaw * Math.PI) / 180 ) );

						geometry.applyMatrix( new THREE.Matrix4().makeTranslation( cubeProperies.x / _settings.scalingFactor, cubeProperies.y / _settings.scalingFactor, (cubeProperies.z / _settings.scalingFactor) ) );

						return geometry;
					};

					function cutUnderFloorPlane(geometry) {

						if(!_robot.IsTPConnected()){
							var geometryThree = geometry;
							var geometryBSP = new ThreeBSP(geometry);
	
							var resultBSP = geometryBSP.intersect(_boundingBoxBSP);
						
							var newGeometry = resultBSP.toGeometry();
							return newGeometry;
						}
						return undefined;
					};

					function buildMesh(geometry, material) {

						return (new THREE.Mesh( geometry, material ));
					};

					var material = buildTexturedMaterial(cubeJsonObject.name, cubeJsonObject.color);
					var mesh = null;

					if( material != null ) {

						cubeGeometry = buildGeometry(cubeJsonObject.value);
						if(privateWallManager.AreWallsVisible()) {
							cubeGeometry = cutUnderFloorPlane(cubeGeometry);	
						}
						mesh = buildMesh(cubeGeometry, material);
					}

					return mesh;
				};

				var privateShowHideCubesByGroupKey = function(groupKey, show) {

					for ( var cube in _cubes ) {

						if ( cube.indexOf(groupKey) > -1 ) {

							_cubes[cube].visible = show;
						}
					}
				};
				
				//TODO: creare un metodo "areCubeVisibleByGroupKey" che restituisca true se i cubi di quel gruppo sono visibili

				function privateRefreshCubes() {

					for ( var groupKey in _cubesJsonObjects ) {

						for ( var i=0; i < _cubesJsonObjects[groupKey].length; i++ ) {

							privateUpdateCube( groupKey, _cubesJsonObjects[groupKey][i] );
						}
					}

					privateRender();
				};

				return {

					Get3DGroup: function () { return _cubesGroup; },

					AddCube: function (groupKey, cubeJsonObject) { privateAddCube(groupKey, cubeJsonObject); },
					UpdateCube: function (groupKey, cubeJsonObject) { privateUpdateCube(groupKey, cubeJsonObject); },
					RemoveCube: function (groupKey, cubeJsonObject) { privateRemoveCube(groupKey, cubeJsonObject); },

					ShowByGroupKey: function (groupKey) { privateShowHideCubesByGroupKey(groupKey, true); },
					HideByGroupKey: function (groupKey) { privateShowHideCubesByGroupKey(groupKey, false); },
					ToggleVisibility: function () { privateShowHideAll(!_cubesGroup.visible); },

					RefreshCubes: privateRefreshCubes
				};
			}();

			var privateWallManager = function () {

				var _wallsGroup = new THREE.Object3D();
				var _lastWallsCorners = undefined;

				var privateUpdateBasement = function(wallsCorners) {

					_lastWallsCorners = wallsCorners;

					privateClearAll();

					if( wallsCorners.length > 0 ) {
						
						var walls = privateBuildWallsFromCorners( wallsCorners );
						privateAddWallsToGroup( walls );
						//Aggiunta dei nomi sui corner nel 3D
						privateAddCornerLabels( wallsCorners ); 
					}
				};

				var privateBuildWallsFromCorners = function ( corners ) {

					var resWalls = [];

					if ( corners.length < 2 ) {

						for ( var i = 0; i < corners.length; i++ ) {
						
							resWalls.push( corners[i] );
						}

					} else {

						for ( var i=0; i<corners.length; i++ ) {
							
							var a = corners[i].value;
							var b = ((i+1) < corners.length) ? corners[i+1].value : corners[0].value;

							var deltaY = b.y - a.y;
							var deltaX = b.x - a.x;

							var centerX = (b.x + a.x) / 2;
							var centerY = (b.y + a.y) / 2;
							var centerPolarAngle = Math.atan2(centerY, centerX);

							var length = Math.sqrt(Math.pow((b.x - a.x), 2) + Math.pow((b.y - a.y), 2));

							var cardanAngle = 0;

							if ( deltaY == 0 ) {
								// segmento stazionario orizzontale
								if ( centerPolarAngle > 0 ) {
									// sta sopra al punto (0;0)
									cardanAngle = 180;
								} else {
									// sta sotto al punto (0;0)
									cardanAngle = 0;
								}

							} else if ( deltaX == 0 ) {
								// segmento stazionario vertcale
								if ( Math.abs(centerPolarAngle) > Math.PI / 2 ) {
									// sta a sinistra rispetto al centro
									cardanAngle = -90;
								} else {
									// sta a destra rispetto al centro
									cardanAngle = 90;
								}
							} else {

								var m = (b.y - a.y) / (b.x - a.x);
								var rad = Math.atan(m);
								var deg = rad * 180 / Math.PI;

								if ( centerPolarAngle < 0 ) {
									
									cardanAngle = deg;
								} else {
									
									cardanAngle = deg + 180;
								}
							}

							resWalls.push( {
								name: corners[i].name,
								id: corners[i].id,
								value: {	
									x: centerX,
									y: centerY,
									z: 0,
									roll: 0,
									pitch: 0,
									yaw: cardanAngle,
									width: length,
									height: 0,
									depth: 1
								}
							});
						}

					}

					return resWalls;
				};

				var privateClearAll = function() {

					while( _wallsGroup.children.length > 0 ) {
						_wallsGroup.children.pop();
					}
				};

				var privateAddWallsToGroup = function(walls) {
					for(var i = 0; i < walls.length; i++ ) {
						_wallsGroup.add(privateBuildWallMesh(walls[i]));
					}
				};
				
				//Aggiunta dei nomi sui corner nel 3D
				var privateAddCornerLabels = function(corners) {
					for(var i = 0; i < corners.length; i++ ) {
						_wallsGroup.add(privateBuildSpriteMesh(corners[i]));
					}
				}

				//////////////////////////////////////Etichette per i corner... TSK1243 and TSK1513
				
				function privateBuildSpriteMesh ( corner ) {

					function privateMakeTextSprite ( message, parameters ) {

						function validateParameters ( parameters ) {

							if ( parameters === undefined ) parameters = {};
					
							parameters = {
								fontface: parameters.hasOwnProperty("fontface") ? 
									parameters["fontface"] : "Arial",
								
								fontsize: parameters.hasOwnProperty("fontsize") ? 
									parameters["fontsize"] : 18,
								
								borderThickness: parameters.hasOwnProperty("borderThickness") ? 
									parameters["borderThickness"] : 4,
								
								borderColor: parameters.hasOwnProperty("borderColor") ?
									parameters["borderColor"] : { r:0, g:0, b:0, a:1.0 },
								
								backgroundColor: parameters.hasOwnProperty("backgroundColor") ?
									parameters["backgroundColor"] : { r:255, g:255, b:255, a:1.0 }
							};

							return parameters;
						};

						function createCanvas ( parameters ) {

							var canvas = document.createElement('canvas');
							var context = canvas.getContext('2d');

							context.font = "Bold " + parameters.fontsize + "px " + parameters.fontface;

							// background color
							context.fillStyle   = "rgba(" + parameters.backgroundColor.r + "," + parameters.backgroundColor.g + ","
														  + parameters.backgroundColor.b + "," + parameters.backgroundColor.a + ")";
							// border color
							context.strokeStyle = "rgba(" + parameters.borderColor.r + "," + parameters.borderColor.g + ","
														  + parameters.borderColor.b + "," + parameters.borderColor.a + ")";

							context.lineWidth = parameters.borderThickness;

							return canvas;
						};

						function paintOnCanvas ( canvas, parameters, message ) {

							function drawRoundRect ( ctx, x, y, w, h, r ) {

								ctx.beginPath();
								ctx.moveTo(x+r, y);
								ctx.lineTo(x+w-r, y);
								ctx.quadraticCurveTo(x+w, y, x+w, y+r);
								ctx.lineTo(x+w, y+h-r);
								ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
								ctx.lineTo(x+r, y+h);
								ctx.quadraticCurveTo(x, y+h, x, y+h-r);
								ctx.lineTo(x, y+r);
								ctx.quadraticCurveTo(x, y, x+r, y);
								ctx.closePath();
								ctx.fill();
								ctx.stroke();   
							};

							var context = canvas.getContext('2d');

							// get size data (height depends only on font size)
							var metrics = context.measureText( message );
							var textWidth = metrics.width;

							drawRoundRect(context, parameters.borderThickness/2, parameters.borderThickness/2, textWidth + parameters.borderThickness, parameters.fontsize * 1.4 + parameters.borderThickness, 6);
							// 1.4 is extra height factor for text below baseline: g,j,p,q.

							// text color
							context.fillStyle = "rgba(255, 255, 255, 1.0)";
							context.fillText( message, parameters.borderThickness, parameters.fontsize + parameters.borderThickness);
						};

						function buildTextureFromCanvas ( canvas ) {

							// canvas contents will be used for a texture
							var texture = new THREE.Texture( canvas );
							texture.needsUpdate = true;

							return texture;
						};

						function buildSpriteMesh ( texture ) {

							var spriteMaterial = new THREE.SpriteMaterial( { map: texture, useScreenCoordinates: false } );
							
							var sprite = new THREE.Sprite( spriteMaterial );
							sprite.scale.set(200,100,1.0);
							
							return sprite;	
						};
						
						parameters = validateParameters( parameters );

						var canvas = createCanvas( parameters );

						paintOnCanvas( canvas, parameters, message );
							
						var texture = buildTextureFromCanvas( canvas );

						var spriteMesh = buildSpriteMesh( texture );

						return spriteMesh;
					};

					var spritey = privateMakeTextSprite( 
							' ' + (corner.id + 1).toString() + ' ', 
							{ 
								fontsize: 100, 
								borderColor: {r:0, g:0, b:0, a:0.8}, 
								backgroundColor: {r:0, g:0, b:0, a:0.5} 
							} 
						);

					if(corner.value.x != undefined && corner.value.y != undefined){
						var labelPosX = corner.value.x >= 0 ? corner.value.x + 100 : corner.value.x -100;
						var labelPosY = corner.value.y >= 0 ? corner.value.y + 100 : corner.value.y -100;
						spritey.position.set(labelPosX, labelPosY, 1000);
					}
					
					return spritey;
				};
				
				/////////////////////////////////////////////Fine etichette per i corner
				
				var privateBuildWallMesh = function(wall) {

					var material = new THREE.MeshBasicMaterial( {color:0x0F0F0F, transparent: true, opacity: 0.1} );

					var boxHeight = _settings.zmaxCoordinate - _settings.zminCoordinate;

					var wallLength = wall.value.width / _settings.scalingFactor;
					var wallWidth = boxHeight;
					var wallHeight = 50 / _settings.scalingFactor;

					var wallMesh = new THREE.Mesh(new THREE.BoxGeometry(wallLength, wallHeight, wallWidth), material);

					wallMesh.material.side = THREE.SingleSide;
					wallMesh.rotation.x = ((wall.value.roll < 0) ? 360 + wall.value.roll : wall.value.roll) * Math.PI / 180;
					wallMesh.rotation.y = ((wall.value.pitch < 0) ? 360 + wall.value.pitch : wall.value.pitch) * Math.PI / 180;
					wallMesh.rotation.z = ((wall.value.yaw < 0) ? 360 + wall.value.yaw : wall.value.yaw) * Math.PI / 180;
					wallMesh.position.x = wall.value.x / _settings.scalingFactor;
					wallMesh.position.y = wall.value.y / _settings.scalingFactor;
					wallMesh.position.z = (boxHeight / 2) + _settings.zminCoordinate;

					return wallMesh;
				};

				var privateShowHideAll = function(show) {

					_wallsGroup.visible = show;
				};

				var privateRefreshWalls = function() {

					if ( _lastWallsCorners != undefined ) {
					
						privateUpdateBasement(_lastWallsCorners);
					}
				};

				return {

					Get3DGroup: function () { return _wallsGroup; },
				
					UpdateBasement: function (walls) { privateUpdateBasement(walls); },
					RefreshWalls: function() { privateRefreshWalls(); },

					Show: function () { privateShowHideAll(true); },
					Hide: function () { privateShowHideAll(false); },
					ToggleVisibility: function () { privateShowHideAll(!_wallsGroup.visible); },
					AreWallsVisible: function () { return _wallsGroup.visible; }
				};
			}();

			var privateLoadRequiredResources = function () {

				var loader = new THREE.ColladaLoader();

				loader.options.convertUpAxis = true;
				loader.load( '../models/'+_settings.robotmodelname+'.dae', function ( collada ) {

						_sceneComponents.robotModel = collada.scene;

						_resourcesLoaded = true;

						if(_onReadyToStartCallback !== undefined) {

							_onReadyToStartCallback();
						}
					} 
				);
			};

			var privateInitialize = function () {

				if(!_robot.IsTPConnected()){
					_containerElement.empty();

					_axisMonitoringPointsGroup = new THREE.Object3D();
					
					privateBuildThreeDEngine();
					privateBuildBaseScene(); 

					_threedEngine.mainView.scene.add(privateCubeManager.Get3DGroup());
					_threedEngine.mainView.scene.add(privateWallManager.Get3DGroup());

					_containerElement.append(_threedEngine.mainView.renderer.domElement);

					privateAnimate();
				}
			};

			var privateUpdateViewSizeWhenNeeded = function () {

				var newRatio = _containerElement.clientWidth / _containerElement.clientHeight;

				if ( !isNaN(newRatio) && _threedEngine.mainView.camera.aspect != newRatio ) {

					_threedEngine.mainView.camera.aspect = newRatio;
					_threedEngine.mainView.camera.updateProjectionMatrix();

					_threedEngine.mainView.renderer.setSize(_containerElement.clientWidth, _containerElement.clientHeight);
				}
			};

			var privateHideGround = function ( hide ) {

				if(_sceneComponents.groundPlane != undefined){
					if ( hide ) {
						_sceneComponents.groundPlane.material.opacity = 0.3;
					} else {
						_sceneComponents.groundPlane.material.opacity = 1.0;
					}
				}
			};

			return {

				setViewReadyCallback: function ( callback ) { _onReadyToStartCallback = callback; },
				IsReadyToStart: function () { return _resourcesLoaded; },

				LoadRequiredResources: function () { privateLoadRequiredResources(); },
				Initialize: function() { privateInitialize(); },

				UpdateZMinMax: function (zmin, zmax) { privateUpdateZMinMax(zmin, zmax); },

				AddCube: function (groupKey, cubeJsonObject) { privateCubeManager.AddCube(groupKey, cubeJsonObject); },
				UpdateCube: function (groupKey, cubeJsonObject) { privateCubeManager.UpdateCube(groupKey, cubeJsonObject); },
				RemoveCube: function (groupKey, cubeJsonObject) { privateCubeManager.RemoveCube(groupKey, cubeJsonObject); },
				ShowCubes: function (groupKey) { privateCubeManager.ShowByGroupKey(groupKey); },
				HideCubes: function (groupKey) { privateCubeManager.HideByGroupKey(groupKey); },
				ToggleCubesVisibility: function () { privateCubeManager.ToggleVisibility(); },

				UpdateBasement: function (walls) { privateWallManager.UpdateBasement(walls); },
				ShowWalls: function () { privateHideGround(false); privateWallManager.Show(); privateCubeManager.RefreshCubes(); },
				HideWalls: function () { privateHideGround(true); privateWallManager.Hide(); privateCubeManager.RefreshCubes(); },
				AreWallVisible: function () { return privateWallManager.AreWallsVisible(); },
				ToggleWallsVisibility: function () { privateWallManager.ToggleVisibility(); privateCubeManager.RefreshCubes(); }
			};
		};

		var ToolThreeDView = function ( container ) {

			var _containerElement = $(container);
			var _sceneEdgeSize = 10000;

			var _scene;
			var _renderer;		
			var _camera;

			var _toolModel;
			var _toolModelName = "toolmodelcomplete";

			var _worldAxisScene;
			var _worldAxisRenderer;
			var _worldAxisCamera;

			var _toolMonitoringPointsGroup;
			var _toolset1PointsGroup;
			var _toolset2PointsGroup;

			var _onReadyToStartCallback = null;
			var _resourcesLoaded = false;

			var privateAnimate = function() {

				requestAnimationFrame( privateAnimate.bind(this) );

				_controls3D.update();

				_worldAxisCamera.position.copy( _camera.position );
				_worldAxisCamera.position.sub( _controls3D.target ); // added by @libe
				_worldAxisCamera.position.setLength( 150 );

				_worldAxisCamera.lookAt( _worldAxisScene.position );

				privateRender();
			};

			var privateRender = function() {

				privateUpdateViewSizeWhenNeeded();

				_renderer.render( _scene, _camera );
				_worldAxisRenderer.render( _worldAxisScene, _worldAxisCamera );
			};

			var privateBuildBaseScene = function () {

				var baseSceneUtility = {

					BuildAxis: function ( _axisLenght ) {

						var axisLenght = _axisLenght || 1;

						var vertices = new Float32Array( [
							-axisLenght/2, 0, 0,  axisLenght/2, 0, 0,
							0, -axisLenght/2, 0,  0, axisLenght/2, 0,
							0, 0, -axisLenght/2,  0, 0, axisLenght/2
						] );

						var colors = new Float32Array( [
							0, 0.6, 1,  0, 0, 1,							
							0.6, 1, 0,  0, 1, 0,
							1, 0.6, 0,  1, 0, 0
						] );

						var geometry = new THREE.BufferGeometry();
						geometry.addAttribute( 'position', new THREE.BufferAttribute( vertices, 3 ) );
						geometry.addAttribute( 'color', new THREE.BufferAttribute( colors, 3 ) );

						var material = new THREE.LineBasicMaterial( { vertexColors: THREE.VertexColors } );

						var axes = new THREE.Line( geometry, material, THREE.LinePieces );

						return axes;
					},

					BuildLights: function () {

						var topLight = new THREE.PointLight(0xffffff);
						topLight.position.set(0,0,100000);

						var aLight = new THREE.PointLight(0xf0f0f0);
						aLight.position.set(-100000,-100000,1);

						var bLight = new THREE.PointLight(0xf0f0f0);
						bLight.position.set(100000,-100000,1);

						var cLight = new THREE.PointLight(0xf0f0f0);
						cLight.position.set(100000,100000,1);

						var dLight = new THREE.PointLight(0xf0f0f0);
						dLight.position.set(-100000,100000,1);

						var lights = new THREE.Object3D();
						lights.add(topLight);
						lights.add(aLight);
						lights.add(bLight);
						lights.add(cLight);
						lights.add(dLight);

						return lights;
					},

					BuildToolModel: function () {

						//var bBox = new THREE.Box3().setFromObject(_toolModel);

						//var boxW = bBox.max.y - bBox.min.y;

						// var scale = (3000) / boxW;
						var scale = 1270;//300;

						_toolModel.scale.x = scale; // * 10 * 2;
						_toolModel.scale.y = scale; // * 10 * 2;
						_toolModel.scale.z = scale; // * 10 * 2;


						_toolModel.rotation.x = Math.PI / 2;

						_toolModel.updateMatrix();

						return _toolModel;
					},

					AddWorldAxes: function () {

						function privateBuildHtmlComponent() {

							var htmlComponent = $('<div class="scr_threedview_worldaxis" />')
							.css({
								'width' : String(edge) + "px",
								'height' : String(edge) + "px",
								'background-color' : 'transparent',
								'border' : 'none',
								'margin' : '5px',
								'padding' : '0px',
								'position' : 'absolute',
								'left' : '0px',
								'bottom' : '0px',
								'z-index' : '100'
							});

							return htmlComponent;						
						};

						function privateBuildWorldAxes3DEngine() {

							// Renderer
							_worldAxisRenderer = new THREE.WebGLRenderer( { precision:"lowp", antialias: true, alpha: true } );
							_worldAxisRenderer.setClearColor( 0x000000, 0 );
							_worldAxisRenderer.setSize( edge, edge );

							// Camera
							_worldAxisCamera = new THREE.PerspectiveCamera( 25, edge / edge, 1, 500 );
							_worldAxisCamera.up = _camera.up;

							// Scene
							_worldAxisScene = new THREE.Scene();						
						};

						function privatePopulateWorldAxisScene() {

							function privateBuildArrowAxes(lenght) {

								function buildArrow(x, y, z, color) {

									var headRotMatrix = new THREE.Matrix4();
									if( x != 0 ) {
										
										var rot = (  Math.PI / 2);

										if ( x > 0 ) {
											rot *= -1;
										}
										
										headRotMatrix.makeRotationZ(rot);
									}
									if( z != 0 ) {

										var rot = (  Math.PI / 2);

										if ( z < 0 ) {
											rot *= -1;
										}

										headRotMatrix.makeRotationX(rot);
									}

									var materialline = new THREE.LineBasicMaterial({color: color});
									var geometryline = new THREE.Geometry();
										geometryline.vertices.push(
											new THREE.Vector3( 0, 0, 0 ),
											new THREE.Vector3( x, y, z )
										);
									var line = new THREE.Line(geometryline, materialline);
									var materialcone = new THREE.MeshBasicMaterial( {color: color} );
									var geometrycone = new THREE.CylinderGeometry( 0, 2, 5 );
										geometrycone.applyMatrix(headRotMatrix);
									var cone = new THREE.Mesh( geometrycone, materialcone );		
										cone.position.x = x;
										cone.position.y = y;
										cone.position.z = z;

									var arrow = new THREE.Object3D();
									arrow.add(line);
									arrow.add(cone);

									return arrow;
								};

								var arrowX = buildArrow(lenght, 0, 0, 0x0000ff);
								var arrowY = buildArrow(0, lenght, 0, 0x00ff00);
								var arrowZ = buildArrow(0, 0, -lenght, 0xff0000);

								var arrowsGroup = new THREE.Object3D();

								arrowsGroup.add(arrowX);
								arrowsGroup.add(arrowY);
								arrowsGroup.add(arrowZ);

								return arrowsGroup;
							}

							_worldAxisScene.add( privateBuildArrowAxes(30) );
						};

						var edge = 100;

						privateBuildWorldAxes3DEngine();
						privatePopulateWorldAxisScene();

						var htmlComponent = privateBuildHtmlComponent();
						$(_containerElement).append(htmlComponent);
						$(htmlComponent).append(_worldAxisRenderer.domElement);
					}			
				};

				_scene = new THREE.Scene();

				_scene.add(baseSceneUtility.BuildAxis(_sceneEdgeSize / 2));
				_scene.add(baseSceneUtility.BuildToolModel());
				_scene.add(baseSceneUtility.BuildLights());
				_scene.add(privMonitoringPointsLib.buildElbowAxis(1000));

				baseSceneUtility.AddWorldAxes();
			};

			var privateBuildThreeDEngine = function () {

				var threeDEngineComponentsBuilder = {

					BuildRenderer: function () {

						var renderer = new THREE.WebGLRenderer( { precision:"lowp", antialias: true, alpha: true } );
						renderer.setSize(650, 600);			
						renderer.setClearColor(0x000000, 0);

						return renderer;
					},

					BuildPerspectivePlaneCamera: function () {

						var camera = new THREE.PerspectiveCamera( 70, 650 / 600, .1, 100000 );
						camera.position.x = 2000;
						camera.position.y = -2000;
						camera.position.z = 2000;
						camera.up.x = 0;
						camera.up.y = 0;
						camera.up.z = 1;

						camera.lookAt(new THREE.Vector3(0,0,0));

						return camera;
					},

					Build3DControls: function ( camera, renderer ) {

						var controls3D = new THREE.OrbitControls( camera, renderer.domElement );
						controls3D.damping = 0.2;
						controls3D.maxPolarAngle = Math.PI/2 * 89/90; 
						controls3D.minDistance = 0;
						controls3D.maxDistance = 40000;	

						return controls3D;
					}
				};

				_renderer = threeDEngineComponentsBuilder.BuildRenderer();
				_camera = threeDEngineComponentsBuilder.BuildPerspectivePlaneCamera();
				_controls3D = threeDEngineComponentsBuilder.Build3DControls( _camera, _renderer );
			};

			var privateLoadRequiredResources = function () {

				var loader = new THREE.ColladaLoader();

				loader.options.convertUpAxis = true;
				loader.load( '../models/'+_toolModelName+'.dae', function ( collada ) {

						_toolModel = collada.scene;
	
						_resourcesLoaded = true;

						if(_onReadyToStartCallback !== undefined) {

							_onReadyToStartCallback();
						}
					} 
				);
			};

			var privateInitialize = function () {

				if(!_robot.IsTPConnected()){
					_containerElement.empty();

					_toolMonitoringPointsGroup = new THREE.Object3D();
					_toolset1PointsGroup = new THREE.Object3D();
					_toolset2PointsGroup = new THREE.Object3D();

					privateBuildThreeDEngine();
					privateBuildBaseScene();

					_containerElement.append(_renderer.domElement);

					privateAnimate();
				}
			};

			var privateUpdateViewSizeWhenNeeded = function () {

				var newRatio = _containerElement.clientWidth / _containerElement.clientHeight;

				if ( !isNaN(newRatio) && _camera.aspect != newRatio ) {

					_camera.aspect = newRatio;
					_camera.updateProjectionMatrix();

					_renderer.setSize(_containerElement.clientWidth, _containerElement.clientHeight);
				}
			};

			var privateUpdateToolMonitoringPoints = function ( pointsArray, color ) {

				if(!_robot.IsTPConnected()){
					privMonitoringPointsLib.clearToolPoints();
					
					var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });
					for ( var i = 0; i < pointsArray.length; i++ ) {

						_toolMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(pointsArray[i], material));
						_toolMonitoringPointsGroup.add(privMonitoringPointsLib.buildSpriteMesh(pointsArray[i]));

						//toolpoints links
						var linkCap = {
							value: { x: 0, y: 0, z: 0, radius: 0 }
						};

						var endPoint = undefined;

						if (i > 0) {
							//connect to the previous tool monitoring point
							endPoint = new THREE.Vector3(pointsArray[i - 1].value.x, pointsArray[i - 1].value.y, pointsArray[i - 1].value.z);
							linkCap.value.x = pointsArray[i - 1].value.x;
							linkCap.value.y = pointsArray[i - 1].value.y;
							linkCap.value.z = pointsArray[i - 1].value.z;
							linkCap = pointsArray[i - 1];
						} else {
							//connect to flange orgin point.
							endPoint = new THREE.Vector3(0, 0, 0);
							linkCap.value.x = 0;
							linkCap.value.y = 0;
							linkCap.value.z = 0;
						}
						var startPoint = new THREE.Vector3(pointsArray[i].value.x, pointsArray[i].value.y, pointsArray[i].value.z);

						//add the link to the 3dGroup
						_toolMonitoringPointsGroup.add(privMonitoringPointsLib.buildConnectionCylinderMesh(startPoint, endPoint, pointsArray[i].value.radius, material));

						linkCap.value.radius = pointsArray[i].value.radius; //set the next kinematics point, for rounding the link cap.
						//add the cap to the 3dGroup
						_toolMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(linkCap, material));

					}   
	
					// add the points as a group to the scene
					_scene.add(_toolMonitoringPointsGroup);
				}
			};

			var privateUpdateToolsetPoints = function ( groupId, newPoints, color ) {

				var group = _toolset1PointsGroup;

				if (groupId === 2) {

					group = _toolset2PointsGroup;
				}

				privMonitoringPointsLib.clearToolsetPoints(group);

				if (newPoints.length === 2) {

					if(group!=undefined){
						var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });
						group.add( privMonitoringPointsLib.buildPointMesh(newPoints[0], material));
						group.add( privMonitoringPointsLib.buildSpriteMesh(newPoints[0] ,groupId.toString() + ".1"));
						group.add( privMonitoringPointsLib.buildPointMesh(newPoints[1], material));
						group.add( privMonitoringPointsLib.buildSpriteMesh(newPoints[1], groupId.toString() + ".2"));
						
						group.add( privMonitoringPointsLib.buildConnectionLineMesh(newPoints, color));
	
						_scene.add(group);
					}
				}
			};

			var privateUpdateToolsetPointsVisibility = function ( groupId, isVisible ) {

				if(!_robot.IsTPConnected()){
					var group = _toolset1PointsGroup;
	
					if (groupId === 2) {
	
						group = _toolset2PointsGroup;
					}
	
					group.visible = isVisible;
				}
			};

			var privateRotatePoints = function (points) {

				var rotatedPointsArray = [];

				for ( var i = 0; i < points.length; i++ ) {

					rotatedPointsArray.push( 
						{ 
							value: { 
								x:points[i].value.z, 
								y:points[i].value.y, 
								z:points[i].value.x * (-1),
								radius:points[i].value.radius
							}, 
							id:points[i].id,
							name:points[i].name,
							flags:points[i].flags 
						} );
				}

				return rotatedPointsArray;
			};

			var _axisMonitoringPointsGroup = new THREE.Object3D();

			var _elbowMonitoringPointsGroup = new THREE.Object3D();

			//fixed point coordinates to be used for generating rotated points
			var j0 = { x: 1620.0, y: 0.0, z: -1550.0, radius: 0.0 };
			var j1 = { x: 1070.0, y: -35.0, z: -1150.0, radius: 0.0 };
			var j2 = { x: 210.0, y: -35.0, z: -1150.0, radius: 0.0 };
			var j3 = { x: 0.0, y: 0.0, z: -1240.0, radius: 0.0 };
			var j4 = { x: 0.0, y: 0.0, z: -175.0, radius: 0.0 };
			var j5 = { x: 0.0, y: 0.0, z: -105.0, radius: 0.0 };
			var j6 = { x: 0.0, y: 0.0, z: 0.0, radius: 0.0 }; 

			const elbowOrigin = { x: j2.z, y: j2.y, z: j2.x * (-1), radius: 0.0 };

			//monitoring points handler (
			var privMonitoringPointsLib = function () {

				var privateClearToolPoints = function () {
					if (!_robot.IsTPConnected()) {
						_scene.remove(_toolMonitoringPointsGroup);

						while (_toolMonitoringPointsGroup.children.length > 0) {
							_toolMonitoringPointsGroup.children.pop();
						}
					}
				};

				var privateClearToolsetPoints = function(group) {
					if (!_robot.IsTPConnected()) {
						_scene.remove(group);

						while (group.children.length > 0) {
							group.children.pop();
						}
					}
				};

				var privateClearAxisPoints = function() {

					_scene.remove(_axisMonitoringPointsGroup);

					while (_axisMonitoringPointsGroup.children.length > 0) {
						_axisMonitoringPointsGroup.children.pop();
					}
				};

				var privateClearElbowPoints = function() {
					_scene.remove(_elbowMonitoringPointsGroup);

					while (_elbowMonitoringPointsGroup.children.length > 0) {
						_elbowMonitoringPointsGroup.children.pop();
					}
				};

				var privateBuildPointMesh = function (point, material) {


					var pointGeom = new THREE.SphereGeometry(point.value.radius, 16, 16);
					var pointMesh = new THREE.Mesh(pointGeom, material);
				   
					pointMesh.position.set(point.value.x, point.value.y, point.value.z);

					return pointMesh;
				};
				
				var privateBuildConnectionLineMesh = function(points, color) {

					if (!_robot.IsTPConnected()) {
						var vertices = new Float32Array([
								points[0].value.x, points[0].value.y, points[0].value.z,
								points[1].value.x, points[1].value.y, points[1].value.z
						]);

						var colorObj = new THREE.Color(color);
						var col = new Float32Array([
								colorObj.r, colorObj.g, colorObj.b,
								colorObj.r, colorObj.g, colorObj.b,
						]);

						var geometry = new THREE.BufferGeometry();
						geometry.addAttribute('position', new THREE.BufferAttribute(vertices, 3));
						geometry.addAttribute('color', new THREE.BufferAttribute(col, 3));

						var material = new THREE.LineBasicMaterial({ vertexColors: THREE.VertexColors });

						var lineMesh = new THREE.Line(geometry, material, THREE.LinePieces);

						return lineMesh;
					}
				};

				var HALF_PI = Math.PI * .5;

				var privateBuildConnectionCylinderMesh = function (vstart, vend, radius, material) {
					var orientation = new THREE.Matrix4();//a new orientation matrix to offset pivot
					var offsetRotation = new THREE.Matrix4();//a matrix to fix pivot rotation
					var offsetPosition = new THREE.Matrix4();//a matrix to fix pivot position

					var distance = vstart.distanceTo(vend);
					var position = vend.clone().add(vstart).divideScalar(2);

					var cylinder = new THREE.CylinderGeometry(radius, radius, distance, 32, 1, false);

					orientation.lookAt(vstart, vend, new THREE.Vector3(0, 1, 0));//look at destination
					offsetRotation.makeRotationX(HALF_PI);//rotate 90 degs on X
					orientation.multiply(offsetRotation);//combine orientation with rotation transformations
					cylinder.applyMatrix(orientation);

					mesh = new THREE.Mesh(cylinder, material);
					mesh.position.x = position.x;
					mesh.position.y = position.y;
					mesh.position.z = position.z;

					return mesh;
				};

				var privateBuildElbowAxis = function (_axisLenght) {

					var axisLenght = _axisLenght || 1;

					//TSK2686 draw only the positive side of the axis
					var vertices = new Float32Array([
						0, 0, 0, 0, axisLenght / 2, 0, //Z
						0, 0, 0, 0, 0, -axisLenght / 2, //Y
						0, 0, 0, axisLenght / 2, 0, 0 //X
					]);

					var colors = new Float32Array([
						0, 0.6, 1, 0, 0, 1, //B?
						0.6, 1, 0, 0, 1, 0, //G?
						1, 0.6, 0, 1, 0, 0  //R?
					]);

					var geometry = new THREE.BufferGeometry();
					geometry.addAttribute('position', new THREE.BufferAttribute(vertices, 3));
					geometry.addAttribute('color', new THREE.BufferAttribute(colors, 3));

					var material = new THREE.LineBasicMaterial({ vertexColors: THREE.VertexColors });

					var elbowAxes = new THREE.Line(geometry, material, THREE.LinePieces);

					//set the axis position (rotating origin point)
					elbowAxes.position.x = elbowOrigin.x;
					elbowAxes.position.y = elbowOrigin.y;
					elbowAxes.position.z = elbowOrigin.z;

					return elbowAxes;
				};

				var privateBuildSpriteMesh = function (point, text) {

					function privateMakeTextSprite(message, parameters) {

						function validateParameters(parameters) {

							if (parameters === undefined) parameters = {};

							parameters = {
								fontface: parameters.hasOwnProperty("fontface") ?
									parameters["fontface"] : "Arial",

								fontsize: parameters.hasOwnProperty("fontsize") ?
									parameters["fontsize"] : 18,

								borderThickness: parameters.hasOwnProperty("borderThickness") ?
									parameters["borderThickness"] : 4,

								borderColor: parameters.hasOwnProperty("borderColor") ?
									parameters["borderColor"] : { r: 0, g: 0, b: 0, a: 1.0 },

								backgroundColor: parameters.hasOwnProperty("backgroundColor") ?
									parameters["backgroundColor"] : { r: 255, g: 255, b: 255, a: 1.0 }
							};

							return parameters;
						};

						function createCanvas(parameters) {

							var canvas = document.createElement('canvas');
							var context = canvas.getContext('2d');

							context.font = "Bold " + parameters.fontsize + "px " + parameters.fontface;

							// background color
							context.fillStyle = "rgba(" + parameters.backgroundColor.r + "," + parameters.backgroundColor.g + ","
														  + parameters.backgroundColor.b + "," + parameters.backgroundColor.a + ")";
							// border color
							context.strokeStyle = "rgba(" + parameters.borderColor.r + "," + parameters.borderColor.g + ","
														  + parameters.borderColor.b + "," + parameters.borderColor.a + ")";

							context.lineWidth = parameters.borderThickness;

							return canvas;
						};

						function paintOnCanvas(canvas, parameters, message) {

							function drawRoundRect(ctx, x, y, w, h, r) {

								ctx.beginPath();
								ctx.moveTo(x + r, y);
								ctx.lineTo(x + w - r, y);
								ctx.quadraticCurveTo(x + w, y, x + w, y + r);
								ctx.lineTo(x + w, y + h - r);
								ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
								ctx.lineTo(x + r, y + h);
								ctx.quadraticCurveTo(x, y + h, x, y + h - r);
								ctx.lineTo(x, y + r);
								ctx.quadraticCurveTo(x, y, x + r, y);
								ctx.closePath();
								ctx.fill();
								ctx.stroke();
							};

							var context = canvas.getContext('2d');

							// get size data (height depends only on font size)
							var metrics = context.measureText(message);
							var textWidth = metrics.width;

							drawRoundRect(context, parameters.borderThickness / 2, parameters.borderThickness / 2, textWidth + parameters.borderThickness, parameters.fontsize * 1.4 + parameters.borderThickness, 6);
							// 1.4 is extra height factor for text below baseline: g,j,p,q.

							// text color
							context.fillStyle = "rgba(255, 255, 255, 1.0)";
							context.fillText(message, parameters.borderThickness, parameters.fontsize + parameters.borderThickness);
						};

						function buildTextureFromCanvas(canvas) {

							// canvas contents will be used for a texture
							var texture = new THREE.Texture(canvas);
							texture.needsUpdate = true;

							return texture;
						};

						function buildSpriteMesh(texture) {

							var spriteMaterial = new THREE.SpriteMaterial({ map: texture, useScreenCoordinates: false });

							var sprite = new THREE.Sprite(spriteMaterial);
							sprite.scale.set(200, 100, 1.0);

							return sprite;
						};

						parameters = validateParameters(parameters);

						var canvas = createCanvas(parameters);

						paintOnCanvas(canvas, parameters, message);

						var texture = buildTextureFromCanvas(canvas);

						var spriteMesh = buildSpriteMesh(texture);

						return spriteMesh;
					};

					if (text == undefined) {
						text = (point.id + 1).toString()
					}

					var spritey = privateMakeTextSprite(
						' ' + text + ' ',
						{
							fontsize: 100,
							borderColor: { r: 0, g: 0, b: 0, a: 0.8 },
							backgroundColor: { r: 0, g: 0, b: 0, a: 0.5 }
						}
					);

					if (point.value.z >= 0) {
						spritey.position.set(point.value.x, point.value.y, point.value.z + point.value.radius + 100);
					} else {
						spritey.position.set(point.value.x, point.value.y, point.value.z - point.value.radius - 100);
					}

					return spritey;
				};

				return {
					clearToolPoints: privateClearToolPoints,
					clearToolsetPoints: privateClearToolsetPoints,
					clearAxisPoints: privateClearAxisPoints,
					clearElbowPoints: privateClearElbowPoints,
					buildPointMesh: privateBuildPointMesh,
					buildConnectionLineMesh: privateBuildConnectionLineMesh,
					buildConnectionCylinderMesh: privateBuildConnectionCylinderMesh,
					buildElbowAxis: privateBuildElbowAxis,
					buildSpriteMesh: privateBuildSpriteMesh
				}
			}();

			var privateUpdateAxisMonitoringPoints = function (pointsArray, color) {

				if (!_robot.IsTPConnected()) {
					privMonitoringPointsLib.clearAxisPoints();

					var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });

					for (var i = 0; i < pointsArray.length; i++) {

						if (pointsArray[i].value.radius > 0) {
							//kinematics point
							_axisMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(pointsArray[i], material));
							//label
							_axisMonitoringPointsGroup.add(privMonitoringPointsLib.buildSpriteMesh(pointsArray[i], ""+pointsArray[i].id));

							//kinematics links
							if (i > 0) { //skip the first axis
								var startPoint = new THREE.Vector3(pointsArray[i].value.x, pointsArray[i].value.y, pointsArray[i].value.z);
								var endPoint = new THREE.Vector3(pointsArray[i - 1].value.x, pointsArray[i - 1].value.y, pointsArray[i - 1].value.z);
								//add the link to the 3dGroup
								_axisMonitoringPointsGroup.add(privMonitoringPointsLib.buildConnectionCylinderMesh(startPoint, endPoint, pointsArray[i].value.radius, material));

								var linkCap = pointsArray[i - 1];
								linkCap.value.radius = pointsArray[i].value.radius; //set the next kinematics point, for rounding the link cap.
								//add the cap to the 3dGroup
								_axisMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(linkCap, material));
							}
						}
					}

					// add the points as a group to the scene
					_scene.add(_axisMonitoringPointsGroup);
				}
			};

			var privateUpdateElbowMonitoringPoints = function (pointsArray, color) {
				if (!_robot.IsTPConnected()) {

					privMonitoringPointsLib.clearElbowPoints();

					var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });

					for (var i = 0; i < pointsArray.length; i++) {

						if (pointsArray[i].value.radius > 0) {
							//kinematics elbow point
							_elbowMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(pointsArray[i], material));
							//label
							_elbowMonitoringPointsGroup.add(privMonitoringPointsLib.buildSpriteMesh(pointsArray[i]));

							//kinematics links
							var linkCap = {
								value: { x: 0, y: 0, z: 0, radius: 0 }
							};

							var endPoint = undefined;
							
							if (i > 0) {
								//connect to the previous elbow point
								endPoint = new THREE.Vector3(pointsArray[i - 1].value.x, pointsArray[i - 1].value.y, pointsArray[i - 1].value.z);
								linkCap.value.x = pointsArray[i - 1].value.x;
								linkCap.value.y = pointsArray[i - 1].value.y;
								linkCap.value.z = pointsArray[i - 1].value.z;
								linkCap = pointsArray[i - 1];
							} else {
								//connect to elbow orgin point.
								endPoint = new THREE.Vector3(elbowOrigin.x, elbowOrigin.y, elbowOrigin.z);
								linkCap.value.x = elbowOrigin.x;
								linkCap.value.y = elbowOrigin.y;
								linkCap.value.z = elbowOrigin.z;
							}
							var startPoint = new THREE.Vector3(pointsArray[i].value.x, pointsArray[i].value.y, pointsArray[i].value.z);

							//add the link to the 3dGroup
							_elbowMonitoringPointsGroup.add(privMonitoringPointsLib.buildConnectionCylinderMesh(startPoint, endPoint, pointsArray[i].value.radius, material));

							linkCap.value.radius = pointsArray[i].value.radius; //set the next kinematics point, for rounding the link cap.
							//add the cap to the 3dGroup
							_elbowMonitoringPointsGroup.add(privMonitoringPointsLib.buildPointMesh(linkCap, material));
							
						}
					}

					// add the points as a group to the scene
					_scene.add(_elbowMonitoringPointsGroup);
				}
			};

			var rotatePointUtils = function () {

				const NUM_ELBOW_POINTS = 2;

				var privateRotateAxisPoints = function (kinematicsPoint) {

					var rotatedPointsArray = [];

					j1.radius = kinematicsPoint.value.axis1;
					j2.radius = kinematicsPoint.value.axis2;
					j3.radius = kinematicsPoint.value.axis3;
					j4.radius = kinematicsPoint.value.axis4;
					j5.radius = kinematicsPoint.value.axis5;
					j6.radius = kinematicsPoint.value.axis6;

					var coordVals = [];
					coordVals.push(j0); //punto corrispondente a $BASE non editabile!
					coordVals.push(j1);
					coordVals.push(j2);
					coordVals.push(j3);
					coordVals.push(j4);
					coordVals.push(j5);
					coordVals.push(j6);
					
					for (var i = 0; i < coordVals.length; i++) {
						
						//verifica che l'asse sia presente nella maschera kinematics
						if (i == 0 || (i > 0 && _robot.GetKineMask(i - 1))) {
							rotatedPointsArray.push(
								{
									value: {
										x: coordVals[i].z,
										y: coordVals[i].y,
										z: coordVals[i].x * (-1),
										radius: coordVals[i].radius
									},
									id: i,
									name: "axis" + i,
									flags: kinematicsPoint.flags
								});
						}
					}

					return rotatedPointsArray;
				};

				var privateRotateElbowPoints = function (kinematicsPoint) {

					var rotatedPointsArray = [];

					for (var i = 0; i < NUM_ELBOW_POINTS; i++) {
						rotatedPointsArray.push(
							{
								value: {
									x: elbowOrigin.x + kinematicsPoint.value["x" + (i + 1)],
									y: elbowOrigin.y + kinematicsPoint.value["z" + (i + 1)],
									z: elbowOrigin.z + (kinematicsPoint.value["y" + (i + 1)] * (-1)),
									radius: kinematicsPoint.value["radius" + (i + 1)]
								},
								id: i,
								name: "axis" + i,
								flags: kinematicsPoint.flags
							});
					}

					return rotatedPointsArray;
				};

				return {
					rotateAxisPoints: privateRotateAxisPoints,
					rotateElbowPoints: privateRotateElbowPoints
				}
			}();

			return {

				setViewReadyCallback: function ( callback ) { _onReadyToStartCallback = callback; },
				IsReadyToStart: function () { return _resourcesLoaded; },

				LoadRequiredResources: function () { privateLoadRequiredResources(); },
				Initialize: function () { privateInitialize(); },

				UpdateMonitoringPoints: function (pointsArray, color) { privateUpdateToolMonitoringPoints( privateRotatePoints(pointsArray), color); },
				UpdateToolset1Points: function (points, color) { privateUpdateToolsetPoints(1, privateRotatePoints(points), color); },
				UpdateToolset2Points: function (points, color) { privateUpdateToolsetPoints(2, privateRotatePoints(points), color); },

				UpdateToolset1PointsVisibility: function (isVisible) { privateUpdateToolsetPointsVisibility(1, isVisible); },
				UpdateToolset2PointsVisibility: function (isVisible) { privateUpdateToolsetPointsVisibility(2, isVisible); },

				UpdateAxisMonitoringPoints: function (pointsArray, color) { privateUpdateAxisMonitoringPoints(rotatePointUtils.rotateAxisPoints(pointsArray), color); },
				UpdateElbowMonitoringPoints: function (pointsArray, color) { privateUpdateElbowMonitoringPoints(rotatePointUtils.rotateElbowPoints(pointsArray), color); }
			};
		};

		function privateTryToStart() {
			
			if (!_robot.IsTPConnected() && _roomThreeDView.IsReadyToStart() && _toolThreeDView.IsReadyToStart() ) {

				_roomThreeDView.Initialize();
				_toolThreeDView.Initialize();

				if ( _readyToStartCallback != undefined ) {

					_readyToStartCallback();
				}
			}
		};

		function privateInitialize() {
			if (!_robot.IsTPConnected()){
				_roomThreeDView.setViewReadyCallback( privateTryToStart );
				_toolThreeDView.setViewReadyCallback( privateTryToStart );

				_roomThreeDView.LoadRequiredResources();
				_toolThreeDView.LoadRequiredResources();
			}
		};

		var _roomThreeDView = RoomThreeDView( _containers.roomThreeDViewContainer );
		var _toolThreeDView = ToolThreeDView( _containers.toolThreeDViewContainer );

		return {

			roomThreeDView: _roomThreeDView,
			toolThreeDView: _toolThreeDView,

			roomThreeDViewElement: _containers.roomThreeDViewContainer,
			toolThreeDViewElement: _containers.toolThreeDViewContainer,

			setReadyToStartCallback: function(_callback) { _readyToStartCallback = _callback; },

			Initialize: privateInitialize
		};
	}();
	*/
	var _configurationManager = function() {
		
		var BSON = bson().BSON;
		var _configurationFileName = "cartesian.json";
		var _bsonFileName = "safe_bck.bson";
		var _configurationFilePath = "../data/";
		var loadedData = null;
		const jsonSysIdIdentifier = "SysID_identifier";
		
		function privateLoadConfiguration(functionCallback) {
			
			loadedData = null;

			var xmlImport = sessionStorage.getItem('xmlImport');
		
			if( xmlImport != undefined ) {
				sessionStorage.removeItem('xmlImport');
				loadedData = JSON.parse(xmlImport);
				if(functionCallback != undefined && functionCallback instanceof Function){
					//console.log("data received, calling the passed callback function");
					functionCallback();
				}
			} else {
			
				$.ajax({
					dataType: "json",
					url: _configurationFilePath + _configurationFileName,
					cache: false,
					async: functionCallback != undefined,
					success: function( data ) {			
						loadedData = data;
						if(functionCallback != undefined && functionCallback instanceof Function){
							//console.log("data received, calling the passed callback function");
							functionCallback();
						}
					},
					error: function(xhr, textStatus, errorThrown){
						
						_utility.MessageBox('Error receiving SAFE data','Impossible to configure the SAFE, error receiving SAFE data.',false).Show();
						
						if(functionCallback != undefined && functionCallback instanceof Function){
							console.log("data NOT received, calling the passed callback function");
							functionCallback();
						}
					}
				});
			}
			return loadedData;
		};

		function privateSaveConfiguration() {

			var jsonObj = _managers.ToObjectJSON();
			var jsonString = JSON.stringify(jsonObj, null, "\t");

			var blob = new Blob( [jsonString], {type: "text/plain;charset=utf-8"} );
			
			var formData = new FormData();

			formData.append("cartesianCfg", blob, _configurationFileName);

			var request = new XMLHttpRequest();
			request.open("POST", "run?cartesian_config");
			request.send(formData);
			
			//insert SYS_ID in the JSON object before serializing it in BSON format.
			jsonObj[jsonSysIdIdentifier] = sys_id;
			
			var bsonFile = BSON.serialize(jsonObj, false, true, false);
			
			var blobBson = new Blob( [btoa(bsonFile)], {type: "data:application/octet-stream"} );
			
			var formDataBson = new FormData();

			formDataBson.append("cartesianCfg", blobBson, _bsonFileName);
			
			var bsonRequest = new XMLHttpRequest();
			bsonRequest.open("POST", "run?bson_backup");
			bsonRequest.send(formDataBson);
		};

		function privateIsDataLoaded(){
			return loadedData != null;
		}
		
		function getLoadedData(){
			return loadedData;
		}
		
		//is used from the XML import
		function setLoadedData(newData){
			loadedData = newData;
		}
		
		//TSK1357: check number of elements of subcategories
		function privateCanSaveConfig(){
			
			for ( var manager in _managers) {
				if( manager != undefined &&  _managers.hasOwnProperty(manager) ) {
					if(_managers[manager].CheckMinMaxNumber != undefined && !_managers[manager].CheckMinMaxNumber()){
						//show the related error message
						_utility.MessageBox("Error", "Bad elements number in "+manager.toString().replace("Manager","") + " page", true).Show();
						return false;
					}

				}
			}
			return true;
		}
		
		function checkCrcAndDynamicBits(){

			var dyn5ByInput = undefined;
			var crcCheck = undefined;
			
			if( _managers != undefined){
				
				var manager = "volumesManager"	
				if( _managers.hasOwnProperty(manager) ) {
					var dynamicAreas = _managers[manager].ToObjectJSON().DynamicVolumes;
					if(dynamicAreas != undefined){
						dyn5ByInput = dynamicAreas[4].flags.enabled && !dynamicAreas[4].flags.alwaysActive;
					}else{
						console.error("Mancanti dynamic volumes o cambiato nome dell'oggetto json");
					}
				}
	
				manager = "safeioManager"
				if( _managers.hasOwnProperty(manager) ) {
					var safeIO = _managers[manager].ToObjectJSON()["SafeOutput"];
					if(safeIO != undefined && safeIO.block3 != undefined){
						crcCheck = !safeIO.block3;
					}else{
						console.error("Mancanti safeIO flags o cambiato nome dell'oggetto json");
					}
				}
			}

			//TSK1736 errato controllo se entrambi "non abilitati"
			if(dyn5ByInput != undefined && crcCheck != undefined && crcCheck == true && dyn5ByInput == true){
				//le due opzioni condividono lo stesso bit di configurazione sulla Safe e non possono essere attive contemporaneamente
				_utility.MessageBox("Error", "CRC check option is incompatible with Dynamic Area 5 activated by RS input, Please change setting", true).Show();
				return false;
			}
			return true;
		}

		return {

			Load: privateLoadConfiguration,
			Save: privateSaveConfiguration,
			IsDataLoaded: privateIsDataLoaded,
			GetLoadedData: getLoadedData,
			SetLoadedData: 	setLoadedData,
			CanSaveConfig: privateCanSaveConfig,
			CheckCrcAndDynamicCoherence: checkCrcAndDynamicBits
		};
	}();

	var _popupUtility = function() {

		var _uploadFileBox = function () {

			const EXPORT_SUFFIX = "_export";

			function privateCreateDialog() {
				var isTPConn = _robot.IsTPConnected();

				var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>')

					.append( $('<p class="' + _cssClass.dialog_title + '"/>')

						.text("Import/Export configuration")
						
					)

					.append( $('<div class="scr_dialog_formrow"/>')
						//TSK2039 gestione import/export da TP5
						.append( isTPConn ? getHtmlTpImport() : getHtmlPcImport() )
					)
					
					.append( $('<div class="scr_dialog_formrow"/>')
							
						.append( $('<div class="scr_cell_100_popup"/>') 

							.append( $('<p/>')

								.html("Export configuration file.")
								.append(isTPConn ? getHtmlTpExport() : '')
							)
							.append( $('<input type="button" value="Export" class="' + _cssClass.dialog_button + '"/>') 

								.click( function () {
									// export the XML file
									if ( isTPConn ) {
										var currPath = $("#file_name_text" + EXPORT_SUFFIX).html();
										privateHide();
										_xmlUtil.downloadXMLFromTP5(currPath);
									} else {
										privateHide();
										_xmlUtil.downloadXMLBackup();
									}
									
								})
							)
						)
					);
					
					dialogContent.append( $('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

						.click( function () {
							privateHide();
						})
					);
					

				var dialogElement = $('<div id="scr_messagebox_dialog" class="' + _cssClass.dialog_hidden + '">').append( dialogContent );

				return dialogElement;
			};
			
			//TSK2039 gestione import/export da TP5
			function readDeviceFromCrc() {
				var option = '<option value"">Select...</option>';
				$.ajax(
						{
							url: "/get?dev_list", 
							cache : false,
							async: false,
							success: function(data)
							{
								
								var resArray = JSON.parse(data).devices;
								for(var i = 0; i < resArray.length; i++){
									option += '<option value="' + resArray[i] + '">' + resArray[i] + '</option>';
								}							 
							}
						});
				return option;
			};
			
			function updateSelectPathValues(suffix) {
				if (suffix == undefined) {
					suffix = "";
				}
				var currPath = $("#file_name_text" + suffix).html();
				var selPath = $("#select_path" + suffix).val()
				if(selPath != undefined){
					if(currPath != ""){
						currPath = currPath + "\\"; 
					}
					currPath = currPath + selPath;
				}
				//get subfolder from controller
				var enableImport = false;
				if (!currPath.endsWith(".xml")) {
					var commandOption = "&file_type=xml&with_dir=true";
					if (suffix === EXPORT_SUFFIX) {
						commandOption = "&file_type=directory";
					}
					var findPathCommand = "/get?file_list&path=" + currPath + commandOption;
					var resArray = undefined;
					$("#select_path" + suffix).empty();
					$.ajax(
					{
						url: findPathCommand, 
						cache : false,
						async: false,
						success: function(data)
						{
							resArray = JSON.parse(data).files;
							var option = '<option value"">No files available</option>';
							if(resArray.length > 0){
								option = '<option value"">Select...</option>';
								for(var i = 0; i < resArray.length; i++){
									option += '<option value="' + resArray[i] + '">' + resArray[i] + '</option>';
								}
							}
							$("#select_path" + suffix).append(option);
							$("#file_name_text" + suffix).html(currPath);
						}
					}); 
				}else{
					$("#select_path" + suffix).empty();
					$("#file_name_text" + suffix).html(currPath);
					enableImport = true;
				}
				$("#import_tp").prop("disabled", !enableImport);
				
			};
			
			function navigateUpFolder(suffix) {
				if (suffix == undefined) {
					suffix = "";
				}
				$("#select_path" + suffix).empty();
				var currPath = $("#file_name_text" + suffix).html();
				var lastTokenIdx = currPath.lastIndexOf("\\");
				if(lastTokenIdx >= 0){
					//posso tornare indietro di un folder
					currPath = currPath.substring(0, lastTokenIdx);
					$("#file_name_text" + suffix).html(currPath);
					updateSelectPathValues(suffix);
				}else{
					//torno al nodo padre (device)
					$("#file_name_text" + suffix).html("");
					$("#select_path" + suffix).append(readDeviceFromCrc());
				}

			};
			
			//Gestione export da TP5 con download in cartella specifica (TSK2189)
			function getHtmlTpExport() {
				var ret = $('<div class="scr_cell_100_popup"/>')

				.append($('<p/>').html("Please select the folder where you want to export the file."))
				.append($('<div>').append($('<div for="file_name_text'+EXPORT_SUFFIX+'" style="display: inline;">Path  </div>'))
									.append($('<div id="file_name_text' + EXPORT_SUFFIX + '"  style="display: inline;"/>').html(""))
						)
				.append($('<select id="select_path' + EXPORT_SUFFIX + '" style="width: 30%;" />').append(readDeviceFromCrc())
						.change(function () {
							updateSelectPathValues(EXPORT_SUFFIX);
						})
				)
				.append($('<input type="button" style="margin-left: 3%;" class="scr_navupbutton" />')
						.click(function () {
							navigateUpFolder(EXPORT_SUFFIX);
						})
				);
				return ret;
			}

			function getHtmlTpImport(){
				var ret =  $('<div class="scr_cell_100_popup"/>') 

				.append( $('<p/>').html("Please select the folder where the import file is placed.") )
				.append( $('<div>')	.append( $('<div for="file_name_text" style="display: inline;">Path  </div>') )
									.append( $('<div id="file_name_text"  style="display: inline;"/>').html("")	)
						)
				.append( $('<select id="select_path" style="width: 30%;" />').append(readDeviceFromCrc() )
						.change( function() {
							updateSelectPathValues();
						})
				)
				.append( $('<input type="button" style="margin-left: 3%;" class="scr_navupbutton" />') 
						.click( function () {
							navigateUpFolder();
						})
				)
				.append( $('<br />') )
				.append( $('<input type="button" id="import_tp" disabled="true" value="Import" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						//verifico che la combobox del filename termini col nome del file
						var textFileName =  $("#file_name_text").html();
						var filePresent = textFileName.endsWith(".xml");
						
						if (!filePresent) 
						{
							//no file found...
							_utility.MessageBox('Invalid file','Please choose a valid backup file name',true).Show();    
							return;
						}else{
							//chiamo il servizio che esegue l'import da path
							privateHide();
							//TODO: chiamare il servizio appena pronto.
							_xmlUtil.importFromTP(textFileName);
						}
					})
				);
				return ret;
			}
			
			function getHtmlPcImport () {
				return $('<div class="scr_cell_100_popup"/>') 

				.append( $('<p/>')

					.html("Please choose configuration file to import.")
				)
				.append( $('<input type="file" id="upload_file" accept=".xml, .XML" name="file" />')	)
				.append( $('<br />') )
				.append( $('<input type="button" value="Import" class="' + _cssClass.dialog_button + '"/>') 

					.click( function () {
						//Upload the file if present
							
						var file = $("#upload_file")[0].files[0];
						
						privateHide();
						if (!file) 
						{
							//no file found...
							_utility.MessageBox('No file found','Please select a backup file',true).Show();    
							return;
						}
						if (file.name.endsWith(".xml") || file.name.endsWith(".XML")) {
							_xmlUtil.validateAndRestore(file);
						}
						
					})
				)
			};
			
			function privateShow() {


				//resetting input file content
				$("#upload_file").val('');
				
				$('#scr_messagebox_dialog').addClass(_cssClass.dialog_shown);
			};

			function privateHide() {
				$("#scr_messagebox_dialog").removeClass(_cssClass.dialog_shown);
				
				if( $('#scr_messagebox_dialog').length > 0 ) {

					$('#scr_messagebox_dialog').remove();
				}
			};

			if( $('#scr_messagebox_dialog').length == 0 ) {

				$('body').append( privateCreateDialog() );
			};

			return {

				Show: privateShow,
				Hide: privateHide
			};
		};
		
		var infoMessages = undefined;
		
		var _infoMessages = function() {
			
			function init(){
				//read the file from data folder
				$.ajax({
					dataType: "json",
					url: '../data/infoMessages.json',
					cache: false,
					async: false,
					success: function( data ) {	
						infoMessages = data;
					},
					error: function() {
						console.log('unable to read file')
					}
				});
					
			};
			
			function privGetInfoMessage(infoID){
				if(infoMessages == undefined){
					init();
				}
				
				if(infoMessages != undefined && infoMessages.hasOwnProperty(infoID)){
					return infoMessages[infoID];
				}else{
					return undefined;
				}
			};
			
			return {
				getInfoMessage: privGetInfoMessage,
				initialize: init
			}
			
		};
		
		return {
			
			UploadFileBox: _uploadFileBox,
			InfoMessages: _infoMessages
		};
	}();
	
	var _xmlUtil = function() {
		
		var _privShowErrorMessage = function (errArray, xmlFileName){
			
			var resString = '<div style="text-align:left;">';
			for(var i=0; i < errArray.length; i++){
				resString += '<div style="color:red;">Err #'+(i+1)+'</div> ';
				errArray[i] = errArray[i].replace("\n", "<br/>");
				if(xmlFileName != undefined){
					errArray[i] = errArray[i].replace("file_0.xml", xmlFileName)
				}
				
				if( !errArray[i].endsWith("<br/>")) {
					errArray[i] += "<br/>";
				}
				resString += errArray[i];
			}
			resString += '</div>';
			
			_utility.MessageBox('Invalid file', resString + '<br /><br />Please select a valid XML configuration file', true).Show();
		}
		
		var _privValidateStoreResponseJson = function (txtJson) {
			
			var objJson = JSON.parse(txtJson);
			
			if(objJson.hasOwnProperty("errors") ){
				//something failed, received the error message
				//close the wait dialog
				_robot.StopWaitingJson();
				var errArray = objJson.errors;
				_privShowErrorMessage(errArray);
			} else {
				
				sessionStorage.setItem('xmlImport',txtJson);

				//refresh page
				location.reload();
			}
			
		}
				
		var _privSendXmlToCrc = function (blob) {
			var xmlFileName = "ComauRoboSAFE.xml";
			var formDataXml = new FormData();
			formDataXml.append("cartesianCfg", blob, xmlFileName);
			
			//resetting current data
			_configurationManager.SetLoadedData(null);
			
			_robot.WaitJson(); //show the popup of "waiting data loading"
			
			//post the xmlfile to crc, json config file expected
			var xmlRequest = new XMLHttpRequest();
			//onloadend
			var errorFunc = function(){
				console.log("data not correctly loaded");
				_utility.MessageBox("Info", "Data not loaded, please reload the page", false).show();;
			};

			xmlRequest.onerror = errorFunc;
			xmlRequest.onabort = errorFunc;
			xmlRequest.onloadend = function() {
				if(xmlRequest.readyState == XMLHttpRequest.DONE){
					
					try {
						_privValidateStoreResponseJson(xmlRequest.responseText);
					}catch(ex){
						errorFunc();
					}
				}
			};
			xmlRequest.open("POST", "run?xml_to_json");
			xmlRequest.send(formDataXml);
		}
		
		var _privImportFromXML = function (file){
			
			$.ajax({
				dataType: "text",
				url: '../data/ComauRoboSAFE.xsd',
				cache: true,
				async: false,
				success: function( data ) {	
					//schema file correctly loaded, 
					//read  the passed file
					var schemaContent = data.toString();
					
					var reader = new FileReader();
					reader.onloadend = function()
					{
						var fileContent = reader.result;
						var xmlFileName = file.name;
						var schemaFileName = "ComauRoboSAFE.xsd";
						if (xmllint.validateXML) {
							var Module = {
									xml: fileContent,
									schema: schemaContent,
									arguments: ["--noout", "--schema", schemaFileName, xmlFileName]
								};
							var result = xmllint.validateXML(Module);
							
							//close wait dialog
							closeGenericWait();
							
							if(result.errors){
								//something is wrong with the XML or XSD file, show a message
								_privShowErrorMessage(result.errors, xmlFileName);
							}else{
								//XML validation OK, send to the controller
								var blobXml = new Blob( [fileContent], {type: "data:application/octet-stream"} );
								_privSendXmlToCrc(blobXml);
							}
						}
					};
					//read the file passed as param
					reader.readAsText(file);
				},
				error: function(xhr, textStatus, errorThrown){
					console.log("Missing schema file");
					//close wait dialog
					closeGenericWait();
				}
			});

		}
		
		var _downloadXMLFromTP5 = function(path) {
			
			//show wait dialog
			dialog = _utility.MessageBox("Please wait, configuration export in progress...","",false);
			dialog.Show();
			
			if (path == undefined || path == "") {
				path = "TD:\\";
			}
			if (!path.endsWith("\\")) {
				path += "\\";
			}
			var fileName = getBackupFileName('.xml');
			var command = "run?xml_export&path="+path+fileName;
				
				$.ajax({
					type: "POST",
					url: command,
					cache : false,
					async: true,
					success: function(data) {
						dialog.Hide()
						_utility.MessageBox('Export success', fileName + ' successfully exported in "' + path + '"', true).Show();
					},
					error: function(xhr, textStatus, errorThrown){
						dialog.Hide()
						_utility.MessageBox('Export failed', 'Something goes wrong during the ' + fileName + ' file export', true).Show();
					}
				});
		}
		
		var _downloadXMLBackup = function() {
			var _configurationFileName = "ComauRoboSAFE.xml";
			var _configurationFilePath = "../data/";
			
			//show wait dialog
			dialog = _utility.MessageBox("Please wait, configuration export in progress...","",false);
			dialog.Show();
			
			//generate fake link for starting the download
			var link = document.createElement('a');
			link.href = _configurationFilePath + _configurationFileName;
			link.download = getBackupFileName('.xml');
			
			//close wait dialog
			dialog.Hide()
			
			if (document.createEvent) {
				var event = document.createEvent('MouseEvents');
				event.initEvent('click', true, true);
				link.dispatchEvent(event);
			}
			else {
				link.click();
			}
		}
		
		var _loadXmlValidatorAndRestore = function (file){
			
			showGenericWait("Please wait, configuration import in progress...");
			//loading xml validator library
			var xmlLintScript = document.createElement('script');
			xmlLintScript.onload = function () {
				_privImportFromXML(file);
			};
			xmlLintScript.onerror = function() {
				//close wait dialog
				closeGenericWait();
				//show an error message
				_utility.MessageBox('Invalid file', 'Impossible to validate file', true).Show();
			};
			
			xmlLintScript.src = "../js/xmllint.js";

			document.head.appendChild(xmlLintScript);
		}
		
		//TSK2039 gestione import/export da TP5
		var _privImportFromTP = function( fullPathName ) {
			
			showGenericWait("Please wait, configuration import in progress...");
			
			$.ajax({
				type: "POST",
				url: "run?xml_to_json&path=" + fullPathName,
				cache : false,
				async: false,
				success: function(data)
				{
					closeGenericWait();
					_privValidateStoreResponseJson(JSON.stringify(data));
				},
				fail: function(xhr, status, error){
					closeGenericWait();
				}
			})
			
		}
		
		return {
			downloadXMLBackup : _downloadXMLBackup,
			downloadXMLFromTP5: _downloadXMLFromTP5,
			validateAndRestore: _loadXmlValidatorAndRestore,
			importFromTP : _privImportFromTP
		};
	}();
	
	var _jsonUtil = function() {
			
		var privHtmlToJsonValue = function (htmlElement) {
			
			var retVal;
			
			if( $(htmlElement).is( "input[type=text]" ) ) {

				retVal = parseInt( $(htmlElement).val(), 10 );

			} else if ( $(htmlElement).is( "input[type=checkbox]" ) ) {

				retVal = $(htmlElement).prop('checked');

			} else if ( $(htmlElement).is( "select" ) ) {
				
				retVal = privGetJSONSelectValue( $(htmlElement).val() );

			} else {
				retVal = $(htmlElement).val() === "true";
			}
			return retVal;
		};
	
		var privGetJSONSelectValue = function (htmlValue){
			var value = htmlValue;
			
			if(value == 'true' || value == 'false') {
				retVal = (value == 'true');
			}else{
				var intVal = parseInt(value);
				
				if ( isNaN(intVal) ) {
					retVal = value; //puo essere diverso da valore booleano...
				} else {
					retVal = intVal;
				}	
			}
			return retVal;
		};

		return {
			getHtmlToJsonValue : privHtmlToJsonValue,
			getJSONSelectValue : privGetJSONSelectValue
		};
	}();

	var _robot = function() {

		var _state = 0;

		var ROBOT_PROG_MODE = 0x8000;

		var ROBOT_DRIVES_OFF = 0x40000000;

		var arm_safe_mask = null;

		var jointMask = [];

		var kineMask = [];

		var safe_cart_keyen = null;

		var strokeEnds;
		
		var jointSpeedLimitMax = new Array();
		
		var isTP = false;
		
		var isRbtAura = false;
		
		var isRbtCobot = false;
		
		var isApc2100 = false;
		
		var isAcoposP3 = false;
		
		var isURDI = false;
		
		var isOptProfiSafe = false;
		
		var isErmEnabled = false;

		var stopWaiting = false;

		var rbModel;
		
		var rbVariant;
		
		var isPal4 = false;

		var isPal5 = false;
		
		const AURA_MAX_SPEED = 500;
		
		const COBOT_MAX_SPEED = 500;
		
		const NORMAL_MAX_SPEED = 5000;  //TSK6866
		
		var _initRobot = function() {
			//inserisco qui tutte le chiamate da fare una volta all'inizio della connessione
			_updateIsTP();
			_updateStrokeEnd();
			_updateHasSafeAxis();
			_updateIsSafeKeyen();
			_updateCntrlCnfg2();
			_updateCntrlSize();
			_updateJointSpeedLimitMax();
			//NB: l'ordine è importante
			_updateJointMask(); //syncronous call
			_updateRbVariant(); //syncronous call
			_updateRbModel(); //syncronous call
			_createKineMask(isPal4,isPal5); //needs o be called after updateJointMask and updare RB_VARIANT RB_MODEL
		}

		var _updateStatus = function() {

			$.ajax(
			{
				url: 'get?sys_state', 
				cache : false,
				async: false,
				success: function(data)
				{        
					_state = parseInt(data);      		     
				}
			});  
		};

		var _isTPConnected = function() {
			return isTP;
		}

		var _updateIsTP = function() {
			isTP = false;
			$.ajax(
			{
				url: 'get?is_tp', 
				cache : false,
				async: false,
				success: function(data)
				{        
					
					isTP = data == "true";   
					
				}
			});  
		}

		var _canDownload = function () {

			// verifico che sia in programmazione
			if ((_state & ROBOT_PROG_MODE) == 0)
			{
				_utility.MessageBox("Info", "System must be in PROGR mode", true).Show();
				// alert('System must be in programming mode');
				return false;
			}
			
			// verifico che sia in drive off
			if ((_state & ROBOT_DRIVES_OFF) == 0)
			{
				_utility.MessageBox("Info", "System must be in driveOFF", true).Show();
				// alert('System must be in drives off');
				return false;
			}

			return true;
		};

		var _updateHasSafeAxis = function() {
			// carico la configurazione safe degli assi
			$.ajax(
			{
				url: 'get?arm_safe_mask', 
				cache : false,
				async: false,
				success: function(data)
				{        
					arm_safe_mask = JSON.parse(data);
				}
			});  
		}

		var _hasSafeAxis = function() {
		
			if(arm_safe_mask != undefined){
				for (var i = 0;i< arm_safe_mask.length; i++) {
					if(arm_safe_mask[i] != "-"){
						return true;
					}
				}
			}
			return false;
		};

		var _hasRailSafe = function() {

			return (arm_safe_mask[6] != '-');
		};
		
		var _updateIsSafeKeyen = function() {
			// carico la licenza safe cartesian
			$.ajax(
			{
				url: 'get?safe_cart_keyen', 
				cache : false,
				async: false,
				success: function(data)
				{        
					safe_cart_keyen = JSON.parse(data);
				}
			});  
		};

		var _isSystemSafeKeyen = function() {

			if(safe_cart_keyen != undefined && safe_cart_keyen == "1") {
				return true;
			}
			return false;
		};
		
		var _updateCntrlCnfg2 = function() {
			$.ajax(
			{
				url: 'get?sysvar=CNTRL_CNFG2', 
				cache : false,
				async: false,
				success: function(data)
				{   
					var ctrlcfg2 = JSON.parse(data); 
					ctrlcfg2 = parseInt(ctrlcfg2);    
					
					isOptProfiSafe = (ctrlcfg2 & 0x2000) !=0;  /* bit 14 : = The ProfiSAFE option has been set */
					isErmEnabled = (ctrlcfg2 & 0x4000) !=0;    /* bit 15 : = The System Signals (ex-ERM) option has been set */
					isRbtAura = (ctrlcfg2 & 0x8000) !=0;       /* bit 16 : = Robot con opzione AURA + SL2 8101 */
					isRbtCobot = (ctrlcfg2 & 0x200000) !=0;    /* bit 22 : = Robot con opzione COBOT+X20DO4331 */
					
					// Il test sul bit che battezza APC2100 e' ambiguo perche' indica azionamenti del tipo ACOPOS.P3 che sono per R1C/S1C ma anche per il nuovo C5GPlus Rel3.0
          //per identificare bene un R1C/S1C si può usare la variabile $CNTRL_SIZE che contiene ora (dalla 4.21 di System) l'identificativo della tipologia  di controllo
          //isApc2100 = (ctrlcfg2 & 0x2) == 0;         /* bit 2  : = 0 AcoposP3 (APC2100) ; = 1 AcoposMulti (APC910) */
          isAcoposP3 = (ctrlcfg2 & 0x2) == 0;         /* bit 2  : = 0 AcoposP3 (APC2100) ; = 1 AcoposMulti (APC910) */

					isURDI = (ctrlcfg2 & 0x04000000) !=0;      /* bit 27 : = SDR TIA */
				}
			});  
		};
    // TSK5866 
	  var _updateCntrlSize = function() {
			$.ajax(
			{
				url: 'get?sysvar=CNTRL_SIZE', 
				cache : false,
				async: false,
				success: function(data)
				{ 
				  try {
				    // faccio il try della CNTRL_SIZE perche' su 411.xxx la sysvar non esiste
				    // $CNTRL_SIZE e' stata introdotta dall 4.21 e vale  
            // 0 per i controlli rel 1 e 2 con i multi
            // 7 per R1C
            // 1..6 per tutti i controlli rel3
            
            var ctrlsize = JSON.parse(data); 
            ctrlsize = parseInt(ctrlsize);    
        
            isApc2100 = (ctrlsize == 7);
          } catch (e) {
            // se la get e' fallita allora verifico la var isAcoposP3 dal bit della $CNTRL_CNFG2
            isApc2100 = isAcoposP3;
          }
				}
			});  
		};
		
		var _updateJointSpeedLimitMax = function() {
			//this function read and calculate the limits of the angular speed per axes
			var mtrSpeedLim;
			var txRate;
			
			if (_isCobot()) {
			  //this value are the max value of BodySpeed Page
			  jointSpeedLimitMax.push(45); //Ax 1
			  jointSpeedLimitMax.push(63); //Ax 2
			  jointSpeedLimitMax.push(97); //Ax 3
			  jointSpeedLimitMax.push(350); //Ax 4
			  jointSpeedLimitMax.push(639); //Ax 5
			  jointSpeedLimitMax.push(600); //Ax 6
			  
			} else {
        
			
			  $.ajax(
			  		{
			  			url: 'get?sysvar=MTR_SPD_LIM', 
			  			cache : false,
			  			async: false,
			  			success: function(data)
			  			{   
			  				mtrSpeedLim = JSON.parse(data).MTR_SPD_LIM;
			  			}	
			  });
			  
			  $.ajax(
			  		{
			  			url: 'get?sysvar=TX_RATE', 
			  			cache : false,
			  			async: false,
			  			success: function(data)
			  			{   
			  				txRate = JSON.parse(data).TX_RATE;
			  			}	
			  });
			  
			  if(mtrSpeedLim != undefined && txRate != undefined) {
			  	for (var i = 0; i < mtrSpeedLim.length; i++) {
			  		//(      $ARM_DATA[1].MTR_SPD_LIM[1] / ABS($ARM_DATA[1].TX_RATE[1]) ) * 360 / 60
			  		var calcValue = (mtrSpeedLim[i] / Math.abs(txRate[i])) * 360 /60;
			  		jointSpeedLimitMax.push(parseInt(calcValue));
			  	}
			  }
			
      }
		}

		var _updateRbVariant = function () {
			const TTK_PARLGRM2 = 0x80000000;
			$.ajax(
			{
				url: 'get?sysvar=RB_VARIANT',
				cache: false,
				async: false,
				success: function (data) {
					rbVariant = data;
					isPal4 = ((data & TTK_PARLGRM2) != 0);
				}
			});
		};
		
		var _updateRbModel = function () {
			const TTL_PAL5AX = 20048;
			$.ajax(
			{
				url: 'get?sysvar=RB_MODEL',
				cache: false,
				async: false,
				success: function (data) {
					rbModel = data;
					//TSK2686 read for pal5
					isPal5 = (data == TTL_PAL5AX);
				}
			});
		};
		
		//needs to be called after update JNT_MASK and update RB_VARIANT RB_MODEL
		var _createKineMask = function ( _isPal4, _isPal5) {
			kineMask = [];
			
			for (var i=0; i < 10; i++) {
				kineMask.push(jointMask[i]);
			}
			//TSK2686 disable kinematic point input field if pal5
			if ( _isPal4 || _isPal5 ) {
				kineMask[2] = false;
				kineMask[3] = false;
				kineMask[4] = true;
			}
		};

		var _updateJointMask = function () {
			$.ajax(
			{
				url: 'get?sysvar=JNT_MASK',
				cache: false,
				async: false,
				success: function (data) {
					//pulisco l'array
					jointMask = [];
					var intData = parseInt(data);
					//trasformo da stringa di bit a array di boolean
					for (var i = 0; i < 10; i++) {
						//creo un array di boolean che rappresenta la maschera di bit
						if (intData & (1 << i)) {
							jointMask.push(true);
						} else {
							jointMask.push(false);
						}
					}
				}
			});
		};

		var _getJointMask = function (index) {
			if (index < jointMask.length) {
				return jointMask[index];
			}
			return false;
		};

		var _getKineMask = function (index) {
			if (index < kineMask.length) {
				return kineMask[index];
			}
			return false;
		};

		var _dlg;

		var _waitReboot = function() {

			_dlg = _utility.MessageBox("Safe logic reboot in progress...", "Please wait", false);
			_dlg.Show();

			var _interval = setInterval(function() {
				if (sl_state == 240) {
					clearInterval(_interval);
					_dlg.Hide();
				}
			}, 500);
		};

		var _waitJson = function() {
			stopWaiting = false;
			_dlg = _utility.MessageBox("Data loading from controller in progress...", "Please wait", false);
			_dlg.Show();

			var _interval = setInterval(function() {
				if (_configurationManager.IsDataLoaded() || stopWaiting) {
					clearInterval(_interval);
					_dlg.Hide();
				}
			}, 500);
		};

		var _obdCount = new Array(7);

		var _notifyTooManyActiveOBD = function() {
			
			var cnt = 0;

			for (var i = 0; i < _obdCount.length; i++)
			{
				if (_obdCount[i])
				{
					cnt++;
				}
			}

			if (cnt > 2)
			{
				_utility.MessageBox("Info", "Take care that having more than 2 OBD active at same time can cause loss of performance", true).Show();
				// alert("Take care that having more than 2 OBD active at same time can cause loss of performance");
			}
		};

		var _setOBD = function(idx, val) {
			_obdCount[idx] = val;
		};

		var _getOBD = function(idx) {
			return _obdCount[idx];
		};

		var _checkData = function (objectJSON) {

			if ( objectJSON != undefined ) {

				var properties = objectJSON["Properties"];

				if (properties.enabled)
				{
					_obdCount[0] = properties.obdOn;
				}
				else
				{
					_obdCount[0] = false;
				}

				var dynamicArea = objectJSON["DynamicVolumes"];

				for ( var i = 0; i < dynamicArea.length; i++ ) 
				{
					if (dynamicArea[i].flags.enabled)
					{						
						_obdCount[i + 1] = dynamicArea[i].flags.obdOn;
					}
					else
					{
						_obdCount[i + 1] = 	false;
					}
				}
			}
		};

		var _updateStrokeEnd = function() {

			$.ajax(
			{
				url: 'get?stroke_end', 
				cache : false,
				async: false,
				success: function(data)
				{        
					strokeEnds = JSON.parse(data);     		     
				}
			});  
		};

		var _strokeEndLowValues = function( axesIndex ){
			if(strokeEnds!=undefined){
				return Math.floor(strokeEnds.neg[axesIndex]);	
			}
			return 0;
		};

		var _strokeEndHighValues = function( axesIndex ){
			if(strokeEnds!=undefined){
				return Math.floor(strokeEnds.pos[axesIndex]);	
			}
			return 0;
		};
		
		var _isAura = function() {
			return isRbtAura;
		}
		
		var _isCobot = function() {
			return isRbtCobot;
		}
		
		var _isApc2100 = function() {
			return isApc2100;
		}
		
		var _isURDI = function() {
			return isURDI;
		}
		
		
		var _isProfiSafe = function() {
			return isOptProfiSafe;
		}	
		
		var _isErmEnabled = function() {
			return isErmEnabled;
		};
		
		var _getJointSpeedLimitMax = function( axesIndex ){
			if(jointSpeedLimitMax != undefined && jointSpeedLimitMax[axesIndex] != undefined){
				return jointSpeedLimitMax[axesIndex];	
			}
			return 0;
		};
		
		var _isAxisRot = function (idAxis) {
			var ret = false;
			$.ajax(
			{
				url: 'get?sysvar=A_ALONG_2D',
				cache : false,
				async: false,
				success: function(data)
				{   
					var variable = JSON.parse(data).A_ALONG_2D[1][idAxis];
					
					ret = (variable === 0); 
				}
			});  
			return ret;
		};
		
		/*TSK2683 return 500 as high speed maximum value if robot is an aura*/
		var _getMaxHighSpeed = function() {
			
			
			var highSpeed = NORMAL_MAX_SPEED;
			
			if (_isAura()) {
				highSpeed = AURA_MAX_SPEED;
			}
			else if (_isCobot()) {
				highSpeed = COBOT_MAX_SPEED;
			}
			
			return highSpeed; 
		};
		
		_initRobot();

		return {

			Init: _initRobot,
			UpdateStatus: _updateStatus,			
			CanDownload: _canDownload,
			HasSafeAxis: _hasSafeAxis,
			HasRailSafe: _hasRailSafe,
			IsSystemSafeKeyen: _isSystemSafeKeyen,
			IsKeyenAndSafeAxes: function(){return _isSystemSafeKeyen() && _hasSafeAxis(); },
			IsTPConnected: _isTPConnected,
			WaitReboot: _waitReboot,
			WaitJson: _waitJson,
			StopWaitingJson: function () { stopWaiting = true; },
			CheckData: _checkData,
			SetOBD: _setOBD,
			GetOBD: _getOBD,
			NotifyTooManyActiveOBD: _notifyTooManyActiveOBD,
			StrokeEndHighValues: _strokeEndHighValues,
			StrokeEndLowValues: _strokeEndLowValues,
			GetJointSpeedLimitMax: _getJointSpeedLimitMax,
			IsErmEnabled: _isErmEnabled,
			IsAura: _isAura,
			IsCobot: _isCobot,
			IsApc2100: _isApc2100,
			IsURDI: _isURDI,
			IsProfiSafe: _isProfiSafe,
			IsAxisRot: _isAxisRot,
			GetJointMask: _getJointMask,
			GetKineMask: _getKineMask,
			GetMaxHighSpeed: _getMaxHighSpeed
		};

	}();

	var _validator = function() {

		var _validateXYZ = function(text) {
			
			var rv = false;

			if (!isNaN(text))
			{
				var v = parseInt(text, 10);

				rv = (v >= -500000) && (v <= 500000);
			}

			return rv;
		};

		var _validateRPY = function(text) {
			
			var rv = false;

			if (!isNaN(text))
			{
				var v = parseInt(text, 10);

				rv = (v >= -180) && (v <= 180);
			}

			return rv;
		};

		var _validateRadius = function(text) {
			
			var rv = false;

			if (!isNaN(text))
			{
				var v = parseInt(text, 10);

				rv = (v >= 0) && (v <= 5000);
			}

			return rv;
		};
		
		var _validateDimension = function(text) {
			
			var rv = false;

			if (!isNaN(text))
			{
				var v = parseInt(text, 10);

				rv = (v >= 100) && (v <= 500000);
			}

			return rv;
		};	
		
		//TSK2063 migliorati i controlli sulle velocità
		var _validateHighSpeed = function(speed) {
			
			var rv = false;
			
			var lowSpeedObj = _managers.speedManager.ToObjectJSON().LowSpeed;
			if(lowSpeedObj[0] != undefined){
				
				var lowSpeed = 2;
				if(lowSpeedObj[0].flags.enabled == true){
					//minimum higspeed value is the current lowspeed value
					//TSK2685
					lowSpeed = lowSpeedObj[0].flags.speedLimit;
				}
	
				if (!isNaN(speed) && lowSpeed != undefined)
				{
					var v = parseInt(speed, 10);
					
					rv = (v >= lowSpeed) && (v <= _robot.GetMaxHighSpeed());
				}
			} else {
				//this case happens when reading data from controller, and some values are not correctly initialized, we return "OK"
				rv = true;
			}

			return rv;
		};
		
		var _validateLowSpeed = function(speed) {
			
			var rv = false;

			var highSpeedObj = _managers.speedManager.ToObjectJSON().HighSpeed;
			if(highSpeedObj[0] != undefined) {
				
				var highSpeed = _robot.GetMaxHighSpeed();
				if(highSpeedObj[0].flags.enabled == true){
					//minimum lowspeed value is the current highspeed value
					//TSK2685
					highSpeed = highSpeedObj[0].flags.speedLimit;
				}
				
				if (!isNaN(speed) && highSpeed != undefined ) {
					var v = parseInt(speed, 10);
					
					//TSK5554
			    if (_robot.IsURDI()){
             highSpeed = 250;
          }
					
					rv = (v >= 2) && (v <= highSpeed);
				}
			}else{
				//this case happens when reading data from controller, and some values are not correctly initialized, we return "OK"
				rv = true;
			}
			return rv;
		};

//		var _validateEmergencyBrakeTime = function(text){
//			var rv = false;
//
//			if (!isNaN(text))
//			{
//				var v = parseInt(text, 10);
//
//				rv = (v >= 0) && (v <= 3000);
//			}
//
//			return rv;
//		};

		var _validateStrokeEndLow = function(axesIndex, text, highValue){
			var rv = false;

			if (!isNaN(text) && !isNaN(highValue))
			{
				var v = parseInt(text, 10);
				var vHigh = parseInt(highValue, 10);
				var strokeLow = _robot.StrokeEndLowValues(axesIndex);

				if( v >= strokeLow && v <= vHigh ){
					rv = true;
				}
				
			}

			return rv;
		};

		var _validateStrokeEndHigh = function(axesIndex, text, lowValue){
			var rv = false;

			if (!isNaN(text) && !isNaN(lowValue))
			{
				var v = parseInt(text, 10);
				var vLow = parseInt(lowValue, 10);
				var strokeHigh = _robot.StrokeEndHighValues(axesIndex);

				if( v <= strokeHigh && v >= vLow ){
					rv = true;
				}
				
			}

			return rv;
		};
		
		var _validateJointSpeedLimitMax = function ( axesIndex, speedValue){
			var rv = false;
			var vLow = 0;
			
			if (!isNaN(speedValue))
			{
				var v = parseInt(speedValue, 10);
				var speedLimit = _robot.GetJointSpeedLimitMax(axesIndex);

				if( v <= speedLimit && v >= vLow ){
					rv = true;
				}
			}

			return rv;
		}

		var _validateTitle = function(text) {
			
			var rv = false;

			if (text.trim() != "" && text.length <= 25)
			{
				rv = true;
			}

			return rv;
		};
		
		var _validateProfSafeAddress = function(text) {
			
			var rv = false;

			if (!isNaN(text))
			{
				var v = parseInt(text, 10);

				rv = (v >= 0) && (v <= 0xFFFF);
			}

			return rv;
		}
		

		return {

			ValidateXYZ: _validateXYZ,
			ValidateRPY: _validateRPY,
			ValidateRadius: _validateRadius,
			ValidateDimension: _validateDimension,
			ValidateLowSpeed: _validateLowSpeed,
			ValidateHighSpeed: _validateHighSpeed,
//			validateEmergencyBrakeTime: _validateEmergencyBrakeTime,
			ValidateStrokeEndHigh: _validateStrokeEndHigh,
			ValidateStrokeEndLow: _validateStrokeEndLow,
			ValidateJointSpeedLimitMax : _validateJointSpeedLimitMax,
			ValidateTitle: _validateTitle,
			ValidatePSFAddress: _validateProfSafeAddress
		};

	}();

	var _fileUploader = function() {

		var _dialogElement = undefined;

		var _endUploadCallback = undefined;

		function privateCreateDialog() {

			var dialog = $('<div id="scr_uploadfile_dialog" class="' + _cssClass.dialog_hidden + '">')

				.append( 

					$('<div class="' + _cssClass.dialog_content + '"/>')

						.append( $('<p class="' + _cssClass.dialog_title + '">Download parameters</p>') )

						.append( $('<div class="scr_dialog_formrow"/>')
						
							.append( $('<div class="' + _cssClass.dialog_formcell_25 + '"/>') 

								.append( $('<form id="scr_uploadfile_dialog_form" enctype="multipart/form-data">')
								
									.append( $('<input name="file" type="file"/>') 
									)
								)
							)

							.append( $('<div class="' + _cssClass.dialog_formcell_75 + '"/>') 

								.append( '<p id="scr_uploadfile_dialog_filename" class="scr_dialog_formcell_label"></>' )
							)
							.append( $('<div class="' + _cssClass.dialog_formcell_100 + '"/>')

								.append( $('<progress id="scr_uploadfile_dialog_progressbar" value="0" max="100"/>') )
							)
						)
						.append(

							$('<input type="button" value="Cancel" class="scr_dialog_button"/>') 

								.click( function () {

									$("#scr_uploadfile_dialog").removeClass(_cssClass.dialog_shown);
									//$( 'body' ).css({
									//	"overflow": "hidden"
									//});

									$('#scr_uploadfile_dialog_progressbar').attr("value", 0);
									$('#scr_uploadfile_dialog_form')[0].reset();
								})
						)
						.append( $('<input type="button" value="Upload" class="scr_dialog_button"/>') 

								.click(function () {

									var formData = new FormData( $('form')[0] );
									$.ajax({
										url: 'run?cartesian_save',  //Server script to process data
										type: 'POST',
										data: formData,
										//Options to tell jQuery not to process data or worry about content-type.
										cache: false,
										contentType: false,
										processData: false
									})
									.done( function() {

										$("#scr_uploadfile_dialog").removeClass(_cssClass.dialog_shown);
										//$( 'body' ).css({	
										//	"overflow": "hidden"
										//});

										$('#scr_uploadfile_dialog_progressbar').attr("value", 0);
										$('#scr_uploadfile_dialog_form')[0].reset();

										if ( _endUploadCallback != undefined ) {

											_endUploadCallback();
										}
									})
									.fail( function() {

										_utility.MessageBox("Info", "Upload failed!", true).Show();
									// alert("Upload fail!");

										$('#scr_uploadfile_dialog_progressbar').attr("value", 0);
										$('#scr_uploadfile_dialog_form')[0].reset();
									});
								})
						)
				);

			return dialog;
		};

		function privateShow() {

			if( _dialogElement == undefined ) {

				_dialogElement = privateCreateDialog();

				$('body').append( _dialogElement );
			}

			$(_dialogElement).addClass(_cssClass.dialog_shown);
			//$( 'body' ).css({
			//	"overflow": "hidden"
			//});
		};

		return {

			setOnEndUploadCallback: function(callback) { _endUploadCallback = callback; },

			Show: privateShow
		};
	}();

	var _managers = function() {

		var _htmlManagers = {

			///////////////////////////////  INIZIO  Builder custom per mostrare i valori giunti  //////////////////////////////
				
			SectorTableHtmlManager: function(values){
				
				var MIN_SECTOR_DEG = -179;

				var MAX_SECTOR_DEG = 179;
				
				var NUM_MAX_SECTOR = 14;
				
				var MEASURE_UNIT = 'mm'

				var _values = values;

				var _htmlForm = [];	
				
				var thisSlider;
				
				var thisLimitLow;
				
				var thisLimitHigh;
				
				function privateBuildHtmlForm() {
					
					function buildSectorTable (title, elements){
						var sliceNumber = elements[0].val.length;
						
						
						var cellClass = _cssClass.dialog_formcell_100;

						var formGroup = ( $('<div class="' + _cssClass.dialog_form + '"/>')

							.append( $('<div class="' + _cssClass.dialog_formtitle + '" />')

									.append( $('<a/>').text(title) )
								)
						);
					
						var tableContent = $('<table> </table>');
						
						var tableRow = $('<tr></tr>').addClass('sector_table');
						
						thisLimitLow = $('<td id="td_limit_low" style="font-weight: bold; width:9%;"></td>');
						
						thisSlider = $(elements[0].htmlElement);
						
						var tdSectorContent = $('<td id="td_sector" style="width:100%;"></td>')
												.html($(elements[0].htmlElement).css('margin','26px 0px 36px'));
						
						thisLimitHigh = $('<td id="td_limit_high" style="font-weight: bold; width:9%;"></td>');
			
						tableRow.append(thisLimitLow);
						tableRow.append(tdSectorContent);
						tableRow.append(thisLimitHigh);

						tableContent.append(tableRow);

						formGroup.append( $('<div class="' + cellClass + '"/>')
								.append(tableContent));

						//ADD BUTTON
						formGroup.append( $('<input type="button"/>')
							.addClass(_cssClass.dialog_button)
							.css('width', '70px')
							.css('padding','5px')
							.val('Add')
							.click( function(e) {
								e.preventDefault();
								var oldVals = thisSlider.slider("values");
								var max = thisSlider.slider("option" , "max");
								var min = thisSlider.slider("option" , "min");
								var val = 0;
								if ( oldVals.length > 0 ) {
									val = oldVals[oldVals.length-1] + Math.abs((max-min) / NUM_MAX_SECTOR) ;	
								} 
								
								if (val > max) {
									val = max;
								}
								if (oldVals.length < NUM_MAX_SECTOR) {
									oldVals.push(val);
	
									oldVals = oldVals.sort(function(a, b){return a-b});
									var i =  oldVals.indexOf(val)+1;
									rebuildSlider(oldVals);
	
									thisSlider.children('a:nth-child('+ i +')').addClass('bg');
								} else {
									_utility.MessageBox("Info", "Max quantity already reached", true).Show();
									// alert("Max quantity already reached");
								}
							})
						);

						//REMOVE BUTTON
						formGroup.append( $('<input type="button"/>')
							.addClass(_cssClass.dialog_button)
							.css('width', '70px')
							.css('padding','5px')
							.val('Remove')
							.click( function(e) {
								e.preventDefault();
								var oldVals = thisSlider.slider("values");
								var arrSize = oldVals.length;
								
								if(arrSize >0)
								{        
									oldVals = oldVals.sort(function(a, b){return a-b});
									
									oldVals.pop();
					
									rebuildSlider(oldVals);  
								}      
							})
						);

						return formGroup;

					};

					_htmlForm = [];

					for ( var property in _values) {

						if( property!=undefined &&  _values.hasOwnProperty(property) && typeof(_values[property]) !== 'function' ) {
							_htmlForm.push(buildSectorTable( _values[property].label, _values[property].valuesArray));
							setSliderLimits(_values[property].minValue +1, _values[property].maxValue -1, 14, _values[property].unit);
						}
					}
				};

				function showAllValues()
				{
					var valueList = thisSlider.slider("values");    
					var handleList = thisSlider.find('.ui-slider-handle');
				
					for(i = 0; i < valueList.length ; i++)
					{
						var strLength = (''+valueList[i]).length;
						//riadatta la grandezza della textbox
						var textbox = $('<input type="text"/>').css('width', strLength * 8 + 'px').css('height','15px').css('font-size','11px').prop('readonly','true').val(valueList[i]);
						textbox.keydown(function(){
							return false;
						});
						var sliderTextBox =  $('<div class="sliderText"/>').append("&nbsp;").append(textbox);    
						  //"<div style='text-align: left; float: left;'  >&nbsp;  " + "<input type='text' style='width: 25px;height: 20px' value='" + theValues[i] + "' /></div>";
						$(handleList[i]).html(sliderTextBox);
					};
				}
					  
				function showValueSlide(event, ui)
				{
					var strLength = (''+ui.value).length;
					//riadatta la grandezza della textbox
					var textbox = $('<input type="text"/>').css('width', strLength * 8 + 'px').css('height','15px').css('font-size','11px').prop('readonly','true').val(ui.value);
					textbox.keydown(function(){
						return false;
					});
					var sliderTextBox =  $('<div class="sliderText"/>').append("&nbsp;").append(textbox);      
					thisSlider.find('.ui-state-focus').html(sliderTextBox)
				}
				 
				function moveOnTop(event, ui) 
				{
					var parent = thisSlider.find('.ui-state-focus');
					$(".ui-slider-handle").css('z-index','1');
					parent.css('z-index','10');
				}
				
				function rebuildSlider(slValues)
				{
					if(slValues.length == 0){
						// se l'array è vuoto aggiungo un elemento a 0
//						slValues.push(0);
					}
					thisSlider.slider("destroy");
					thisSlider.slider({
						min: MIN_SECTOR_DEG,
						max: MAX_SECTOR_DEG,
						steps: 1,
						values: slValues ,
						create: showAllValues,
						slide: showValueSlide
					}).focusin(moveOnTop);
					thisLimitLow.html(" " + MIN_SECTOR_DEG + MEASURE_UNIT + " ");
					thisLimitHigh.html(" " + MAX_SECTOR_DEG + MEASURE_UNIT + " ");
					
					thisSlider.slider( "option", "disabled", slValues.length == 0);
					showAllValues();
				}
				
				function setSliderLimits(minLimit, maxLimit, numMaxSector, measureUnit){
					//settings passed values.
					MIN_SECTOR_DEG = minLimit;
					MAX_SECTOR_DEG = maxLimit;
					MEASURE_UNIT = measureUnit;
					NUM_MAX_SECTOR = numMaxSector;
					//rebuild the slider.
					var oldVals = thisSlider.slider("values");
					
					for (var i = 0; i < oldVals.length; i++ ) {
						if (oldVals[i] > MAX_SECTOR_DEG || oldVals[i] < MIN_SECTOR_DEG) {
							oldVals.splice(i, 1);
						}
					}
					
					if (oldVals.length < NUM_MAX_SECTOR) {
						//rebuild the slider
						rebuildSlider(oldVals);
					}
					
					
				}
				
				function privateUpdateValuesFromForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								if( typeof(prop.valuesArray[j]) !== 'function' ) {
								
									for(var i=0 ; i < prop.valuesArray[j].htmlElement.length; i++ ) {
										prop.valuesArray[j].val = privateGetValueFromHtmlElement( prop.valuesArray[j].htmlElement );
									}
								}
							}
						}
					}
				};

				function privateGetValueFromHtmlElement(htmlElement) {

					var retVal = undefined;

					if( $(htmlElement).is( ".slider" ) ) {

					   retVal = ($(htmlElement).slider("values"));
					   retVal = retVal.sort(function(a, b){return a-b});
					}

 
					return retVal;
				};

				function privateWriteValuesIntoForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								privateWriteValueIntoHtmlElement( prop.valuesArray[j].val, prop.valuesArray[j].htmlElement );
							}
						}
					}
				};

				function privateWriteValueIntoHtmlElement(valuesArray, htmlElement) {

					if( $(htmlElement).is( ".slider" ) ) {
						rebuildSlider(valuesArray);
					}
				};

				function privateToObjectJSON() {

					return _values.ToObjectJSON();
				};

				privateBuildHtmlForm();

				return {

					getHtml: function () { return _htmlForm; },

					UpdateValues: privateUpdateValuesFromForm,
					WriteValuesIntoForm: privateWriteValuesIntoForm,

					DataToObjectJSON: function() { return privateToObjectJSON(); },
					ObjectJSONToData: function(objectJSON) {  _values.FromObjectJSON(objectJSON); privateBuildHtmlForm(); privateWriteValuesIntoForm(); }
				};
			},

			JointTableHtmlManager: function(values){
				
				var _values = values;

				var _htmlForm = [];

				var colAxesIdx = 0; //identificatore della colonna delle checkbox di enable
						
				var colEnableIdx = 1; //identificatore della colonna delle checkbox di enable

				var colConditionIdx = 2; //identificatore della colonna delle checkbox di enable
					
				var colWorkspaceIdx = 3; //identificatore della colonna per la select inside outside

				var colLowLimitIdx = 4; //identificatore della colonna delle checkbox di enable
						
				var colHighLimitIdx = 5; //identificatore della colonna delle checkbox di enable
		
				function getTableWidth(tableIndex){
					var ret = '18%';
					switch(tableIndex){
						case colAxesIdx:
							ret = '8%';
							break;
						case colEnableIdx:
							ret = '13%';
							break;
						case colConditionIdx:
							ret = '12%';
							break;
						case colWorkspaceIdx:
							ret = '17%';
							break;
						case colLowLimitIdx:
						case colHighLimitIdx:
							ret = '25%';
							break;
					}
					return ret;
				};
				
				function privateBuildHtmlForm() {
					
					function buildJointTable (elements){
						var axesNumber = elements[0].htmlElement.length;
						
						var htmlTable = $('<div class="' + _cssClass.dialog_form + '"/>');

						var tableContent = $('<table>').css('width','100%');

						var enableDisableRow = function (checkbox, enabled) {
							//var checkbox = sender.target;
							if (checkbox.type == "checkbox") {

								var tRow = checkbox.parentElement.parentElement;

								for (var c = colEnableIdx + 1; c < tRow.children.length; c++) {
									// parte da 2 per escludere table header e se stesso
									var child = tRow.children[c];
									$(child.firstChild).prop("disabled", !enabled);
								}
							}
						};
						
						// appendo l'header della tabella
						for(var j=0; j<elements.length;j++){
							var tableHeader = $('<th></th>').addClass('joint_table').css('width', getTableWidth(j))
							.html(elements[j].label);
							tableContent.append(tableHeader);
						}
						
						for(var row=0; row < axesNumber; row++){

							var tableRow = $('<tr></tr>').addClass('joint_table');
							
							for(var j=0; j<elements.length;j++){
								var component = elements[j].htmlElement[row]

								var data = $('<td></td>').addClass('joint_table')
								.html(component);
								
								if ( j == colEnableIdx ) {
									// listener per l'abilitazione o
									// disabilitazione della riga
									$(component).unbind('change');
									$(component).on("change", function (sender) {
										var checkbox = sender.target;
										enableDisableRow(checkbox, checkbox.checked);
									});
									//TTP15424 abilitazione secondo flag di enable generico
									$(component).unbind('jointDisable');
									$(component).on('jointDisable', function (sender, disabled) {
										var checkbox = sender.target;
										$(checkbox).prop("disabled", disabled);
										//disabled == true means that the generic enabled checkbox is not checked
										if (disabled) {
											enableDisableRow(checkbox, false);
										} else {
											enableDisableRow(checkbox, checkbox.checked);
										}
									});

								} else if ( j == colConditionIdx ) {
									// listener per l'abilitazione o
									// disabilitazione della condition
									$(component).unbind('change');
									$(component).on("change", function(sender){
										var checkbox = sender.target;
										if(checkbox.type == "checkbox" ){
											var tRow = checkbox.parentElement.parentElement;
											var child = tRow.children[colEnableIdx];
											//disabilito la checkbox di enable della riga
											$(child.firstChild).prop("disabled", checkbox.checked);
											privateShowHideConditionHeader(tRow.parentElement);
										}
									});
								} else if ( j == colLowLimitIdx ) {

									var lowLimitInitialValue;

									//listener per il controllo dei valori di stroke End
									$(component).unbind('focusout');
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusout( function(sender){
										var textBox = sender.target;
										
										var tRow = textBox.parentElement.parentElement;
										
										var axIndex = $(tRow.children[colAxesIdx].firstChild).val(); 

										var child = tRow.children[colHighLimitIdx].firstChild;

										var isValid = _validator.ValidateStrokeEndLow(axIndex -1 , $(textBox).val() , $(child).val());
										
										if(!isValid){
											if(!_validator.ValidateStrokeEndHigh(axIndex -1 , lowLimitInitialValue , $(child).val() )){
												lowLimitInitialValue = _robot.StrokeEndLowValues(axIndex-1);
											}
											$(textBox).val(lowLimitInitialValue);
											$(this).preventFocus();
											_utility.MessageBox("Info", "Invalid limit value", true).Show();
										}
										
									});

									$(component).unbind('focusin');
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusin( function(sender){
										
										lowLimitInitialValue = $(sender.target).val();

									});

								} else if ( j == colHighLimitIdx ) {

									var highLimitInitialValue;

									// listener per il controllo dei valori di
									// stroke End
									$(component).unbind('focusout'); 
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusout( function(sender){
										var textBox = sender.target;
										
										var tRow = textBox.parentElement.parentElement;

										var axIndex = $(tRow.children[colAxesIdx].firstChild).val();
										
										var child = tRow.children[colLowLimitIdx].firstChild;

										var isValid = _validator.ValidateStrokeEndHigh(axIndex -1 , $(textBox).val() , $(child).val() );
										
										if(!isValid){
											if(!_validator.ValidateStrokeEndHigh(axIndex -1 , highLimitInitialValue , $(child).val() )){
												highLimitInitialValue = _robot.StrokeEndHighValues(axIndex-1);
											}
											$(textBox).val(highLimitInitialValue);
											$(this).preventFocus();
											_utility.MessageBox("Info", "Invalid limit value", true).Show();
										}
										
									});

									$(component).unbind('focusin'); 
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusin( function(sender){
										
										highLimitInitialValue = $(sender.target).val();

									});

								}
								tableRow.append(data);
							}

							tableContent.append(tableRow);
						}


						htmlTable.append(tableContent);

						return htmlTable;
					};

					_htmlForm = [];

					for ( var property in _values) {

						if( property!=undefined &&  _values.hasOwnProperty(property) && typeof(_values[property]) !== 'function' ) {
							_htmlForm.push(buildJointTable(_values[property].valuesArray));
						}
					}
				};

				function privateInitStrokeEndLabel() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for(var i=0 ; i < prop.valuesArray[colLowLimitIdx].htmlElement.length; i++ ) {
							
								var axLbl = $(prop.valuesArray[colAxesIdx].htmlElement[i]);

								var axIndex = parseInt(axLbl.val().trim());
								
								var strokeLow = _robot.StrokeEndLowValues(axIndex-1);
								var strokeHigh = _robot.StrokeEndHighValues(axIndex-1);
								
								if(!_robot.IsAxisRot(axIndex-1)){
									strokeLow += ' mm';
									strokeHigh += ' mm';
								}
								
								if(strokeLow!=undefined){
									$(prop.valuesArray[colLowLimitIdx].htmlElement[i]).parent().append(' (' + strokeLow + ')');	
								}
								if(strokeHigh!=undefined){
									$(prop.valuesArray[colHighLimitIdx].htmlElement[i]).parent().append(' (' + strokeHigh + ')');
								}
							}
						}
					}
				};

				function privateHideConditionFromForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for(var i=0 ; i < prop.valuesArray[colAxesIdx].htmlElement.length; i++ ) {
							
								var axLbl = $(prop.valuesArray[colAxesIdx].htmlElement[i]);
								var axIndex = parseInt(axLbl.val().trim());

								if(axIndex !== 1 && axIndex !== 7){
									$(prop.valuesArray[colConditionIdx].htmlElement[i]).css("visibility", "hidden");
								
								}

							}
						}
					}
				};

				function privateShowHideConditionHeader(parentTable) {
					
					var properties = Object.keys(_values);
					//find the condition header only inside this table element, not in the whole DOM
					var condLbl = $(parentTable).find('#conditionLabel');
					var isChecked = false;

					
						for ( var i=0; i < properties.length; i++ ) {
	
							if( typeof(_values[ properties[i] ]) !== 'function' ) {
	
								var prop = _values[ properties[i] ];
	
								for(var i=0 ; i < prop.valuesArray[colAxesIdx].htmlElement.length; i++ ) {
								
									var axLbl = $(prop.valuesArray[colAxesIdx].htmlElement[i]);
									var axIndex = parseInt(axLbl.val().trim());
	
									if(axIndex == 1 && condLbl.length==0){
										// appendere a questa riga un divisore
										// per gli assi condition
										var tRow = axLbl.closest("tr");
										var conditionRow = $("<tr id='conditionLabel'></tr>").css('display','none').css('font-weight','bold')
															.append('<td>To be</td>').append('<td>controlled</td>');
										tRow.after(conditionRow);
										condLbl = $("#conditionLabel");
									}
									
									var value = $(prop.valuesArray[colConditionIdx].htmlElement[i]).prop('checked');
									if(value){
										isChecked=true;
									}
								}
							}
						}
					

					if(condLbl!= undefined && condLbl.length > 0){
						//dovrebbe sempre essere true, lo aggiungo sopra
						if(isChecked){
							condLbl.show();
						}else{
							condLbl.hide();
						}
					}
				};
				
				function privateUpdateValuesFromForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								if( typeof(prop.valuesArray[j]) !== 'function' ) {
								
									for(var i=0 ; i < prop.valuesArray[j].htmlElement.length; i++ ) {
										prop.valuesArray[j].val[i] = privateGetValueFromHtmlElement( prop.valuesArray[j].htmlElement[i] );
									}
								}
							}
						}
					}
				};

				function privateGetValueFromHtmlElement(htmlElement) {

					return _jsonUtil.getHtmlToJsonValue(htmlElement);
				};

				function privateWriteValuesIntoForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								privateWriteValueIntoHtmlElement( prop.valuesArray[j].val, prop.valuesArray[j].htmlElement );
							}
						}
					}
				};

				function privateWriteValueIntoHtmlElement(valuesArray, _htmlElementsArray) {

					for( var i=0 ; i < valuesArray.length ; i++ ) {
						
						if( $(_htmlElementsArray[i]).is( "input[type=text]" ) ) {
	
							$(_htmlElementsArray[i]).val( valuesArray[i].toString() ).trigger('change');
	
						} else if ( $(_htmlElementsArray[i]).is( "input[type=checkbox]" ) ) {
	
							$(_htmlElementsArray[i]).prop('checked', valuesArray[i]).trigger('change');
	
						} else if ($(_htmlElementsArray[i]).is( "select" ) ) {

							$(_htmlElementsArray[i]).val( valuesArray[i].toString() ).trigger('change');

						} else {

							$(_htmlElementsArray[i]).val(valuesArray[i]).trigger('change');
						}
					}
				};

				function privateToObjectJSON() {

					return _values.ToObjectJSON();
				};

				privateBuildHtmlForm();

				return {

					getHtml: function () { return _htmlForm; },

					UpdateValues: privateUpdateValuesFromForm,
					WriteValuesIntoForm: privateWriteValuesIntoForm,

					DataToObjectJSON: function() { return privateToObjectJSON(); },
					ObjectJSONToData: function(objectJSON) {  _values.FromObjectJSON(objectJSON); privateBuildHtmlForm(); privateWriteValuesIntoForm(); privateInitStrokeEndLabel(); privateHideConditionFromForm(); }
				};
			},
			
			JointSpeedTableHtmlManager: function(values){
				
				//TSK1456 joint speed limitation handling
				
				var _values = values;

				var _htmlForm = [];

				var colAxesIdx = 0; //identificatore della colonna degli indici degli assi
						
				var colEnableIdx = 1; //identificatore della colonna delle checkbox di enable
						
				var colSpeedLimitIdx = 2; //identificatore della colonna dei limiti di velocità
		
				function getTableWidth(tableIndex){
					var ret = '33%';
					switch(tableIndex){
						case colAxesIdx:
							ret = '20%';
							break;
						case colEnableIdx:
							ret = '20%';
							break;
						case colSpeedLimitIdx:
							ret = '60%';
							break;
					}
					return ret;
				};

				function privateBuildHtmlForm() {

					function buildJointSpeedTable (elements){
						var axesNumber = elements[0].htmlElement.length;
						
						var htmlTable = $('<div class="' + _cssClass.dialog_form + '"/>');

						var tableContent= $('<table>').css('width','100%');

						var enableDisableRow = function (checkbox, enabled) {
							//var checkbox = sender.target;
							if (checkbox.type == "checkbox") {

								var tRow = checkbox.parentElement.parentElement;

								for (var c = colEnableIdx + 1; c < tRow.children.length; c++) {
									// parte da 2 per escludere table header e se stesso
									var child = tRow.children[c];
									$(child.firstChild).prop("disabled", !enabled);
								}
							}
						};
						
						
						// appendo l'header della tabella
						for(var j=0; j<elements.length;j++){
							var tableHeader = $('<th></th>').addClass('joint_table').css('width', getTableWidth(j))
							.html(elements[j].label);
							tableContent.append(tableHeader);
						}
						
						for(var row=0; row < axesNumber; row++){

							var tableRow = $('<tr></tr>').addClass('joint_table');
							
							for(var j=0; j<elements.length;j++){
								var component = elements[j].htmlElement[row]

								var data = $('<td></td>').addClass('joint_table')
								.html(component);
								
								if ( j == colEnableIdx ) {
									// listener per l'abilitazione o
									// disabilitazione della riga
									$(component).unbind('change');
									$(component).on("change", function(sender){
										var checkbox = sender.target;
										enableDisableRow(checkbox, checkbox.checked);
									});
									//TTP15424 abilitazione secondo flag di enable generico
									$(component).unbind('jointSpeedDisable');
									$(component).on('jointSpeedDisable', function (sender, disabled) {
										var checkbox = sender.target;
										$(checkbox).prop("disabled", disabled);
										//disabled == true means that the generic enabled checkbox is not checked
										if (disabled) {
											enableDisableRow(checkbox, false);
										} else {
											enableDisableRow(checkbox, checkbox.checked);
										}
									});
									
								} else if ( j == colSpeedLimitIdx ) {

									var speedLimitInitialValue;

									//listener per il controllo dei valori di stroke End
									$(component).unbind('focusout');
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusout( function(sender){
										var textBox = sender.target;
										
										var tRow = textBox.parentElement.parentElement;
										
										var axIndex = $(tRow.children[colAxesIdx].firstChild).val();

										var isValid = _validator.ValidateJointSpeedLimitMax(axIndex -1 , $(textBox).val());
										
										if(!isValid){
											if(!_validator.ValidateJointSpeedLimitMax(axIndex -1 , speedLimitInitialValue)){
												speedLimitInitialValue = _robot.GetJointSpeedLimitMax(axIndex-1)
											}
											$(textBox).val(speedLimitInitialValue);
											$(this).preventFocus();
											_utility.MessageBox("Info", "Invalid speed limit value", true).Show();
										}
										
									});

									$(component).unbind('focusin');
									//necessario per evitare di aggiungere il listener N volte
									$(component).focusin( function(sender){
										
										speedLimitInitialValue = $(sender.target).val();

									});

								}
								tableRow.append(data);
							}

							tableContent.append(tableRow);
						}


						htmlTable.append(tableContent);

						return htmlTable;
					};

					_htmlForm = [];

					for ( var property in _values) {

						if( property!=undefined &&  _values.hasOwnProperty(property) && typeof(_values[property]) !== 'function' ) {
							_htmlForm.push(buildJointSpeedTable(_values[property].valuesArray));
						}
					}
				};

				function privateInitSpeedLimitLabel() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for(var i=0 ; i < prop.valuesArray[colSpeedLimitIdx].htmlElement.length; i++ ) {
							
								var axLbl = $(prop.valuesArray[colAxesIdx].htmlElement[i]);

								var axIndex = parseInt(axLbl.val().trim());
								
								var speedLimMax = _robot.GetJointSpeedLimitMax(axIndex-1);
								
								if(!_robot.IsAxisRot(axIndex-1)){
									speedLimMax += ' mm/s';
								}
								
								if(speedLimMax!=undefined){
									$(prop.valuesArray[colSpeedLimitIdx].htmlElement[i]).parent().append(' (' + speedLimMax + ')');	
								}
							}
						}
					}
				};
				
				function privateUpdateValuesFromForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								if( typeof(prop.valuesArray[j]) !== 'function' ) {
								
									for(var i=0 ; i < prop.valuesArray[j].htmlElement.length; i++ ) {
										prop.valuesArray[j].val[i] = privateGetValueFromHtmlElement( prop.valuesArray[j].htmlElement[i] );
									}
								}
							}
						}
					}
				};

				function privateGetValueFromHtmlElement(htmlElement) {

					return _jsonUtil.getHtmlToJsonValue(htmlElement);
				};

				function privateWriteValuesIntoForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								privateWriteValueIntoHtmlElement( prop.valuesArray[j].val, prop.valuesArray[j].htmlElement );
							}
						}
					}
				};

				function privateWriteValueIntoHtmlElement(valuesArray, _htmlElementsArray) {

					for( var i=0 ; i < valuesArray.length ; i++ ) {
						
						if( $(_htmlElementsArray[i]).is( "input[type=text]" ) ) {
	
							$(_htmlElementsArray[i]).val( valuesArray[i].toString() ).trigger('change');
	
						} else if ( $(_htmlElementsArray[i]).is( "input[type=checkbox]" ) ) {
	
							$(_htmlElementsArray[i]).prop('checked', valuesArray[i]).trigger('change');
	
						} else if ($(_htmlElementsArray[i]).is( "select" ) ) {

							$(_htmlElementsArray[i]).val( valuesArray[i].toString() ).trigger('change');

						} else {

							$(_htmlElementsArray[i]).val(valuesArray[i]).trigger('change');
						}
					}
				};

				function privateToObjectJSON() {

					return _values.ToObjectJSON();
				};

				privateBuildHtmlForm();

				return {

					getHtml: function () { return _htmlForm; },

					UpdateValues: privateUpdateValuesFromForm,
					WriteValuesIntoForm: privateWriteValuesIntoForm,

					DataToObjectJSON: function() { return privateToObjectJSON(); },
					ObjectJSONToData: function(objectJSON) {  _values.FromObjectJSON(objectJSON); privateBuildHtmlForm(); privateWriteValuesIntoForm(); privateInitSpeedLimitLabel(); }
				};
			},

			///////////////////////////////  FINE  Builder custom per mostrare i valori giunti  //////////////////////////////
			
			MulticolumnHtmlManager: function(values) {

				var _values = values;

				var _htmlForm = [];

				function privateBuildHtmlForm() {
					
					function buildSubTable(title, elementsArray) {

						var cellClass = _cssClass.dialog_formcell_33; // 3 elementi

						if ( elementsArray.length === 1 ) { // 1 elemento
							cellClass = _cssClass.dialog_formcell_100;
						} else if ( elementsArray.length === 2 ) { // 2 elementi
							cellClass = _cssClass.dialog_formcell_50;
						} else if(elementsArray.length === 4) { // 4 elementi
							cellClass = _cssClass.dialog_formcell_25;
						}

						var formGroup = ( $('<div class="' + _cssClass.dialog_form + '"/>')

							.append( $('<div class="' + _cssClass.dialog_formtitle + '" />')

									.append( $('<a/>').text(title) )
								)
						);


						for (var i = 0; i < elementsArray.length; i++ ) {

							formGroup.append( $('<div class="' + cellClass + '"/>') 

											.append( $('<label/>').html(elementsArray[i].label) )

											.append( elementsArray[i].htmlElement )
							);
						}

						return formGroup;
					};

					for ( var property in _values) {

						if( _values.hasOwnProperty(property) && typeof(_values[property]) !== 'function' ) {

							_htmlForm.push( buildSubTable( _values[property].label, _values[property].valuesArray ) );
						}
					}
				};

				function privateUpdateValuesFromForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								if( typeof(prop.valuesArray[j]) !== 'function' ) {
								
									prop.valuesArray[j].val = privateGetValueFromHtmlElement( prop.valuesArray[j].htmlElement );
								}
							}
						}
					}
				};

				function privateGetValueFromHtmlElement(htmlElement) {

					return _jsonUtil.getHtmlToJsonValue(htmlElement);
				};

				function privateWriteValuesIntoForm() {

					var properties = Object.keys(_values);

					for ( var i=0; i < properties.length; i++ ) {

						if( typeof(_values[ properties[i] ]) !== 'function' ) {

							var prop = _values[ properties[i] ];

							for ( var j=0; j < prop.valuesArray.length; j++ ) {

								privateWriteValueIntoHtmlElement( prop.valuesArray[j].val, prop.valuesArray[j].htmlElement );
							}
						}
					}
				};

				function privateWriteValueIntoHtmlElement(value, htmlElement) {

					if( $(htmlElement).is( "input[type=text]" ) ) {

						$(htmlElement).val( value.toString() ).trigger('change');

					} else if ( $(htmlElement).is( "input[type=checkbox]" ) ) {

						$(htmlElement).prop('checked', value).trigger('change');

					} else {

						$(htmlElement).val(value).trigger('change');
					}
				};

				function privateToObjectJSON() {

					return _values.ToObjectJSON();
				};

				privateBuildHtmlForm();

				return {

					getHtml: function () { return _htmlForm; },

					UpdateValues: privateUpdateValuesFromForm,
					WriteValuesIntoForm: privateWriteValuesIntoForm,

					DataToObjectJSON: function() { return privateToObjectJSON(); },
					ObjectJSONToData: function(objectJSON) { _values.FromObjectJSON(objectJSON); privateWriteValuesIntoForm(); }
				};
			},

			SinglecolumnHtmlManager: function(values, showValuesInDialog) {

				var _showValuesInDialog = showValuesInDialog;

				var _values = values;

				var _htmlForm = $();

				var _changeCallback;

				function privateBuildHtmlForm(flagsType) {

					function buildSubTable(title, elementsArray) {

						var formGroup = ( $('<div class="' + _cssClass.dialog_form + '"/>')

							.append( $('<div class="' + _cssClass.dialog_formtitle + '" />')

									.append( $('<a/>').text(title) )
								)
						);


						for (var i = 0; i < elementsArray.length; i++ ) {

							if( typeof(elementsArray[i]) !== 'function' ) {

								privateWriteValueIntoHtmlElement( elementsArray[i].val, elementsArray[i].htmlElement );
								var leftCSS = _cssClass.dialog_formcell_50;
								var rightCSS = _cssClass.dialog_formcell_50;
								if(values.Use75_25 != undefined ){
									if(values.Use75_25){
										rightCSS = _cssClass.dialog_formcell_25;
										leftCSS = _cssClass.dialog_formcell_75;
									}
								}
								formGroup
									.append(
											$('<div class="' +  leftCSS + " " + _cssClass.dialog_formcell_left + '">')

											.append( '<label>' + elementsArray[i].label + '</label>')
									)						
									.append(

										$('<div class="' +  rightCSS + " "  + _cssClass.dialog_formcell_right + '">')

											.append( $(elementsArray[i].htmlElement)

												.change( function() {


													///////////////VERIFICARE SE NON ROMPE NIENTE !!!
													if(_showValuesInDialog == undefined || !_showValuesInDialog){
														privateUpdateValuesFromForm();
													}
													if ( _changeCallback != undefined ) {

														_changeCallback( _values, _values.ToObjectJSON() );
													}
												})
											)
									)
								;
							}
						}

						return formGroup;
					};

					_htmlForm = buildSubTable(_values.flagsLabel, _values.elementsArray);
				};

				function privateUpdateValuesFromForm() {

					for ( var i=0; i < _values.elementsArray.length; i++ ) {

						if( typeof(_values.elementsArray[i]) !== 'function' ) {
							_values.elementsArray[i].val = privateGetValueFromHtmlElement( _values.elementsArray[i].htmlElement );
						}
					}
				};

				function privateGetValueFromHtmlElement(htmlElement) {

					return _jsonUtil.getHtmlToJsonValue(htmlElement);
				};

				function privateWriteValuesIntoForm() {

					for ( var i=0; i < _values.elementsArray.length; i++ ) {

						if( typeof(_values.elementsArray[i]) !== 'function' ) {

							privateWriteValueIntoHtmlElement( _values.elementsArray[i].val, _values.elementsArray[i].htmlElement );
						}
					}

					for ( var i=0; i < _values.elementsArray.length; i++ ) {

						if( typeof(_values.elementsArray[i]) !== 'function' ) {

							$(_values.elementsArray[i].htmlElement).trigger('change');
						}
					}
				};

				function privateWriteValueIntoHtmlElement(value, htmlElement) {

					if(value!=null){
						if( $(htmlElement).is( "input[type=text]" ) ) {

							$(htmlElement).val( value.toString() );

						} else if ( $(htmlElement).is( "input[type=checkbox]" ) ) {

							$(htmlElement).prop('checked', value);

						} else {

							$(htmlElement).val(value.toString());
						}
					}
				};

				privateBuildHtmlForm();

				return {

					uId: _values.uId,
					getHtml: function () { return _htmlForm; },

					UpdateValues: privateUpdateValuesFromForm,
					WriteValuesIntoForm: privateWriteValuesIntoForm,

					setChangeCallback: function (callback) { _changeCallback = callback; },
					setEnabled: function(isEnabled) { _values.SetEnabled(isEnabled); },
					setAlwaysActive: function(isAlwayActive) { _values.SetAlwaysActive(isAlwayActive); },

					DataToObjectJSON: function() { return _values.ToObjectJSON(); },
					ObjectJSONToData: function(objectJSON) { _values.FromObjectJSON(objectJSON); privateWriteValuesIntoForm(); }
				};
			}
		};

		var _settings = function() {
			
			var focusInValue;
			
			var privValidateDimension = function(e, obj) {

				var v = $(obj).val();
				var sts = _validator.ValidateDimension(v);

				if (!sts)
				{
					$(obj).preventFocus();
					$(obj).val(focusInValue);
					_utility.MessageBox("Info", v + ' is not a valid value for a dimension', true).Show();
					// alert(v + ' is not a valid value for a dimension');
				}

				// $("#setBtnId").prop("disabled", sts ? false : true);
			};
			
			
			var privValidateRot = function(e, obj, message) {

				var v = $(obj).val();
				var sts = _validator.ValidateRPY(v);

				if (!sts)
				{
					$(obj).preventFocus();
					$(obj).val(focusInValue);
					_utility.MessageBox("Info", v + message, true).Show();
					// alert(v + ' is not a valid value for (R,P,Y)');
				}

				// $("#setBtnId").prop("disabled", sts ? false : true);
			};
			
			var privValidateRPY = function(e, obj) {
				
				privValidateRot(e, obj, ' is not a valid value for (R,P,Y)');
				
			};
			
			var privValidateXYZ = function(e, obj) {

				var v = $(obj).val();
				var sts = _validator.ValidateXYZ(v);

				if (!sts)
				{
					$(obj).preventFocus();
					$(obj).val(focusInValue);
					_utility.MessageBox("Info", v + ' is not a valid value for (X,Y,Z)', true).Show();
				}							
			};
			
			//same of "privValidateXYZ" but with a different message shown
			var privValidateXY = function(e, obj) {

				var v = $(obj).val();
				var sts = _validator.ValidateXYZ(v);

				if (!sts)
				{
					$(obj).preventFocus();
					$(obj).val(focusInValue);
					_utility.MessageBox("Info", v + ' is not a valid value for (X,Y)', true).Show();
				}							
			};
			
			var privValidateRadius = function(e, obj) {

				var v = $(obj).val();
				var sts = _validator.ValidateRadius(v);

				if (!sts)
				{
					$(obj).preventFocus();
					$(obj).val(focusInValue);
					_utility.MessageBox("Info", v + ' is not a valid value for (Radius)', true).Show();
				}							

				// $("#setBtnId").prop("disabled", sts ? false : true);
			};
			
			var ItemPropertiesBuilders = {

				valueObjectBuilders: {

					Value2DPoint: function(initialValue) {

						var _x = {
							val: 1000,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXY(e,this);
								})							
						};

						var _y = {
							val: 1000,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXY(e,this);
								})							
						};

						function privateToObjectJSON() {

							return {
								x: _x.val,
								y: _y.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x" ) { _x.val = objectJSON[property]; }
										else if ( property === "y" ) { _y.val = objectJSON[property]; }
									}
								}
							}
						};

						return {

							location: {
								label: "Location",
								valuesArray: [ _x, _y ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					},

					Value3DPoint: function(initialValue) {

						var _x = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})							
						};

						var _y = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})							
						};

						var _z = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};
						
						var _radius = {
							val:20,
							label: "Radius [mm]",
							htmlElement: $('<input type="text"/>')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateRadius(e,this);
							})
							
						};

						function privateToObjectJSON() {

							return {
								x: _x.val,
								y: _y.val,
								z: _z.val,
								radius: _radius.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x" 		) { _x.val		= objectJSON[property]; }
										else if ( property === "y" 		) { _y.val 		= objectJSON[property]; }
										else if ( property === "z" 		) { _z.val		= objectJSON[property]; }
										else if ( property === "radius" ) { _radius.val = objectJSON[property]; }
									}
								}
							}
						};

						return {

							location: {
								label: "Location",
								valuesArray: [ _x, _y, _z ]
							},
							size: {
								label: "Dimension",
								valuesArray: [_radius]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					},

					ValueDummy: function(initialValue){

						
						function privateFromObjectJSON(objectJSON) {};
						function privateToObjectJSON(objectJSON) {
							return "";
							};
						return  {
							location: {
								label: "Location",
								valuesArray: [ ]
							},
							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};

					},
					
					ValueAxisMonitoring: function(initialValue){
						
						var _canvas = {
								val: 0,
								label: "",
								htmlElement: $('<canvas id="axisMonitoringCanvas" width="550" height="400"/>')
						};
						
						function drawX(ctx, x, y) {
							ctx.beginPath();

							ctx.moveTo(x - 5, y);
							ctx.lineTo(x + 5, y);

							ctx.moveTo(x, y - 5);
							ctx.lineTo(x, y + 5);
							ctx.stroke();
						}
						
						const kinPos = [
							{
								x: 327,
								y: 258
							}, {
								x: 328,
								y: 122
							}, {
								x: 336,
								y: 92
							}, {
								x: 169,
								y: 93
							}, {
								x: 169,
								y: 85
							}, {
								x: 146,
								y: 79
							}
						];
						
						function privUpdateCanvasImage() {
							
							var scaleFactor = 5;
							var canvas = _canvas.htmlElement[0];
							var ctx = canvas.getContext("2d");
							//clear the canvas content
							ctx.clearRect(0, 0, canvas.width, canvas.height);
							//reload the image
							var img = new Image();
							img.onload = function(){
								// when the image is loaded, start redrawing circle and image
								ctx.drawImage(img,0,0);
								//arc(X of the center, Y of the center, diameter, ...)
								ctx.fillStyle = "rgba(255, 0, 0, 0.5)";
								ctx.strokeStyle = "rgb(255, 255, 255)";
								// axis 1 ###
								ctx.beginPath();
								ctx.arc(kinPos[0].x, kinPos[0].y, _axis1.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								// axis 2
								ctx.beginPath();
								ctx.arc(kinPos[1].x, kinPos[1].y, _axis2.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								// axis 3
								ctx.beginPath();
								ctx.arc(kinPos[2].x, kinPos[2].y, _axis3.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								// axis 4
								ctx.beginPath();
								ctx.arc(kinPos[3].x, kinPos[3].y, _axis4.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								// axis 5
								ctx.beginPath();
								ctx.arc(kinPos[4].x, kinPos[4].y, _axis5.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								// axis 6
								ctx.beginPath();
								ctx.arc(kinPos[5].x, kinPos[5].y, _axis6.htmlElement.val() / scaleFactor, 0, 2 * Math.PI);
								ctx.fill();
								
								//all the cross in the center of circles
								drawX(ctx, kinPos[0].x, kinPos[0].y );
								drawX(ctx, kinPos[1].x, kinPos[1].y );
								drawX(ctx, kinPos[2].x, kinPos[2].y );
								drawX(ctx, kinPos[3].x, kinPos[3].y );
								drawX(ctx, kinPos[4].x, kinPos[4].y );
								drawX(ctx, kinPos[5].x, kinPos[5].y );
								
							  };
							  
							img.src = "/safe/images/axis_monitoring.png";
							
						};
						
						var _axis1 = {
							val: 0,
							label: "Joint 1 radius [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRadius(e,this);
									privUpdateCanvasImage();
								})
								.change(function(e){
										privUpdateCanvasImage();
								})
								.prop("disabled", !_robot.GetKineMask(0))
						};
	
						var _axis2 = {
								val: 0,
								label: "Joint 2 radius [mm]",
								htmlElement: $('<input type="text"/>')
									.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
										privUpdateCanvasImage();
									})
									.change(function(e){
										privUpdateCanvasImage();
									})
									.prop("disabled", !_robot.GetKineMask(1))
							};
	
						var _axis3 = {
								val: 0,
								label: "Joint 3 radius [mm]",
								htmlElement: $('<input type="text"/>')
									.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
										privUpdateCanvasImage();
									})
									.change(function(e){
										privUpdateCanvasImage();
									})
									.prop("disabled", !_robot.GetKineMask(2))
							};
	
						var _axis4 = {
								val: 0,
								label: "Joint 4 radius [mm]",
								htmlElement: $('<input type="text"/>')
									.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
										privUpdateCanvasImage();
									})
									.change(function(e){
										privUpdateCanvasImage();
									})
									.prop("disabled", !_robot.GetKineMask(3))
							};
	
						var _axis5 = {
								val: 0,
								label: "Joint 5 radius [mm]",
								htmlElement: $('<input type="text"/>')
									.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
										privUpdateCanvasImage();
									})
									.change(function(e){
										privUpdateCanvasImage();
									})
									.prop("disabled", !_robot.GetKineMask(4))
							};
	
						var _axis6 = {
								val: 0,
								label: "Joint 6 radius [mm]",
								htmlElement: $('<input type="text"/>')
									.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
										privUpdateCanvasImage();
									})
									.change(function(e){
										privUpdateCanvasImage();
									})
									.prop("disabled", !_robot.GetKineMask(5))
							};
		
						function privateToObjectJSON() {
	
							return {
								axis1: _axis1.val,
								axis2: _axis2.val,
								axis3: _axis3.val,
								axis4: _axis4.val,
								axis5: _axis5.val,
								axis6: _axis6.val
							};
						};
	
						function privateFromObjectJSON(objectJSON) {
	
							if ( objectJSON != undefined ) {
	
								for ( var property in objectJSON) {
	
									if ( objectJSON.hasOwnProperty(property) ) {
	
										if      ( property === "axis1"	) { _axis1.val = objectJSON[property]; }
										else if ( property === "axis2"	) { _axis2.val = objectJSON[property]; }
										else if ( property === "axis3"	) { _axis3.val = objectJSON[property]; }
										else if ( property === "axis4"	) { _axis4.val = objectJSON[property]; }
										else if ( property === "axis5"	) { _axis5.val = objectJSON[property]; }
										else if ( property === "axis6"	) { _axis6.val = objectJSON[property]; }
									}
								}
								
								privUpdateCanvasImage();
							}
						};


						
						return {
							
							radius1: {
								label: "Radius",
								valuesArray: [ _axis1, _axis2, _axis3 ]
							},
	
							radius2: {
								label: "",
								valuesArray: [ _axis4, _axis5, _axis6 ]
							},
							
							canvas: {
								label: "Image",
								valuesArray: [ _canvas ]
							},
	
							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						}
					},

					ValueElbowMonitoring: function(initialValue) {

						var _x1 = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						var _y1 = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						var _z1 = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						 var _radius1 = {
							val: 0,
							label: "Radius [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
									.focusin( function(){
										focusInValue = $(this).val();
									})
									.focusout(function(e){
										privValidateRadius(e,this);
									})
						 };
				 
						 var _x2 = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						var _y2 = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						var _z2 = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.addClass('valueAreaClass')
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateXYZ(e,this);
							})		
						};

						 var _radius2 = {
							val: 0,
							label: "Radius [mm]",
							htmlElement: $('<input type="text" />')
							.css("width", "90%")
							.focusin( function(){
								focusInValue = $(this).val();
							})
							.focusout(function(e){
								privValidateRadius(e,this);
							})
						 };

						function privateToObjectJSON() {

							return {
								x1: _x1.val,
								y1: _y1.val,
								z1: _z1.val,
								radius1: _radius1.val,
								x2: _x2.val,
								y2: _y2.val,
								z2: _z2.val,
								radius2: _radius2.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x1"      ) { _x1.val      = objectJSON[property]; }
										else if ( property === "y1"      ) { _y1.val      = objectJSON[property]; }
										else if ( property === "z1"      ) { _z1.val      = objectJSON[property]; }
										else if ( property === "radius1" ) { _radius1.val = objectJSON[property]; }
										else if ( property === "x2"      ) { _x2.val      = objectJSON[property]; }
										else if ( property === "y2"      ) { _y2.val      = objectJSON[property]; }
										else if ( property === "z2"      ) { _z2.val      = objectJSON[property]; }
										else if ( property === "radius2" ) { _radius2.val = objectJSON[property]; }
									}
								}
							}
						};

						 return {

							point1: {
								label: "Point A",
								valuesArray: [ _x1, _y1, _z1, _radius1 ]
							},

							point2: {
								label: "Point B",
								valuesArray: [ _x2, _y2, _z2, _radius2 ]
							},


							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					},
					
					ValueArea: function(initialValue) {

						var _x = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text" />')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})							
						};

						var _y = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};

						var _z = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};

						var _roll = {
							val: 0,
							label: "<font color='red'> Roll [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _pitch = {
							val: 0,
							label: "<font color='green'> Pitch [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _yaw = {
							val: 0,
							label: "<font color='blue'> Yaw [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _width = {
							val: 1000,
							label: "<font color='red'> Width (&Delta;X) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};

						var _depth = {
							val: 1000,
							label: "<font color='green'> Depth (&Delta;Y) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};

						var _height = {
							val: 1000,
							label: "<font color='blue'> Height (&Delta;Z) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('valueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};



						function privateToObjectJSON() {

							return {
								x: _x.val,
								y: _y.val,
								z: _z.val,
								roll: _roll.val,
								pitch: _pitch.val,
								yaw: _yaw.val,
								width: _width.val,
								depth: _depth.val,
								height: _height.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x"      ) { _x.val      = objectJSON[property]; }
										else if ( property === "y"      ) { _y.val      = objectJSON[property]; }
										else if ( property === "z"      ) { _z.val      = objectJSON[property]; }
										else if ( property === "roll"   ) { _roll.val   = objectJSON[property]; }
										else if ( property === "pitch"  ) { _pitch.val  = objectJSON[property]; }
										else if ( property === "yaw"    ) { _yaw.val    = objectJSON[property]; }
										else if ( property === "width"  ) { _width.val  = objectJSON[property]; }
										else if ( property === "height" ) { _height.val = objectJSON[property]; }
										else if ( property === "depth"  ) { _depth.val  = objectJSON[property]; }
									}
								}
							}
						};

						return {
							
							location: {
								label: "Location",
								valuesArray: [ _x, _y, _z ]
							},

							size: {
								label: "Dimension",
								valuesArray: [ _width, _depth, _height ]
							},

							rotation: {
								label: "Rotation",
								valuesArray: [ _roll, _pitch, _yaw ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						}
					},
			
					ValueDynamicArea : function(initialValue) {

						var _x = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})							
						};

						var _y = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};

						var _z = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};

						var _roll = {
							val: 0,
							label: "<font color='red'> Roll [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _pitch = {
							val: 0,
							label: "<font color='green'> Pitch [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _yaw = {
							val: 0,
							label: "<font color='blue'> Yaw [°]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _width = {
							val: 1000,
							label: "<font color='red'> Width (&Delta;X) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};

						var _depth = {
							val: 1000,
							label: "<font color='green'> depth (&Delta;Y) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};

						var _height = {
							val: 1000,
							label: "<font color='blue'> Height (&Delta;Z) [mm]",
							htmlElement: $('<input type="text"/>')
								.addClass('dynamicValueAreaClass')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateDimension(e,this);
								})
						};

						function privateToObjectJSON() {

							return {
								x: _x.val,
								y: _y.val,
								z: _z.val,
								roll: _roll.val,
								pitch: _pitch.val,
								yaw: _yaw.val,
								width: _width.val,
								depth: _depth.val,
								height: _height.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x"      ) { _x.val      = objectJSON[property]; }
										else if ( property === "y"      ) { _y.val      = objectJSON[property]; }
										else if ( property === "z"      ) { _z.val      = objectJSON[property]; }
										else if ( property === "roll"   ) { _roll.val   = objectJSON[property]; }
										else if ( property === "pitch"  ) { _pitch.val  = objectJSON[property]; }
										else if ( property === "yaw"    ) { _yaw.val    = objectJSON[property]; }
										else if ( property === "width"  ) { _width.val  = objectJSON[property]; }
										else if ( property === "height" ) { _height.val = objectJSON[property]; }
										else if ( property === "depth"  ) { _depth.val = objectJSON[property]; }
									}
								}
							}
						};

						return {
							
							location: {
								label: "Location",
								valuesArray: [ _x, _y, _z ]
							},

							size: {
								label: "Dimension",
								valuesArray: [ _width, _depth, _height ]
							},

							rotation: {
								label: "Rotation",
								valuesArray: [ _roll, _pitch, _yaw ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						}
					},
					
					//TSK1924 gestione tool orientation
					ValueVectorW: function(initialValue) {
						
						var _x = {
							val: 0,
							label: "<font color='red'> X [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})							
						};

						var _y = {
							val: 0,
							label: "<font color='green'> Y [mm]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};

						var _z = {
							val: 0,
							label: "<font color='blue'> Z [mm]",
							htmlElement: $('<input type="text"/>')
								.focusout(function(e){
									privValidateXYZ(e,this);
								})
						};
						
						var _image = {
							val: 0,
							label: "",
							htmlElement: $('<img src="/safe/images/vectorw.png" id="vectorWCanvas" width="500" height="500"/>')
						};

						function privateToObjectJSON() {

							return {
								x: _x.val,
								y: _y.val,
								z: _z.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "x"      ) { _x.val      = objectJSON[property]; }
										else if ( property === "y"      ) { _y.val      = objectJSON[property]; }
										else if ( property === "z"      ) { _z.val      = objectJSON[property]; }
									}
								}
							}
						};

						return {
							
							location: {
								label: "Location",
								valuesArray: [ _x, _y, _z ]
							},
							
							illustration: {
								label: "",
								valuesArray: [ _image ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						}
						
					},
					
					//TSK1924 gestione tool orientation
					ValueOrientationOCS: function(initialValue) {
						

						var _roll = {
							val: 0,
							label: "Roll [°]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _pitch = {
							val: 0,
							label: "Pitch [°]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						var _yaw = {
							val: 0,
							label: "Yaw [°]",
							htmlElement: $('<input type="text"/>')
								.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRPY(e,this);
								})
						};

						
						var _alpha = {
							val: 0,
							label: "Safe Angle [°]",
							htmlElement: $('<input type="text"/>')
							.focusin( function(){
									focusInValue = $(this).val();
								})
								.focusout(function(e){
									privValidateRot(e,this,' is not a valid value for Safe Angle');
								})
						};
						
						var _imageRot = {
							val: 0,
							label: "",
							htmlElement: $('<img src="/safe/images/orcs_rpy.png" id="vectorWCanvas" width="500" height="200"/>')
						};
						
						var _imageAngle = {
							val: 0,
							label: "",
							htmlElement: $('<img src="/safe/images/orcs_safe_angle.png" id="vectorWCanvas" width="500" height="270"/>')
						};

						function privateToObjectJSON() {

							return {
								alpha: _alpha.val,
								roll : _roll.val,
								pitch: _pitch.val,
								yaw  : _yaw.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "alpha"  ) { _alpha.val  = objectJSON[property]; }
										else if ( property === "roll"   ) { _roll.val   = objectJSON[property]; }
										else if ( property === "pitch"  ) { _pitch.val  = objectJSON[property]; }
										else if ( property === "yaw"    ) { _yaw.val    = objectJSON[property]; }
									}
								}
							}
						};

						return {
							
							rotation: {
								label: "Rotation",
								valuesArray: [ _roll, _pitch, _yaw ]
							},
							
							illustrationRot: {
								label: "",
								valuesArray: [ _imageRot ]
							},
							
							angle: {
								label: "Angle",
								valuesArray: [ _alpha ]
							},
							
							illustrationAngle: {
								label: "",
								valuesArray: [ _imageAngle ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						}
						
					},
					
					ValueJoints: function(initialValue) {

						var _idAxes = {
							val: [],
							label: "Axis",
							htmlElement: []
						};

						var _enabled = {
							val: [],
							label: "Enabled",
							htmlElement: []
						};

						var _condition = {
							val: [],
							label: "Condition",
							htmlElement: []
						};

						var _inOut = {
							val: [],
							label: "Workspace",
							htmlElement: []
						};

						var _limitLow = {
							val: [],
							label: "Low Limit [°]",

							htmlElement: []
						};

						var _limitHigh = {
							val: [],
							label: "High Limit [°]",
							htmlElement: []
						};

						function privateInitHtml(){
							for (var i = 0; i < 10; i++) {

								_idAxes.htmlElement.push( $('<input type="text" readonly/>')
										.addClass('jointAxes')
										.css("width", "90%") );

								_enabled.htmlElement.push($('<input type="checkbox" />').addClass('JointCheckClass'));

								_condition.htmlElement.push( $('<input type="checkbox" />').addClass('joint_condition'));

								_inOut.htmlElement.push( $('<select />')
												.append( '<option value="false">Inside</option>' )
												.append( '<option value="true">Outside</option>' )
												.css("width", "90%") );

								_limitLow.htmlElement.push( $('<input type="text"/>') 
										.css("width", "50%")
										.css("float", "left") );

								_limitHigh.htmlElement.push( $('<input type="text"/>') 
										.css("width", "50%")
										.css("float", "left") );
							}
						};

						function privateToObjectJSON() {

							return {
								idAxes: _idAxes.val,
								enabled: _enabled.val,
								condition: _condition.val,
								inOut: _inOut.val,
								limitLow: _limitLow.val,
								limitHigh: _limitHigh.val
							};
						};

						function privateSliceArray(array,n) {
							return array.slice(0,n);
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "idAxes"       ) {
											_idAxes.val       = objectJSON[property];
											_idAxes.htmlElement=privateSliceArray(_idAxes.htmlElement, _idAxes.val.length);
										}
										else if ( property === "enabled"    ) {
											_enabled.val    = objectJSON[property];
											_enabled.htmlElement=privateSliceArray(_enabled.htmlElement, _enabled.val.length);
										}
										else if ( property === "condition"  ) { 
											_condition.val  = objectJSON[property];
											_condition.htmlElement=privateSliceArray(_condition.htmlElement, _condition.val.length);
										}
										else if ( property === "inOut"      ) { 
											_inOut.val      = objectJSON[property];
											_inOut.htmlElement=privateSliceArray(_inOut.htmlElement, _inOut.val.length);
										}
										else if ( property === "limitLow"   ) { 
											_limitLow.val   = objectJSON[property]; 
											_limitLow.htmlElement=privateSliceArray(_limitLow.htmlElement, _limitLow.val.length);
										}
										else if ( property === "limitHigh"  ) { 
											_limitHigh.val  = objectJSON[property]; 
											_limitHigh.htmlElement=privateSliceArray(_limitHigh.htmlElement, _limitHigh.val.length);
										}

									}
								}
							}
						};
					
						privateInitHtml(); //Initialize htmlElements as array of 10.

						return {
							
							axes:  {
							label: "axes",
								valuesArray: [
								_idAxes,
								_enabled,
								_condition,
								_inOut,
								_limitLow,
								_limitHigh ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					},
					
					//TSK1456 joint speed limitation handling
					ValueJointSpeed: function(initialValue) {

						var _idAxes = {
							val: [],
							label: "Axis",
							htmlElement: []
						};

						var _enabled = {
							val: [],
							label: "Enabled",
							htmlElement: []
						};

						var _speedLimit = {
							val: [],
							label: $(_robot.IsCobot() ? "<span>Speed Limit [tenth of &deg;/s]</span>" : "<span>Speed Limit [&deg;/s]</span>"),
							htmlElement: []
						};

						function privateInitHtml(){
							for (var i = 0; i < 10; i++) {

								_idAxes.htmlElement.push( $('<input type="text" readonly/>')
										.addClass('jointAxes')
										.css("width", "90%") );

								_enabled.htmlElement.push($('<input type="checkbox" />')
										.addClass('JointSpeedClass') );

								_speedLimit.htmlElement.push( $('<input type="text"/>') 
										.css("width", "50%")
										.css("float", "left") );

							}
						};

						function privateToObjectJSON() {

							return {
								idAxes: _idAxes.val,
								enabled: _enabled.val,
								speedLimit: _speedLimit.val
							};
						};

						function privateSliceArray(array,n) {
							return array.slice(0,n);
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "idAxes"       ) {
											_idAxes.val       = objectJSON[property];
											_idAxes.htmlElement=privateSliceArray(_idAxes.htmlElement, _idAxes.val.length);
										}
										else if ( property === "enabled"    ) {
											_enabled.val    = objectJSON[property];
											_enabled.htmlElement=privateSliceArray(_enabled.htmlElement, _enabled.val.length);
										}
										else if ( property === "speedLimit"  ) { 
											_speedLimit.val  = objectJSON[property]; 
											_speedLimit.htmlElement=privateSliceArray(_speedLimit.htmlElement, _speedLimit.val.length);
										}

									}
								}
							}
						};
					
						privateInitHtml(); //Initialize htmlElements as array of 10.

						return {
							
							axes:  {
							label: "axes",
								valuesArray: [
								_idAxes,
								_enabled,
								_speedLimit ]
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					},

					ValueSector: function(axesIndex) {

						var _delimiter = {
							val: [],
							label: "Axes",
							htmlElement: $('<div class="slider"/>').slider(
								{
									min: 0,
									max: 0,
									step: 1,
									values: []
								}) 
						};
						
						var _delimMin = {
							val: _robot.StrokeEndLowValues(axesIndex),
							label: "",
							htmlElement : ""
						};
						
						var _delimMax = {
							val: _robot.StrokeEndHighValues(axesIndex),
							label: "",
							htmlElement : ""
						};

						function privateToObjectJSON() {
							return {
								delimiter: _delimiter.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "delimiter"       ) {
											_delimiter.val       = objectJSON[property];
										}
									}
								}
							}
						};

						return {
							
							axes:  {

								valuesArray: [
									_delimiter
								],
							minValue: _delimMin.val,
							maxValue: _delimMax.val,
							unit: _robot.IsAxisRot(axesIndex) ? '&deg;' : 'mm'
							},

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};

					},

					ValueAxesArray: function(initialValue) {
						var _axes = {
							val: ValueJoints.elementsArray,
							label:""
						};
						
						function privateToObjectJSON() {

							return {
								axes: ValueJoints.ToObjectJSON
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON) {

									if ( objectJSON.hasOwnProperty(property) ) {

										if      ( property === "axes"    ) { _axes.val = ValueJoints.FromObjectJSON(); }
									}
								}
							}
						};

						return {
							
							elementsArray: [
								_axes
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON
						};
					} 
				}, 

				flagsObjectBuildres: {

					FlagsEmpty: function(title) {

						function privateToObjectJSON() {

							;
						};

						function privateSetEnabled(isEnabled) {

							;
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: function() { ; },
							SetEnabled: privateSetEnabled
						};
					},

					FlagsEnableOnly: function(title) {

						var _enabled = {
							val: false,
							label: "Enabled",
							htmlElement: $('<input type="checkbox" />')
						};

						function privateSetEnabled(isEnabled) {

							_enabled.val = isEnabled;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					FlagsEnableAndActiveOnly: function(title) {

						var _enabled = {
							val: true,
							label: "Enabled",
							htmlElement: $('<input type="checkbox" />')
						};

						var _alwaysActive = {
							val: false,
							label: "Activated by",
							htmlElement: $('<select />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always active</option>' )
						};

						function privateSetEnabled(isEnabled) {

							_enabled.val = isEnabled;
						};

						function privateSetAlwaysActive(isAlwayActive) {

							_alwaysActive.val = isAlwayActive;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								alwaysActive: _alwaysActive.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									else if ( property === "alwaysActive" ) { _alwaysActive.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_alwaysActive
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							SetAlwaysActive: privateSetAlwaysActive
						};
					},

					FlagsCompact: function(title, initialValue) {

						var _enabled = {
							val: true,
							label: "Enabled",
							htmlElement: $('<input type="checkbox" />')
											.change( function () {

												var disabled = $(_enabled.htmlElement).prop('checked') === false;
												
												$(_stopInAutoMode.htmlElement).attr('disabled', disabled);
												$(_stopInProgMode.htmlElement).attr('disabled', disabled);
											})
						};

//						var _obdOn = {
//							val: false,
//							label: "OBD",
//							htmlElement: $('<select id="cellObdId" />')
//											.append( '<option value="false">Off</option>' )
//											.append( '<option value="true">On</option>' )
//											.css("width", "90%")
//						};

						var _stopInAutoMode = {
							val: "0",
							label: "Stop in AUTO",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="1">Stop Cat. 1</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						var _stopInProgMode = {
							val: "0",
							label: "Stop in PROGR",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						function privateSetEnabled(isEnabled) {
							$(_stopInAutoMode.htmlElement).prop('disabled', !isEnabled);
							$(_stopInProgMode.htmlElement).prop('disabled', !isEnabled);
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								//obdOn: _obdOn.val,
								stopInAutoMode: _stopInAutoMode.val,
								stopInProgMode: _stopInProgMode.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									//Per ora nascosto, potrebbe tornare utile in futuro... else if ( property === "obdOn" ) { _obdOn.val = objectJSON[property]; }
									else if ( property === "stopInAutoMode" ) { _stopInAutoMode.val = objectJSON[property]; }
									else if ( property === "stopInProgMode" ) { _stopInProgMode.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								//_obdOn,
								_stopInAutoMode,
								_stopInProgMode
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					FlagsDynamicVolumes: function(title, initialValue) {

//						var _obdOn = {
//							val: false,
//							label: "OBD",
//							htmlElement: $('<select />')
//											.append( '<option value="false">Off</option>' )
//											.append( '<option value="true">On</option>' )
//											.css("width", "90%")
//						};

						var _stopInAutoMode = {
							val: "0",
							label: "Stop in AUTO",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="1">Stop Cat. 1</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						var _stopInProgMode = {
							val: "0",
							label: "Stop in PROGR",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						function privateSetEnabled(isEnabled) {
							$(_stopInAutoMode.htmlElement).prop('disabled', !isEnabled);
							$(_stopInProgMode.htmlElement).prop('disabled', !isEnabled);
						};

						function privateToObjectJSON() {

							return {
								//obdOn: _obdOn.val,
								stopInAutoMode: _stopInAutoMode.val,
								stopInProgMode: _stopInProgMode.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {
									
									//Per ora nascosto, potrebbe tornare utile in futuro... if ( property === "obdOn" ) { _obdOn.val = objectJSON[property]; }
									if ( property === "stopInAutoMode" ) { _stopInAutoMode.val = objectJSON[property]; }
									else if ( property === "stopInProgMode" ) { _stopInProgMode.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								//_obdOn,
								_stopInAutoMode,
								_stopInProgMode
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					HighSpeedFlags: function(title, initialValue){

						var _use75_25 = true;

						var _enabled = {
							val: false,
							label: "Enable cartesian speed control (higher than Low Speed)",
							htmlElement: $('<input type="checkbox" />')
											.change( function () {
												
												if (_robot.IsAura()) {
													var disabled =  $(_enabled.htmlElement).prop('checked') === false;
													$(_cartControl.htmlElement).attr('disabled', true); //disabled anyway if aura
													$(_enableStopProcedure.htmlElement).attr('disabled', true); //disabled anyway if aura
													$(_speedLimit.htmlElement).attr('disabled', disabled);
												}
												else if (_robot.IsCobot()) {
													$(_enabled.htmlElement).prop('checked', true);
													
													$(_cartControl.htmlElement).attr('disabled', true);
													$(_enableStopProcedure.htmlElement).attr('disabled', false);
													$(_speedLimit.htmlElement).attr('disabled', false);
												}
												else {
													var disabled =  $(_enabled.htmlElement).prop('checked') === false;
													$(_cartControl.htmlElement).attr('disabled', disabled); //disabled anyway if aura
													$(_enableStopProcedure.htmlElement).attr('disabled', disabled); //disabled anyway if aura
													$(_speedLimit.htmlElement).attr('disabled', disabled);
												}

			
											})
											.prop('disabled', _robot.IsCobot()||_robot.IsAura())
						};

						var _cartControl = {
							val: "0",
							label: "Activated by",
							htmlElement: $('<select id="cartControl" />')
											.append('<option value="0">RS input</option>' )
											.append('<option value="1">Always active</option>' )
											.append(_robot.IsKeyenAndSafeAxes() ? '<option value="2">Func. Space A</option>' : '' )
											.append(_robot.IsKeyenAndSafeAxes() ? '<option value="3">RS Input &amp; FS A</option>' : '' )
											.append(_robot.IsAura() ? '<option value="4">Aura input</option>' : '')
											.append(_robot.IsAura() ? '<option value="5">A.in &amp; FS A</option>' : '')
											.css("width", "90%")
											.prop('disabled', _robot.IsAura())
						};

						var _enableStopProcedure = {
								val: "0",
								label: "Stop procedure when cartesian speed limits are violated",
								htmlElement: $('<select />')
									.append( '<option value="0">Don\'t stop</option>' )
									.append( '<option value="1">Stop Cat. 1</option>' )
									.append( '<option value="2">Stop Cat. 0</option>' )
									.css("width", "90%")
									.prop('disabled', _robot.IsAura())
						};

						var _speedLimit = {
							val: false,
							label: "Speed limit [mm/s]",
							htmlElement: $('<input type="text" />')
								.css("width", "90%")
								.focusout(function(e) {

									var v = $(this).val();

									if (!_validator.ValidateHighSpeed(v))
									{
										var lowSpeedStr = '';
										var lsManager = _managers.speedManager.ToObjectJSON().LowSpeed;
										if(lsManager[0] != undefined){
											if (lsManager[0].flags.enabled == true)
												lowSpeedStr = lsManager[0].flags.speedLimit;
											else 
												lowSpeedStr = 2;
										}
										$(this).preventFocus();
										_utility.MessageBox("Info", v + ' is not a valid value for HighSpeed, it should be <= ' + _robot.GetMaxHighSpeed() + ' and >= LowSpeed (' + lowSpeedStr + ')', true).Show();
										$(this).val(_robot.GetMaxHighSpeed());
									}
								})
						};
						
						
						var _helpBodySpeed = {
							val: [],
							label: "",
							htmlElement: $(_robot.IsCobot() ? 
							             '<div style="margin-left:-240px;width:350px"> BodySpeed information collisions type ' +
							             '<input type="text" value="Transient" style="width:25%;margin-left:19px;background-color:inherit;color: #666;border:0px none;" alt="Not editable parameter" title="Not editable parameter" readonly />' +
							             '</div>' : '')

						};


						function privateSetEnabled(isEnabled) {
							$(_enabled.htmlElement).prop('disabled', !isEnabled);
							$(_cartControl.htmlElement).prop('disabled', !isEnabled);
							$(_enableStopProcedure.htmlElement).prop('disabled', !isEnabled);
							$(_speedLimit.htmlElement).prop('disabled', !isEnabled);
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								cartControl: _cartControl.val,
								enableStopProcedure: _enableStopProcedure.val,
								speedLimit: _speedLimit.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									else if ( property === "cartControl" ) { _cartControl.val = objectJSON[property]; }
									else if ( property === "enableStopProcedure" ) { _enableStopProcedure.val = objectJSON[property]; }
									else if ( property === "speedLimit" ) {
										var v = objectJSON[property];

										// check if the speed is correct
										if (!_validator.ValidateHighSpeed(v))
										{
											v = _robot.GetMaxHighSpeed();
										}
										_speedLimit.val = v;
									}
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_cartControl,
								_enableStopProcedure,
								_speedLimit,
								_helpBodySpeed
						
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: _use75_25
						};
					},

					LowSpeedFlags: function(title, initialValue){

						var _use75_25 = true;

						var _enabled = {
							val: false,
							label: "Enable cartesian speed control (lower than High Speed)",
							htmlElement: $('<input type="checkbox" />')
											.change( function () {

												if (_robot.IsURDI()){
													$(_enabled.htmlElement).prop('checked', true);
													
												  $(_cartControl.htmlElement).attr('disabled', true);
												  $(_enableStopProcedure.htmlElement).attr('disabled', true);
												  $(_speedLimit.htmlElement).attr('disabled', false);
												} else {
												  
													
												  var disabled = $(_enabled.htmlElement).prop('checked') === false;
												  
												  
												  $(_cartControl.htmlElement).attr('disabled', disabled);
												  $(_enableStopProcedure.htmlElement).attr('disabled', disabled);
												  $(_speedLimit.htmlElement).attr('disabled', disabled);
                        }
											})
											
							.click( function () {
							  
									if (_robot.IsCobot()){
							      if ($(_enabled.htmlElement).prop('checked') === true) {
							          										    										    
									    _utility.MessageBox("Info", "Remember to SET 'Joint Speed Limiting' value", true).Show();
                    }
                  }
							})
						};

						var _cartControl = {
							val: "0",
							label: "Activated by",
							htmlElement: $('<select id="cartControl" />')
											.append('<option value="0">RS input</option>' )
											.append('<option value="1">Always active</option>' )
											.append(_robot.IsKeyenAndSafeAxes() ? '<option value="2">Func. Space B</option>' : '' )
											.append(_robot.IsKeyenAndSafeAxes() ? '<option value="3">RS Input &amp; FS B</option>' : '')
											.append(_robot.IsAura() ? '<option value="4">Aura input</option>' : '')
											.append(_robot.IsAura() ? '<option value="5">A.in &amp; FS B</option>' : '')
											.css("width", "90%")
						};

						var _enableStopProcedure = {
								val: "0",
								label: "Stop procedure when cartesian speed limits are violated",
								htmlElement: $('<select />')
									.append( '<option value="0">Don\'t stop</option>' )
									.append( '<option value="1">Stop Cat. 1</option>' )
									.append( '<option value="2">Stop Cat. 0</option>' )
									.css("width", "90%")
						};

						var _speedLimit = {
							val: 0,
							label: "Speed limit [mm/s]",
							htmlElement: $('<input type="text" />')
								.css("width", "90%")
								.focusout(function(e) {

									var v = $(this).val();

									if (!_validator.ValidateLowSpeed(v))
									{
										var highSpeedStr = '';
										var hsManager= _managers.speedManager.ToObjectJSON().HighSpeed;
										if(hsManager[0] != undefined){
											
											if (hsManager[0].flags.enabled == false)
												highSpeedStr = _robot.GetMaxHighSpeed();
											else
												highSpeedStr = hsManager[0].flags.speedLimit;
										}
										
					          //TSK5554
			              if (_robot.IsURDI()){
                       highSpeedStr = 250;
                       
										   $(this).preventFocus();
										   _utility.MessageBox("Info", v + ' is not a valid value for LowSpeed, it should be >= 2 and <= '+ highSpeedStr, true).Show();
										   $(this).val(highSpeedStr);
                       
                    } else {
                      
										  $(this).preventFocus();
										  _utility.MessageBox("Info", v + ' is not a valid value for LowSpeed, it should be >= 2 and <= HighSpeed ('+ highSpeedStr + ')', true).Show();
										  $(this).val(2);
                    }
									}
								})
						};
						
						
						var _helpBodySpeed = {
							val: [],
							label: "",
							htmlElement: $(_robot.IsCobot() ? 
							             '<div style="margin-left:-240px;width:350px"> BodySpeed information collisions type ' +
							             '<input type="text" value="Constrained" style="width:25%;margin-left:19px;background-color:inherit;color: #666;border:0px none;" alt="Not editable parameter" title="Not editable parameter" readonly />' +
							             '</div>' : '')

						};


						function privateSetEnabled(isEnabled) {
							$(_enabled.htmlElement).prop('disabled', !isEnabled);
							$(_cartControl.htmlElement).prop('disabled', !isEnabled);
							$(_enableStopProcedure.htmlElement).prop('disabled', !isEnabled);
							$(_speedLimit.htmlElement).prop('disabled', !isEnabled);
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								cartControl: _cartControl.val,
								enableStopProcedure: _enableStopProcedure.val,
								speedLimit: _speedLimit.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									else if ( property === "cartControl" ) { _cartControl.val = objectJSON[property]; }
									else if ( property === "enableStopProcedure" ) { _enableStopProcedure.val = objectJSON[property]; }
									else if ( property === "speedLimit" ) {
										var v = objectJSON[property];

										// check if the speed is correct
										if (!_validator.ValidateLowSpeed(v))
										{
											v=2;
										}
										_speedLimit.val = v;
									}
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_cartControl,
								_enableStopProcedure,
								_speedLimit,
								_helpBodySpeed
						
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: _use75_25
						};
					},

					ProgrSpeedFlags: function(title, initialValue){

						var _use75_25 = true;

						var _enabled = {
							val: false,
							label: "Enable Reduced cartesian Speed control in Manual motion",
							htmlElement: $('<input type="checkbox" />')
												.change( function () {
													var disabled = $(_enabled.htmlElement).prop('checked') === false;
													$(_stopCategory.htmlElement).attr('disabled', disabled );
												})
						};
												
						var _stopCategory = {
								val: "2",
								label: "Stop category",
								htmlElement: $('<select />')
												.append( '<option value="1">Category 1</option>' )
												.append( '<option value="2">Category 0</option>' )
												.css("width", "90%")
						};
						
						var _speedLimit = {
								val: 250,
								label: "Speed limit [mm/s]",
								htmlElement: $('<input type="text" alt="Not editable parameter" title="Not editable parameter" readonly/>')
								.css("width", "90%").css("border","0px none").css("background-color","inherit").css('color','#666')
						};

						function privateSetEnabled(isEnabled) {
							$(_enabled.htmlElement).prop('disabled', !isEnabled);
							$(_stopCategory.htmlElement).prop('disabled', !isEnabled);
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								stopCategory: _stopCategory.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									else if ( property === "stopCategory" ) { _stopCategory.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_stopCategory,
								_speedLimit
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: _use75_25
						};
					},
					
					SpeedModulationFlags : function(title, initialValue) {
							var _enabled = {
								val: false,
								label: "Enabled",
								htmlElement: $('<input type="checkbox" />')
							};
													
							
							function privateSetEnabled(isEnabled) {
								$(_enabled.htmlElement).prop('disabled', !isEnabled);
							};

							function privateToObjectJSON() {
								return {
									enabled: _enabled.val
								};
							};

							function privateFromObjectJSON(objectJSON) {

								if ( objectJSON != undefined ) {

									for ( var property in objectJSON ) {

										if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									}
								}
							};

							return {

								uId: title.replace(/\s+/g, ''),
								flagsLabel: title,
								elementsArray: [
									_enabled
								],

								ToObjectJSON: function() { return privateToObjectJSON(); },
								FromObjectJSON: privateFromObjectJSON,
								SetEnabled: privateSetEnabled,
								Use75_25: false
							};
					},

					FlagsExtended: function(title, initialValue) {

						var _enabled = {
							val: true,
							label: "Enabled",
							htmlElement: $('<input type="checkbox" />')
											.change( function () {

												var disabled = $(_enabled.htmlElement).prop('checked') === false;

												$(_checkMode.htmlElement).attr('disabled', disabled);

												$(_workType.htmlElement).attr('disabled', disabled);
												$(_alwaysActive.htmlElement).attr('disabled', disabled);

												$(".dynamicValueAreaClass").prop('disabled', disabled);
											})
						};

						var _workType = {
							val: false,
							label: "Area type",
							htmlElement: $('<select />')
											.append( '<option value="false">Forbidden</option>' )
											.append( '<option value="true">Work</option>' )
											.css("width", "90%")
						};
						

						var _checkMode = {
							val: true,
							label: "Mode",
							htmlElement: $('<label />')
											.append( 'Check' )
											.css("width", "90%")
						};

						var _alwaysActive = {
							val: false,
							label: "Activated by",
							htmlElement: $('<select />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always active</option>' )
											.css("width", "90%")
						};


						function privateSetEnabled(isEnabled) {

							_enabled.val = isEnabled;
						};

						function privateSetAlwaysActive(isAlwayActive) {

							_alwaysActive.val = isAlwayActive;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								workType: _workType.val,
								checkMode: _checkMode.val,
								alwaysActive: _alwaysActive.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
									else if ( property === "workType" ) { _workType.val = objectJSON[property]; }
									else if ( property === "checkMode" ) { _checkMode.val = true; } //in c5g+ is always true 
									else if ( property === "alwaysActive" ) { _alwaysActive.val = objectJSON[property]; }
								}
							}
						};


						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,								
//								_checkMode,
								_workType,
								_alwaysActive
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							SetAlwaysActive: privateSetAlwaysActive
						};
					},
					
					//gestione tool orientation flags
					ToolOrientationFlags: function(title, initialValue){

						var _enabled = {
							val: false,
							label: "Enable",
							htmlElement: $('<input type="checkbox" />')
							.change( function () {

												var disabled = $(_enabled.htmlElement).prop('checked') === false;
												
												$(_activatedBy.htmlElement).attr('disabled', disabled);
												$(_stopInAutoMode.htmlElement).attr('disabled', disabled);
												$(_stopInProgMode.htmlElement).attr('disabled', disabled);
											})
						};

						var _activatedBy = {
							val: false,
							label: "Activated by",
							htmlElement: $('<select id="tcpControl" />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always active</option>' )
											.css("width", "90%")
						};

						var _stopInAutoMode = {
							val: "0",
							label: "Stop in AUTO",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="1">Stop Cat. 1</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						var _stopInProgMode = {
							val: "0",
							label: "Stop in PROGR",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						function privateSetEnabled(isEnabled) {
							_enabled.val = isEnabled;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								activatedBy: _activatedBy.val,
								stopInAutoMode: _stopInAutoMode.val,
								stopInProgMode: _stopInProgMode.val

							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if		( property === "enabled" )				{ _enabled.val = objectJSON[property]; }
									else if ( property === "activatedBy" )			{ _activatedBy.val = objectJSON[property]; }
									else if ( property === "stopInAutoMode" )		{ _stopInAutoMode.val = objectJSON[property]; }
									else if ( property === "stopInProgMode" )		{ _stopInProgMode.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_activatedBy,
								_stopInAutoMode,
								_stopInProgMode
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: false
						};
					},
					
					JointFlags: function(title, initialValue){

						var _enabled = {
							val: false,
							label: "Enable Joint Space control",
							htmlElement: $('<input type="checkbox" />')
							.change( function () {

												var disabled = $(_enabled.htmlElement).prop('checked') === false;
												
												$(_activatedBy.htmlElement).attr('disabled', disabled);
												$(_stopInAutoMode.htmlElement).attr('disabled', disabled);
												$(_stopInProgMode.htmlElement).attr('disabled', disabled);
												
												var enableCheckBoxes = $(".JointCheckClass");
												enableCheckBoxes.trigger("jointDisable", disabled);
												
											})
						};

						var _activatedBy = {
							val: false,
							label: "Activated by",
							htmlElement: $('<select id="tcpControl" />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always active</option>' )
											.css("width", "90%")
						};

						var _stopInAutoMode = {
							val: "0",
							label: "Stop in AUTO",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="1">Stop Cat. 1</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						var _stopInProgMode = {
							val: "0",
							label: "Stop in PROGR",
							htmlElement: $('<select />')
											.append( '<option value="0">Don\'t stop</option>' )
											.append( '<option value="2">Stop Cat. 0</option>' )
											.css("width", "90%")
						};

						function privateSetEnabled(isEnabled) {
							_enabled.val = isEnabled;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								activatedBy: _activatedBy.val,
								stopInAutoMode: _stopInAutoMode.val,
								stopInProgMode: _stopInProgMode.val

							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if		( property === "enabled" )				{ _enabled.val = objectJSON[property]; }
									else if ( property === "activatedBy" )			{ _activatedBy.val = objectJSON[property]; }
									else if ( property === "stopInAutoMode" )		{ _stopInAutoMode.val = objectJSON[property]; }
									else if ( property === "stopInProgMode" )		{ _stopInProgMode.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_activatedBy,
								_stopInAutoMode,
								_stopInProgMode
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: true
						};
					},
					
					JointSpeedFlags: function(title, initialValue){

						var _enabled = {
							val: false,
							label: "Enable Joint speed control",
							htmlElement: $('<input type="checkbox" />')
							.change( function () {
							  
										    var lowSpeedEnabled = false;
										    var lsManager = _managers.speedManager.ToObjectJSON().LowSpeed;
										    if(lsManager[0] != undefined){
										    		lowSpeedEnabled = lsManager[0].flags.enabled;
										    }
								
												if (_robot.IsCobot()){
												  
												    $(_activatedBy.htmlElement).attr('disabled', true);
												    $(_enableStopProcedure.htmlElement).attr('disabled', true);
												    
												    _enableStopProcedure.val = 1; //Stop Cat. 1
												    
												    if(lowSpeedEnabled == false){
												    
												    	$(_enabled.htmlElement).prop('checked', false);
												    } else {
                              
												    	$(_enabled.htmlElement).prop('checked', true);
                            }
                            
												    $(_enabled.htmlElement).attr('disabled', lowSpeedEnabled == false);
												    
												    var disabled = $(_enabled.htmlElement).prop('checked') === false;
												    
												    var enableCheckBoxes = $(".JointSpeedClass");
												    
												    if (!disabled) {
                              enableCheckBoxes.prop('checked', true);
                              enableCheckBoxes.click(function(){return false;})
                              
                            }
                                                        
												    enableCheckBoxes.trigger("jointSpeedDisable", disabled);
												    
											  } else {
                          
												    var disabled = $(_enabled.htmlElement).prop('checked') === false;

												    $(_activatedBy.htmlElement).attr('disabled', disabled);
												    $(_enableStopProcedure.htmlElement).attr('disabled', disabled);
												    
												    var enableCheckBoxes = $(".JointSpeedClass");
												    enableCheckBoxes.trigger("jointSpeedDisable", disabled);

                        }
											})
							
						};

						var _activatedBy = {
							val: false,
							label: "Activated by",
							htmlElement: $('<select id="tcpControl" />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always active</option>' )
											.css("width", "90%")
						};

						var _enableStopProcedure = {
							val: "0",
							label: "Stop procedure when joint speed limits are violated",
							htmlElement: $('<select />')
								.append( '<option value="0">Don\'t stop</option>' )
								.append( '<option value="1">Stop Cat. 1</option>' )
								.append( '<option value="2">Stop Cat. 0</option>' )
								.css("width", "90%")
						};
						
						var _helpBodySpeed = {
							val: [],
							label: "",
							htmlElement: $(_robot.IsCobot() ? 
							             '<div style="margin-left:-256px;width:350px"> Cobot joint speed limits are Activated by ' +
							             '<input type="text" value="Low Speed" style="width:25%;margin-left:19px;background-color:inherit;color: #666;border:0px none;" alt="Not editable parameter" title="Not editable parameter" readonly />' +
							             '</div>' : '')

						};

						function privateSetEnabled(isEnabled) {
							_enabled.val = isEnabled;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val,
								activatedBy: _activatedBy.val,
								enableStopProcedure: _enableStopProcedure.val

							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if		( property === "enabled" )				{ _enabled.val = objectJSON[property]; }
									else if ( property === "activatedBy" )			{ _activatedBy.val = objectJSON[property]; }
									else if ( property === "enableStopProcedure" )	{ _enableStopProcedure.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_activatedBy,
								_enableStopProcedure,
								_helpBodySpeed
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled,
							Use75_25: true
						};
					},

					LayoutProperties: function(title, initialValue) {

						var initialValue;
						
						var _zmin = {
							val: 0,
							label: "<font color='blue'> Z-min [mm]",
							htmlElement: $('<input id="zminId" type="text" />').css("width", "90%")
							.focusin( function(sender) {
								initialValue = $(this).val();			
							})
							.focusout( function(sender) {
								validateField(this);
							})
						};

						var _zmax = {
							val: 3000,
							label: "<font color='blue'> Z-max [mm]",
							htmlElement: $('<input type="text" />').css("width", "90%")
							.focusin( function(sender) {
								initialValue = $(this).val();			
							})
							.focusout( function(sender) {
								validateField(this);
							})
						};
						
						function validateField(field) {
							var txtValue = $(field).val();
							var isValid = !isNaN(txtValue);
							if(!isValid){
								_utility.MessageBox("Info", "Only numeric values are allowed for this field", true).Show();
								$(field).val(initialValue);
								$(field).preventFocus();
							}
						};
					
						function privateToObjectJSON() {

							return {
								zmin: _zmin.val,
								zmax: _zmax.val
							};
						};

						function privateSetValues(newZMin, newZMax) {

							_zmin.val = newZMin;
							$(_zmin.htmlElement).val( newZMin.toString() );

							_zmax.val = newZMax;
							$(_zmax.htmlElement).val( newZMax.toString() );
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "zmin" ) { _zmin.val = objectJSON[property]; }
									else if ( property === "zmax" ) { _zmax.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_zmin,
								_zmax
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,

							setValues: privateSetValues
						};
					},

					FlagsBrake: function(title) {

						var _enabled = {
							val: false,
							label: "Enabled",
							htmlElement: $('<input type="checkbox" />')
						};

						var _reminder = {
							val: 144,
							label: "Reminder [h]",
							htmlElement: $('<input type="text"  alt="Not editable parameter" title="Not editable parameter" readonly/>')
							.css("width", "90%").css("border","0px none").css("background-color","inherit").css('color','#666')
						};

						var _alarm = {
							val: 168,
							label: "Alarm [h]",
							htmlElement: $('<input type="text"  alt="Not editable parameter" title="Not editable parameter" readonly/>')
							.css("width", "90%").css("border","0px none").css("background-color","inherit").css('color','#666')
						};

						function privateSetEnabled(isEnabled) {

							_enabled.val = isEnabled;
						};

						function privateToObjectJSON() {

							return {
								enabled: _enabled.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "enabled" ) { _enabled.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_enabled,
								_reminder,
								_alarm
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					FlagsSafeOutput: function(title) {

						var _block1 = {
							val: false,
							label: "Block 1",
							htmlElement: $('<select />').css("width", "95%")
											.append( '<option value="false">Ax. 1 sector</option>' )
											.append( '<option value="true">Func. space A</option>' )
						};

						var _block2 = {
							val: true,
							label: "Block 2",
							htmlElement: $('<select />').css("width", "95%")
											.append( _robot.HasRailSafe() ? '<option value="false">Ax. 7 sector</option>' : '' )
											.append( '<option value="true">Func. space B</option>' )
						};

						var _block3 = {
								val: true,
								label: "Block 3",
								htmlElement: $('<select />').css("width", "95%")
												.append( '<option value="true">Motion active</option>' )
												.append( '<option value="false">CRC check</option>' )
							};
						
						function privateSetEnabled(isEnabled) {
							var isKeyenSafe = _robot.IsKeyenAndSafeAxes();
							$(_block1.htmlElement).prop('disabled', !isKeyenSafe || !isEnabled);
							$(_block2.htmlElement).prop('disabled', !isKeyenSafe || !isEnabled || _robot.IsApc2100());
							$(_block3.htmlElement).prop('disabled', !isEnabled || _robot.IsApc2100()); //il block 3 non deve tenere conto della presenza del keyen.
							
						};

						function privateToObjectJSON() {

							return {
								block1: _block1.val,
								block2: _block2.val,
								block3: _block3.val,
								
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if		( property === "block1" ) 	{ _block1.val = objectJSON[property]; }
									else if ( property === "block2" ) 	{ _block2.val = objectJSON[property]; }
									else if ( property === "block3" ) 	{ _block3.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_block1,
								_block2,
								_block3
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					SystemFlags: function(title) {

						var _emergencyStopTime = {
							val: "1400",
							label: "Stop time [s]",
							htmlElement: $('<select />').css("width", "90%")
											.append( '<option value="60">Cat. 0</option>' ) //TSK2062 gestione cat 0
											.append( '<option value="400">Cat. 1 - 0,5</option>' )
											.append( '<option value="900">Cat. 1 - 1,0</option>' )
											.append( '<option value="1400">Cat. 1 - 1,5</option>' )
											.append( '<option value="1900">Cat. 1 - 2,0</option>' )
											.append( '<option value="2400">Cat. 1 - 2,5</option>' )
											.append( '<option value="2900">Cat. 1 - 3,0</option>' )
											.append( '<option value="3900">Cat. 1 - 4,0</option>' )
											.append( '<option value="4900">Cat. 1 - 5,0</option>' )
											.append( '<option value="5900">Cat. 1 - 6,0</option>' )
						};
						
						var psfInitialValue;
						var _psFaddress = {
							val: "198",
							label: "PS F-Address",
							htmlElement: $('<input type="text"  />').css("width", "90%")
											.focusin ( function () {
												psfInitialValue = $(this).val();
											})
											.focusout ( function () {
												var txtValue = $(this).val();
												var isValid = _validator.ValidatePSFAddress(txtValue);
												if(!isValid){
													_utility.MessageBox("Info", "Invalid value for ProfiSafe F-Address", true).Show();
													$(this).val(psfInitialValue);
													$(this).preventFocus();
												}
											})
						};
						
						var _psStopDisable = {
								val: "false",
								label: "Disable PS Stop",
								htmlElement: $('<input type="checkbox" />')
												
							};

						function privateSetEnabled(isEnabled) {
							//just PS option can be disabled
							$(_psFaddress.htmlElement).prop( "disabled", !isEnabled )
							$(_psStopDisable.htmlElement).prop( "disabled", !isEnabled )
						};

						function privateToObjectJSON() {

							return {
								emergencyStopTime: _emergencyStopTime.val,
								psFaddress: _psFaddress.val,
								psStopDisable: _psStopDisable.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if ( property === "emergencyStopTime" ) { _emergencyStopTime.val = objectJSON[property]; }
									else if ( property === "psFaddress" )	{ _psFaddress.val = objectJSON[property]; }
									else if ( property === "psStopDisable" )	{ _psStopDisable.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_emergencyStopTime,
								_psFaddress,
								_psStopDisable
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					},

					StatusFlags: function(title) {
						var _signal1 = {
							val: false,
							label: "Signal 1",
							htmlElement: $('<select />').css("width", "90%")
											.append( '<option value="0">Progr</option>' )
											.append( '<option value="1">Auto</option>' )
											.append( '<option value="2">En Device</option>' )
											.append( '<option value="3">EmExt Stop</option>' )
											.append( '<option value="4">Drive ON</option>' )
											.append( '<option value="5">Safety gates</option>' )
											.append( _robot.IsProfiSafe() ? '<option value="6">SBO 1</option>' : '')
											.append( _robot.IsProfiSafe() ? '<option value="7">SBO 2</option>' : '')
						};

						var _signal2 = {
							val: false,
							label: "Signal 2",
							htmlElement: $('<select />').css("width", "90%")
											.append( '<option value="0">Progr</option>' )
											.append( '<option value="1">Auto</option>' )
											.append( '<option value="2">En Device</option>' )
											.append( '<option value="3">EmExt Stop</option>' )
											.append( '<option value="4">Drive ON</option>' )
											.append( '<option value="5">Safety gates</option>' )
											.append( _robot.IsProfiSafe() ? '<option value="6">SBO 1</option>' : '')
											.append( _robot.IsProfiSafe() ? '<option value="7">SBO 2</option>' : '')
						};

						var _signal3 = {
							val: false,
							label: "Signal 3",
							htmlElement: $('<select />').css("width", "90%")
											.append( '<option value="0">Progr</option>' )
											.append( '<option value="1">Auto</option>' )
											.append( '<option value="2">En Device</option>' )
											.append( '<option value="3">EmExt Stop</option>' )
											.append( '<option value="4">Drive ON</option>' )
											.append( '<option value="5">Safety gates</option>' )
											.append( _robot.IsProfiSafe() ? '<option value="6">SBO 1</option>' : '')
											.append( _robot.IsProfiSafe() ? '<option value="7">SBO 2</option>' : '')
						};

						function privateSetEnabled(isEnabled) {
							$(_signal1.htmlElement).prop( "disabled", !isEnabled );

							$(_signal2.htmlElement).prop( "disabled", !isEnabled );

							$(_signal3.htmlElement).prop( "disabled", !isEnabled );
						};

						function privateToObjectJSON() {

							return {
								signal1: _signal1.val,
								signal2: _signal2.val,
								signal3: _signal3.val
							};
						};

						function privateFromObjectJSON(objectJSON) {

							if ( objectJSON != undefined ) {

								for ( var property in objectJSON ) {

									if      ( property === "signal1" ) { _signal1.val = objectJSON[property]; }
									else if ( property === "signal2" ) { _signal2.val = objectJSON[property]; }
									else if ( property === "signal3" ) { _signal3.val = objectJSON[property]; }
								}
							}
						};

						return {

							uId: title.replace(/\s+/g, ''),
							flagsLabel: title,
							elementsArray: [
								_signal1,
								_signal2,
								_signal3
							],

							ToObjectJSON: function() { return privateToObjectJSON(); },
							FromObjectJSON: privateFromObjectJSON,
							SetEnabled: privateSetEnabled
						};
					}

				}
			};

			var privateGetItemsConvexHull = function( itemsArray ) {

				var anchorPoint = undefined;
				var reverse = false;
				var points = [];

				var privateFindPolarAngle = function ( a, b ) {
					var ONE_RADIAN = 57.295779513082;
					var deltaX = (b.x - a.x);
					var deltaY = (b.y - a.y);

					if (deltaX == 0 && deltaY == 0) {
						return 0;
					}

					var angle = Math.atan2(deltaY, deltaX) * ONE_RADIAN;

					if (reverse){
						if (angle <= 0) {
							angle += 360;
						}
					}else{
						if (angle >= 0) {
							angle += 360;
						}
					}

					return angle;
				};

				var privateAddPoint = function ( x, y ) {
					// Check to see if anchorPoint has been defined yet.
					if (anchorPoint === undefined) {
						// Create new anchorPoint.
						anchorPoint = {'x':x, 'y':y};

						// Sets anchorPoint if point being added is further left.
					} else if (anchorPoint.y > y || (anchorPoint.y == y && anchorPoint.x > x)) {
						anchorPoint.y = y;
						anchorPoint.x = x;
						points.unshift({'x':x, 'y':y});
						return;
					}

					points.push({'x':x, 'y':y});
				};

				var privateSortPoints = function () {

					return points.sort(function (a, b) {
						var polarA = privateFindPolarAngle( anchorPoint, a );
						var polarB = privateFindPolarAngle( anchorPoint, b );

						if (polarA < polarB) {
							return -1;
						}
						if (polarA > polarB) {
							return 1;
						}

						return 0;
					});
				};

				var privateCheckPoints = function ( p0, p1, p2 ) {
					var difAngle;
					var cwAngle = privateFindPolarAngle( p0, p1 );
					var ccwAngle = privateFindPolarAngle( p0, p2 );

					if (cwAngle > ccwAngle) {

						difAngle = cwAngle - ccwAngle;

						return !(difAngle > 180);

					} else if (cwAngle < ccwAngle) {

						difAngle = ccwAngle - cwAngle;

						return (difAngle > 180);

					}

					return false;
				};

				var privateComputeConvexHull = function () {
					var hullPoints = [],
						pnts,
						pntsLength;

					reverse = points.every(function(point){
						return (point.x < 0 && point.y < 0);
					});

					pnts = privateSortPoints();
					pntsLength = pnts.length;

					//If there are less than 4 points, joining these points creates a correct hull.
					if (pntsLength < 4) {
						return pnts;
					}

					// move first two points to output array
					hullPoints.push(pnts.shift(), pnts.shift());

					// scan is repeated until no concave points are present.
					while (true) {
						var p0,
							p1,
							p2;

						hullPoints.push(pnts.shift());

						p0 = hullPoints[hullPoints.length - 3];
						p1 = hullPoints[hullPoints.length - 2];
						p2 = hullPoints[hullPoints.length - 1];

						if (privateCheckPoints(p0, p1, p2)) {
							hullPoints.splice(hullPoints.length - 2, 1);
						}

						if (pnts.length == 0) {
							if (pntsLength == hullPoints.length) {
								return hullPoints;
							}
							pnts = hullPoints;
							pntsLength = pnts.length;
							hullPoints = [];
							hullPoints.push(pnts.shift(), pnts.shift());
						}
					}
				};

				var privateBuildResultingItemsArray = function () {

					var outputArray = [];
					var pointsArray = privateComputeConvexHull();

					for ( var i = 0; i < pointsArray.length; i++ ) {

						for ( var j = 0; j < itemsArray.length; j++ ) {

							if ( itemsArray[j].value.x === pointsArray[i].x && itemsArray[j].value.y === pointsArray[i].y ) {
								
								//add corners only if not already present
								if( outputArray.indexOf ( itemsArray[j] ) < 0) {
									outputArray.push(itemsArray[j]);
								}
								break;
							}
						}
					}

					return outputArray;
				};
				
				var privateOrderID = function ( arr ){
					if(arr != undefined) {
						for ( var i = 0; i < arr.length; i++ ) {
							arr[i].id = i;
						}
					}
					return arr;
				}

				for(var i=0; i < itemsArray.length; i++ ) {

					privateAddPoint( itemsArray[i].value.x, itemsArray[i].value.y );
				}
				
				var resArray =  privateBuildResultingItemsArray();
				
				//ordering IDs before return
				return privateOrderID(resArray);
			};

			var ItemListsManagerSettings = function() {
				return {
					indexPadding: 0,
					maxTotalItems: { value: 100 },
					itemLists: [],
					flagsObjects: []
				};
			};

			var ItemListSettings = function(listId) {
				return {

					uId: listId, 			
					enableAddFunctionality: true,
					infoFunctionalityText: undefined,
					showExtraButtonText: undefined,
					buttonText: "Add",
					showEnableCheckbox: false,
					showAlwaysActiveCombobox: false,
					maxItemsCount: 10,
					minItemsCount: 0,
					color: 0xffffff,
					filterFunction: undefined,

					callbacks: {
						onSomeItemAddedCallback: undefined,
						onSomeItemChangedCallback: undefined,
						onSomeItemRemovedCallback: undefined,
						onExtraButtonPressedCallback: undefined
					},
					
					itemSettings: {

						showFlagsInDialog: true,
						showValuesInDialog: true,
						isNameEditable: false,
						showTableType: undefined,
						extraParams: undefined,
						showIndex: false,
						uId: 0,
						itemPrefixName: "item",
						flagsObject: undefined,
						valueBuilder: undefined,
						flagsBuilder: undefined
					}
				};
			};

			var _flagsElements = function() {

				var _cellFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.FlagsCompact("Properties");
				var _cellFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _cellFlagsValues );
					_cellFlagsElement.setChangeCallback( _callbacks.cellFlags.onCellFlagsChange );

				var _dynamicVolumeFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.FlagsDynamicVolumes("Dynamic Volumes Properties");
				var _dynamicVolumeFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _dynamicVolumeFlagsValues );
					_dynamicVolumeFlagsElement.setChangeCallback( _callbacks.dynamicVolume.onDynamicVolumeFlagsChange );

				var _cellLayoutValues = new ItemPropertiesBuilders.flagsObjectBuildres.LayoutProperties("Height");
				var _cellLayoutElement = new _htmlManagers.SinglecolumnHtmlManager( _cellLayoutValues );
					_cellLayoutElement.setChangeCallback( _callbacks.cellLayout.onCellLayoutChange );

				var _brakeFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.FlagsBrake("Brake test timer");
				var _brakeFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _brakeFlagsValues );
					_brakeFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange );

				var _safeOutputFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.FlagsSafeOutput("Safe Output");
					_safeOutputFlagsValues.SetEnabled(!_robot.IsProfiSafe());
				var _safeOutputFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _safeOutputFlagsValues );
					_safeOutputFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange );

				var _systemFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.SystemFlags("System settings");
					_systemFlagsValues.SetEnabled(_robot.IsProfiSafe());
				var _systemFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _systemFlagsValues );
					_systemFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange );

				var _statusFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.StatusFlags("Status Signals");
					_statusFlagsValues.SetEnabled(_robot.IsErmEnabled());
				var _statusFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _statusFlagsValues );
					_statusFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange );

				var _speedModulationFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.SpeedModulationFlags("Speed Modulation");
					//_speedModulationFlagsValues.SetEnabled(_robot.HasSafeAxis() && _robot.IsSystemSafeKeyen());
					_speedModulationFlagsValues.SetEnabled(false);
				var _speedModulationFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _speedModulationFlagsValues );
					_speedModulationFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange ); 	
				
				var _toolOrientationFlagsValues = new ItemPropertiesBuilders.flagsObjectBuildres.ToolOrientationFlags("Tool Orientation");
				var _toolOrientationFlagsElement = new _htmlManagers.SinglecolumnHtmlManager( _toolOrientationFlagsValues );
					_toolOrientationFlagsElement.setChangeCallback( _callbacks.genericFlags.onGenericFlagsChange );
				
				return {
					cellFlagsElement: _cellFlagsElement,
					dynamicVolumeFlagsElement: _dynamicVolumeFlagsElement,
					cellLayoutElement: _cellLayoutElement,
					brakeFlagsElement: _brakeFlagsElement,
					safeOutputFlagsElement: _safeOutputFlagsElement,
					systemFlagsElement: _systemFlagsElement,
					statusFlagsElement: _statusFlagsElement,
					speedModulationFlagsElement: _speedModulationFlagsElement,
					toolOrientationFlagsElement: _toolOrientationFlagsElement
				};
			}();

			var _listSettings = function() {

				var _dynamicVolumeSettings = new ItemListSettings("DynamicVolumes");
					_dynamicVolumeSettings.enableAddFunctionality = false;
					_dynamicVolumeSettings.buttonText = "Dynamic Volumes";
					_dynamicVolumeSettings.infoFunctionalityText = undefined;// _popupUtility.InfoMessages().getInfoMessage("DynamicVolumes");
					_dynamicVolumeSettings.showEnableCheckbox = false;
					_dynamicVolumeSettings.minItemsCount = 10;
					_dynamicVolumeSettings.maxItemsCount = 10;
					_dynamicVolumeSettings.color = "Gold";
					_dynamicVolumeSettings.filterFunction = undefined;
					_dynamicVolumeSettings.callbacks.onSomeItemAddedCallback = _callbacks.dynamicVolume.onDynamicVolumeAdded;
					_dynamicVolumeSettings.callbacks.onSomeItemChangedCallback = _callbacks.dynamicVolume.onDynamicVolumeChanged;
					_dynamicVolumeSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_dynamicVolumeSettings.itemSettings.showFlagsInDialog = true;
					_dynamicVolumeSettings.itemSettings.isNameEditable = true;
					_dynamicVolumeSettings.itemSettings.showValuesInDialog = true;
					_dynamicVolumeSettings.itemSettings.showIndex = true;
					_dynamicVolumeSettings.itemSettings.enableDeleteButton = false;
					_dynamicVolumeSettings.itemSettings.itemPrefixName = "dynamic_volume";
					_dynamicVolumeSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueDynamicArea;
					_dynamicVolumeSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsExtended;
					_dynamicVolumeSettings.itemSettings.flagsObjects = undefined; 

				var _jointListSettings = new ItemListSettings("Joints");
					_jointListSettings.enableAddFunctionality = false;
					_jointListSettings.buttonText = "Joint Space Limiting";
					_jointListSettings.showEnableCheckbox = false;
					_jointListSettings.minItemsCount = 6;
					_jointListSettings.maxItemsCount = 6;
					_jointListSettings.color = "Gold";
					_jointListSettings.filterFunction = undefined;
					_jointListSettings.callbacks.onSomeItemAddedCallback = undefined;
					_jointListSettings.callbacks.onSomeItemChangedCallback = undefined;
					_jointListSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_jointListSettings.itemSettings.showFlagsInDialog = true;
					_jointListSettings.itemSettings.showValuesInDialog = true;
					_jointListSettings.itemSettings.showTableType = "Joint";
					_jointListSettings.itemSettings.showIndex = false;
					_jointListSettings.itemSettings.enableDeleteButton = false;
					_jointListSettings.itemSettings.itemPrefixName = "Set";
					_jointListSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueJoints;
					_jointListSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.JointFlags;
					_jointListSettings.itemSettings.flagsObjects = undefined;

				var _jointSectorSettings1 = new ItemListSettings("Axis1Sector");
					_jointSectorSettings1.enableAddFunctionality = false;
					_jointSectorSettings1.buttonText = "Joint functional sectors";
					_jointSectorSettings1.showEnableCheckbox = false;
					_jointSectorSettings1.minItemsCount = 1;
					_jointSectorSettings1.maxItemsCount = 1;
					_jointSectorSettings1.color = "Gold";
					_jointSectorSettings1.filterFunction = undefined;
					_jointSectorSettings1.callbacks.onSomeItemAddedCallback = undefined;
					_jointSectorSettings1.callbacks.onSomeItemChangedCallback = undefined;
					_jointSectorSettings1.callbacks.onSomeItemRemovedCallback = undefined;
					_jointSectorSettings1.itemSettings.showFlagsInDialog = false;
					_jointSectorSettings1.itemSettings.showValuesInDialog = true;
					_jointSectorSettings1.itemSettings.showTableType = "Sector";
					_jointSectorSettings1.itemSettings.showIndex = false;
					_jointSectorSettings1.itemSettings.extraParams = 0;
					_jointSectorSettings1.itemSettings.enableDeleteButton = false;
					_jointSectorSettings1.itemSettings.itemPrefixName = "Sector";
					_jointSectorSettings1.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueSector;
					_jointSectorSettings1.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_jointSectorSettings1.itemSettings.flagsObjects = undefined;				

				var _jointSectorSettings7 = new ItemListSettings("Axis7Sector");
					_jointSectorSettings7.enableAddFunctionality = false;
					_jointSectorSettings7.buttonText = ""; //titolo vuoto, fa fede quello del sel sopra
					_jointSectorSettings7.showEnableCheckbox = false;
					_jointSectorSettings7.minItemsCount = 1;
					_jointSectorSettings7.maxItemsCount = 1;
					_jointSectorSettings7.color = "Gold";
					_jointSectorSettings7.filterFunction = undefined;
					_jointSectorSettings7.callbacks.onSomeItemAddedCallback = undefined;
					_jointSectorSettings7.callbacks.onSomeItemChangedCallback = undefined;
					_jointSectorSettings7.callbacks.onSomeItemRemovedCallback = undefined;
					_jointSectorSettings7.itemSettings.showFlagsInDialog = false;
					_jointSectorSettings7.itemSettings.showValuesInDialog = true;
					_jointSectorSettings7.itemSettings.showTableType = "Sector";
					_jointSectorSettings7.itemSettings.showIndex = false;
					_jointSectorSettings7.itemSettings.extraParams = 6;
					_jointSectorSettings7.itemSettings.enableDeleteButton = false;
					_jointSectorSettings7.itemSettings.itemPrefixName = "Sector";
					_jointSectorSettings7.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueSector;
					_jointSectorSettings7.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_jointSectorSettings7.itemSettings.flagsObjects = undefined;

				var _highSpeedSettings = new ItemListSettings("HighSpeed");
					_highSpeedSettings.enableAddFunctionality = false;
					_highSpeedSettings.buttonText = "Cartesian Speed Limiting";
					_highSpeedSettings.showEnableCheckbox = false;
					_highSpeedSettings.minItemsCount = 1;
					_highSpeedSettings.maxItemsCount = 1;
					_highSpeedSettings.color = "Gold";
					_highSpeedSettings.filterFunction = undefined;
					_highSpeedSettings.callbacks.onSomeItemAddedCallback = undefined;
					_highSpeedSettings.callbacks.onSomeItemChangedCallback = _callbacks.genericFlags.onGenericFlagsChange;
					_highSpeedSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_highSpeedSettings.itemSettings.showFlagsInDialog = true;
					_highSpeedSettings.itemSettings.showValuesInDialog = false;
					_highSpeedSettings.itemSettings.showIndex = false;
					_highSpeedSettings.itemSettings.enableDeleteButton = false;
					_highSpeedSettings.itemSettings.itemPrefixName = "High Speed";
					_highSpeedSettings.itemSettings.valueBuilder =  undefined;
					_highSpeedSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.HighSpeedFlags;
					_highSpeedSettings.itemSettings.flagsObjects = undefined;

				var _progrSpeedSettings = new ItemListSettings("ProgrSpeed");
					_progrSpeedSettings.enableAddFunctionality = false;
					_progrSpeedSettings.buttonText = "";
					_progrSpeedSettings.showEnableCheckbox = false;
					_progrSpeedSettings.minItemsCount = 1;
					_progrSpeedSettings.maxItemsCount = 1;
					_progrSpeedSettings.color = "Gold";
					_progrSpeedSettings.filterFunction = undefined;
					_progrSpeedSettings.callbacks.onSomeItemAddedCallback = undefined;
					_progrSpeedSettings.callbacks.onSomeItemChangedCallback = _callbacks.genericFlags.onGenericFlagsChange;
					_progrSpeedSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_progrSpeedSettings.itemSettings.showFlagsInDialog = true;
					_progrSpeedSettings.itemSettings.showValuesInDialog = false;
					_progrSpeedSettings.itemSettings.showIndex = false;
					_progrSpeedSettings.itemSettings.enableDeleteButton = false;
					_progrSpeedSettings.itemSettings.itemPrefixName = "PROGR Speed";
					_progrSpeedSettings.itemSettings.valueBuilder = undefined;
					_progrSpeedSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.ProgrSpeedFlags;
					_progrSpeedSettings.itemSettings.flagsObjects = undefined;

				var _lowSpeedSettings = new ItemListSettings("LowSpeed");
					_lowSpeedSettings.enableAddFunctionality = false;
					_lowSpeedSettings.buttonText = "";
					_lowSpeedSettings.showEnableCheckbox = false;
					_lowSpeedSettings.minItemsCount = 1;
					_lowSpeedSettings.maxItemsCount = 1;
					_lowSpeedSettings.color = "Gold";
					_lowSpeedSettings.filterFunction = undefined;
					_lowSpeedSettings.callbacks.onSomeItemAddedCallback = undefined;
					_lowSpeedSettings.callbacks.onSomeItemChangedCallback = _callbacks.genericFlags.onGenericFlagsChange;
					_lowSpeedSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_lowSpeedSettings.itemSettings.showFlagsInDialog = true;
					_lowSpeedSettings.itemSettings.showValuesInDialog = false;
					_lowSpeedSettings.itemSettings.showIndex = false;
					_lowSpeedSettings.itemSettings.enableDeleteButton = false;
					_lowSpeedSettings.itemSettings.itemPrefixName = "Low Speed";
					_lowSpeedSettings.itemSettings.valueBuilder = undefined;
					_lowSpeedSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.LowSpeedFlags;
					_lowSpeedSettings.itemSettings.flagsObjects = undefined;

				var _jointSpeedSettings = new ItemListSettings("JointSpeed"); //TSK1456 joint speed limitation handling
					_jointSpeedSettings.enableAddFunctionality = false;
					_jointSpeedSettings.buttonText = "Joint Speed Limiting";
					_jointSpeedSettings.showEnableCheckbox = false;
					_jointSpeedSettings.minItemsCount = 1;
					_jointSpeedSettings.maxItemsCount = 1;
					_jointSpeedSettings.color = "Gold";
					_jointSpeedSettings.filterFunction = undefined;
					_jointSpeedSettings.callbacks.onSomeItemAddedCallback = undefined;
					_jointSpeedSettings.callbacks.onSomeItemChangedCallback = undefined;
					_jointSpeedSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_jointSpeedSettings.itemSettings.showFlagsInDialog = true;
					_jointSpeedSettings.itemSettings.showValuesInDialog = true;
					_jointSpeedSettings.itemSettings.showTableType = "JointSpeed";
					_jointSpeedSettings.itemSettings.showIndex = false;
					_jointSpeedSettings.itemSettings.enableDeleteButton = false;
					_jointSpeedSettings.itemSettings.itemPrefixName = "";
					_jointSpeedSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueJointSpeed;
					_jointSpeedSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.JointSpeedFlags;
					_jointSpeedSettings.itemSettings.flagsObjects = undefined;
					
				var _wallCornersSettings = new ItemListSettings("WallCorners");
					// List settings
					_wallCornersSettings.enableAddFunctionality = true;
					_wallCornersSettings.buttonText = "Add new corner";
					_wallCornersSettings.showExtraButtonText = "Update corner order"; //TSK1513 visualizzazione di un tasto opzionale per aggiornare i corner
					_wallCornersSettings.showEnableCheckbox = false;
					_wallCornersSettings.maxItemsCount = 8;
					_wallCornersSettings.minItemsCount = 3;
					_wallCornersSettings.color = "rgba(0, 0, 0, 0.2)";
					_wallCornersSettings.filterFunction = privateGetItemsConvexHull;
					_wallCornersSettings.callbacks.onSomeItemAddedCallback = _callbacks.wallCorner.onWallCornerAdded;
					_wallCornersSettings.callbacks.onSomeItemChangedCallback = _callbacks.wallCorner.onWallCornerChanged;
					_wallCornersSettings.callbacks.onSomeItemRemovedCallback = _callbacks.wallCorner.onWallCornerRemoved;
					_wallCornersSettings.callbacks.onExtraButtonPressedCallback = _callbacks.wallCorner.onWallCornerCheckOrder;
					// Items settings
					_wallCornersSettings.itemSettings.showFlagsInDialog = false;
					_wallCornersSettings.itemSettings.isNameEditable = true;
					_wallCornersSettings.itemSettings.showValuesInDialog = true;
					_wallCornersSettings.itemSettings.enableDeleteButton = true;
					_wallCornersSettings.itemSettings.showIndex = true;
					_wallCornersSettings.itemSettings.itemPrefixName = "corner";			
					_wallCornersSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.Value2DPoint;
					_wallCornersSettings.itemSettings.flagsBuilder = undefined;
					_wallCornersSettings.itemSettings.flagsObject = _flagsElements.cellFlagsElement;

				var _forbiddenVolumeSettings = new ItemListSettings("ForbiddenVolumes");
					// List settings
					_forbiddenVolumeSettings.enableAddFunctionality = true;
					_forbiddenVolumeSettings.buttonText = "Add volume";
					_forbiddenVolumeSettings.showEnableCheckbox = false;
					_forbiddenVolumeSettings.maxItemsCount = 10;
					_forbiddenVolumeSettings.minItemsCount = 0;
					_forbiddenVolumeSettings.color = "Silver";
					_forbiddenVolumeSettings.filterFunction = undefined;
					_forbiddenVolumeSettings.callbacks.onSomeItemAddedCallback = _callbacks.forbiddenVolume.onForbiddenVolumeAdded;
					_forbiddenVolumeSettings.callbacks.onSomeItemChangedCallback = _callbacks.forbiddenVolume.onForbiddenVolumeChanged;
					_forbiddenVolumeSettings.callbacks.onSomeItemRemovedCallback = _callbacks.forbiddenVolume.onForbiddenVolumeRemoved;
					// Items settings
					_forbiddenVolumeSettings.itemSettings.isNameEditable = true;
					_forbiddenVolumeSettings.itemSettings.showFlagsInDialog = false;
					_forbiddenVolumeSettings.itemSettings.showValuesInDialog = true;
					_forbiddenVolumeSettings.itemSettings.enableDeleteButton = true;
					_forbiddenVolumeSettings.itemSettings.showIndex = true;
					_forbiddenVolumeSettings.itemSettings.itemPrefixName = "forbidden_volume";			
					_forbiddenVolumeSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueArea;
					_forbiddenVolumeSettings.itemSettings.flagsBuilder = undefined;
					_forbiddenVolumeSettings.itemSettings.flagsObject = _flagsElements.cellFlagsElement;

				var _monitoringPointsSettings = new ItemListSettings("MonitoringPoints");
					// List settings
					_monitoringPointsSettings.enableAddFunctionality = true;
					_monitoringPointsSettings.buttonText = "Add monitoring point";
					_monitoringPointsSettings.showEnableCheckbox = false;
					_monitoringPointsSettings.maxItemsCount = 8;
					_monitoringPointsSettings.minItemsCount = 0;
					_monitoringPointsSettings.color = 0xff7f50;
					_monitoringPointsSettings.filterFunction = undefined;
					_monitoringPointsSettings.callbacks.onSomeItemAddedCallback = _callbacks.monitoringPoint.onMonitoringPointAdded;
					_monitoringPointsSettings.callbacks.onSomeItemChangedCallback = _callbacks.monitoringPoint.onMonitoringPointChanged;
					_monitoringPointsSettings.callbacks.onSomeItemRemovedCallback = _callbacks.monitoringPoint.onMonitoringPointRemoved;
					// Items settings
					_monitoringPointsSettings.itemSettings.showFlagsInDialog = false;
					_monitoringPointsSettings.itemSettings.showValuesInDialog = true;
					_monitoringPointsSettings.itemSettings.enableDeleteButton = true;
					_monitoringPointsSettings.itemSettings.showIndex = true;
					_monitoringPointsSettings.itemSettings.itemPrefixName = "monitoring point";			
					_monitoringPointsSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.Value3DPoint;
					_monitoringPointsSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_monitoringPointsSettings.itemSettings.flagsObject = undefined;

				var _toolset1Settings = new ItemListSettings("Toolset1");
					// List settings
					_toolset1Settings.enableAddFunctionality = false;
					_toolset1Settings.buttonText = "Toolset 1";
					_toolset1Settings.showEnableCheckbox = true;
					_toolset1Settings.showAlwaysActiveCombobox = true;
					_toolset1Settings.maxItemsCount = 2;
					_toolset1Settings.minItemsCount = 2;
					_toolset1Settings.color = 0x9932cc;
					_toolset1Settings.filterFunction = undefined;
					_toolset1Settings.callbacks.onSomeItemAddedCallback = _callbacks.toolset1Point.onToolset1PointAdded;
					_toolset1Settings.callbacks.onSomeItemChangedCallback = _callbacks.toolset1Point.onToolset1PointChanged;
					_toolset1Settings.callbacks.onSomeItemRemovedCallback = _callbacks.toolset1Point.onToolset1PointRemoved;
					// Items settings
					_toolset1Settings.itemSettings.showFlagsInDialog = false;
					_toolset1Settings.itemSettings.showValuesInDialog = true;
					_toolset1Settings.itemSettings.enableDeleteButton = false;
					_toolset1Settings.itemSettings.itemPrefixName = "tool1 point";			
					_toolset1Settings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.Value3DPoint;
					_toolset1Settings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEnableAndActiveOnly;
					_toolset1Settings.itemSettings.flagsObject = undefined;

				var _toolset2Settings = new ItemListSettings("Toolset2");
					// List settings
					_toolset2Settings.enableAddFunctionality = false;
					_toolset2Settings.buttonText = "Toolset 2";
					_toolset2Settings.showEnableCheckbox = true;
					_toolset2Settings.showAlwaysActiveCombobox = true;
					_toolset2Settings.maxItemsCount = 2;
					_toolset2Settings.minItemsCount = 2;
					_toolset2Settings.color = 0xda70d6;
					_toolset2Settings.filterFunction = undefined;
					_toolset2Settings.callbacks.onSomeItemAddedCallback = _callbacks.toolset2Point.onToolset2PointAdded;
					_toolset2Settings.callbacks.onSomeItemChangedCallback = _callbacks.toolset2Point.onToolset2PointChanged;
					_toolset2Settings.callbacks.onSomeItemRemovedCallback = _callbacks.toolset2Point.onToolset2PointRemoved;
					// Items settings
					_toolset2Settings.itemSettings.showFlagsInDialog = false;
					_toolset2Settings.itemSettings.showValuesInDialog = true;
					_toolset2Settings.itemSettings.enableDeleteButton = false;
					_toolset2Settings.itemSettings.itemPrefixName = "tool2 point";			
					_toolset2Settings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.Value3DPoint;
					_toolset2Settings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEnableAndActiveOnly;
					_toolset2Settings.itemSettings.flagsObject = undefined;
					
				var _axisMonitoringSettings = new ItemListSettings("AxisMonitoringPoint");
					// List settings
					_axisMonitoringSettings.enableAddFunctionality = false;
					_axisMonitoringSettings.buttonText = "Kinematics Monitoring points";
					_axisMonitoringSettings.showEnableCheckbox = false;
					_axisMonitoringSettings.showAlwaysActiveCombobox = false;
					_axisMonitoringSettings.maxItemsCount = 1;
					_axisMonitoringSettings.minItemsCount = 1;
					_axisMonitoringSettings.color = 0xff3300;
					_axisMonitoringSettings.filterFunction = undefined;
					_axisMonitoringSettings.callbacks.onSomeItemAddedCallback = _callbacks.axisMonitoringPoint.onAxisPointAdded;
					_axisMonitoringSettings.callbacks.onSomeItemChangedCallback = _callbacks.axisMonitoringPoint.onAxisPointChanged;
					_axisMonitoringSettings.callbacks.onSomeItemRemovedCallback = _callbacks.axisMonitoringPoint.onAxisPointRemoved;
					// Items settings
					_axisMonitoringSettings.itemSettings.showFlagsInDialog = false;
					_axisMonitoringSettings.itemSettings.showValuesInDialog = true;
					_axisMonitoringSettings.itemSettings.enableDeleteButton = false;
					_axisMonitoringSettings.itemSettings.itemPrefixName = "axis monitoring points";			
					_axisMonitoringSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueAxisMonitoring;
					_axisMonitoringSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_axisMonitoringSettings.itemSettings.flagsObject = undefined;
					
				var _elbowMonitoringSettings = new ItemListSettings("ElbowMonitoringPoint");
					// List settings
					_elbowMonitoringSettings.enableAddFunctionality = false;
					_elbowMonitoringSettings.buttonText = "";
					_elbowMonitoringSettings.showEnableCheckbox = false;
					_elbowMonitoringSettings.showAlwaysActiveCombobox = false;
					_elbowMonitoringSettings.maxItemsCount = 1;
					_elbowMonitoringSettings.minItemsCount = 1;
					_elbowMonitoringSettings.color = 0xff3300;
					_elbowMonitoringSettings.filterFunction = undefined;
					_elbowMonitoringSettings.callbacks.onSomeItemAddedCallback = _callbacks.axisMonitoringPoint.onElbowPointChanged;
					_elbowMonitoringSettings.callbacks.onSomeItemChangedCallback = _callbacks.axisMonitoringPoint.onElbowPointChanged;
					_elbowMonitoringSettings.callbacks.onSomeItemRemovedCallback = _callbacks.axisMonitoringPoint.onElbowPointChanged;
					// Items settings
					_elbowMonitoringSettings.itemSettings.showFlagsInDialog = false;
					_elbowMonitoringSettings.itemSettings.showValuesInDialog = true;
					_elbowMonitoringSettings.itemSettings.enableDeleteButton = false;
					_elbowMonitoringSettings.itemSettings.itemPrefixName = "elbow monitoring points";			
					_elbowMonitoringSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueElbowMonitoring;
					_elbowMonitoringSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_elbowMonitoringSettings.itemSettings.flagsObject = undefined;

				var _functionalSpaceASettings = new ItemListSettings("FunctionalSpaceA");
					// List settings
					_functionalSpaceASettings.enableAddFunctionality = true;
					_functionalSpaceASettings.buttonText = "Add volume";
					_functionalSpaceASettings.showEnableCheckbox = true;
					_functionalSpaceASettings.maxItemsCount = 15;
					_functionalSpaceASettings.minItemsCount = 1;
					_functionalSpaceASettings.color = "rgba(65, 105, 225, 1.0)";
					_functionalSpaceASettings.filterFunction = undefined;
					_functionalSpaceASettings.callbacks.onSomeItemAddedCallback = _callbacks.functionalSpaceA.onFunctionalSpaceAAdded;
					_functionalSpaceASettings.callbacks.onSomeItemChangedCallback = _callbacks.functionalSpaceA.onFunctionalSpaceAChanged;
					_functionalSpaceASettings.callbacks.onSomeItemRemovedCallback = _callbacks.functionalSpaceA.onFunctionalSpaceARemoved;
					// Items settings
					_functionalSpaceASettings.itemSettings.showFlagsInDialog = false;
					_functionalSpaceASettings.itemSettings.isNameEditable = true;
					_functionalSpaceASettings.itemSettings.showValuesInDialog = true;
					_functionalSpaceASettings.itemSettings.enableDeleteButton = true;
					_functionalSpaceASettings.itemSettings.showIndex = true;
					_functionalSpaceASettings.itemSettings.itemPrefixName = "functional_space_A";			
					_functionalSpaceASettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueArea;
					_functionalSpaceASettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEnableOnly;
					_functionalSpaceASettings.itemSettings.flagsObject = undefined;

				var _functionalSpaceBSettings = new ItemListSettings("FunctionalSpaceB");
					// List settings
					_functionalSpaceBSettings.enableAddFunctionality = true;
					_functionalSpaceBSettings.buttonText = "Add volume";
					_functionalSpaceBSettings.showEnableCheckbox = true;
					_functionalSpaceBSettings.maxItemsCount = 15;
					_functionalSpaceBSettings.minItemsCount = 1;
					_functionalSpaceBSettings.color = "rgba(100, 149, 237, 1.0)";
					_functionalSpaceBSettings.filterFunction = undefined;
					_functionalSpaceBSettings.callbacks.onSomeItemAddedCallback = _callbacks.functionalSpaceB.onFunctionalSpaceBAdded;
					_functionalSpaceBSettings.callbacks.onSomeItemChangedCallback = _callbacks.functionalSpaceB.onFunctionalSpaceBChanged;
					_functionalSpaceBSettings.callbacks.onSomeItemRemovedCallback = _callbacks.functionalSpaceB.onFunctionalSpaceBRemoved;
					// Items settings
					_functionalSpaceBSettings.itemSettings.showFlagsInDialog = false;
					_functionalSpaceBSettings.itemSettings.isNameEditable = true;
					_functionalSpaceBSettings.itemSettings.showValuesInDialog = true;
					_functionalSpaceBSettings.itemSettings.enableDeleteButton = true;
					_functionalSpaceBSettings.itemSettings.showIndex = true;
					_functionalSpaceBSettings.itemSettings.itemPrefixName = "functional_space_B";			
					_functionalSpaceBSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueArea;
					_functionalSpaceBSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEnableOnly;
					_functionalSpaceBSettings.itemSettings.flagsObject = undefined;
					
				var _vectorWSettings = new ItemListSettings("ToolOrientationVectorW"); //TSKXXX tool orientation settings
					_vectorWSettings.enableAddFunctionality = false;
					_vectorWSettings.buttonText = "Orientation Coordinate System";
					_vectorWSettings.showEnableCheckbox = false;
					_vectorWSettings.minItemsCount = 1;
					_vectorWSettings.maxItemsCount = 1;
					_vectorWSettings.color = "Gold";
					_vectorWSettings.filterFunction = undefined;
					_vectorWSettings.callbacks.onSomeItemAddedCallback = undefined;
					_vectorWSettings.callbacks.onSomeItemChangedCallback = undefined;
					_vectorWSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_vectorWSettings.itemSettings.showFlagsInDialog = false;
					_vectorWSettings.itemSettings.showValuesInDialog = true;
					_vectorWSettings.itemSettings.showTableType = undefined;
					_vectorWSettings.itemSettings.showIndex = false;
					_vectorWSettings.itemSettings.enableDeleteButton = false;
					_vectorWSettings.itemSettings.itemPrefixName = "";
					_vectorWSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueVectorW;
					_vectorWSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_vectorWSettings.itemSettings.flagsObjects = undefined;
					
				var _orientationOCSSettings = new ItemListSettings("ToolOrientationOrcs"); //TSKXXX tool orientation settings
					_orientationOCSSettings.enableAddFunctionality = false;
					_orientationOCSSettings.buttonText = ""; //no title
					_orientationOCSSettings.showEnableCheckbox = false;
					_orientationOCSSettings.minItemsCount = 1;
					_orientationOCSSettings.maxItemsCount = 1;
					_orientationOCSSettings.color = "Gold";
					_orientationOCSSettings.filterFunction = undefined;
					_orientationOCSSettings.callbacks.onSomeItemAddedCallback = undefined;
					_orientationOCSSettings.callbacks.onSomeItemChangedCallback = undefined;
					_orientationOCSSettings.callbacks.onSomeItemRemovedCallback = undefined;
					_orientationOCSSettings.itemSettings.showFlagsInDialog = false;
					_orientationOCSSettings.itemSettings.showValuesInDialog = true;
					_orientationOCSSettings.itemSettings.showTableType = undefined;
					_orientationOCSSettings.itemSettings.showIndex = false;
					_orientationOCSSettings.itemSettings.enableDeleteButton = false;
					_orientationOCSSettings.itemSettings.itemPrefixName = "";
					_orientationOCSSettings.itemSettings.valueBuilder = ItemPropertiesBuilders.valueObjectBuilders.ValueOrientationOCS;
					_orientationOCSSettings.itemSettings.flagsBuilder = ItemPropertiesBuilders.flagsObjectBuildres.FlagsEmpty;
					_orientationOCSSettings.itemSettings.flagsObjects = undefined;

				return {

					dynamicVolumeSettings: _dynamicVolumeSettings,
					jointListSettings:  _jointListSettings,
					jointSectorSettings1: _jointSectorSettings1,
					jointSectorSettings7: _jointSectorSettings7,
					highSpeedSettings: _highSpeedSettings,
					progrSpeedSettings: _progrSpeedSettings,
					lowSpeedSettings: _lowSpeedSettings,
					jointSpeedSettings: _jointSpeedSettings,
					wallCornersSettings: _wallCornersSettings,
					forbiddenVolumeSettings: _forbiddenVolumeSettings,
					axisMonitoringSettings: _axisMonitoringSettings,
					elbowMonitoringSettings: _elbowMonitoringSettings,
					monitoringPointsSettings: _monitoringPointsSettings,
					toolset1Settings: _toolset1Settings,
					toolset2Settings: _toolset2Settings,
					functionalSpaceASettings: _functionalSpaceASettings,
					functionalSpaceBSettings: _functionalSpaceBSettings,
					vectorWSettings: _vectorWSettings,
					orientationOCSSettings: _orientationOCSSettings
				};
			}();

			var _managersSettings = function() {

				var _volumesManagerSettings = new ItemListsManagerSettings();
					_volumesManagerSettings.maxTotalItems.value = 10;
					_volumesManagerSettings.itemLists.push( _listSettings.dynamicVolumeSettings );
					_volumesManagerSettings.flagsObjects.push( _flagsElements.dynamicVolumeFlagsElement );
					
				var _OCSManagerSettings = new ItemListsManagerSettings();
					_OCSManagerSettings.flagsObjects.push( _flagsElements.toolOrientationFlagsElement );
					_OCSManagerSettings.itemLists.push( _listSettings.vectorWSettings );
					_OCSManagerSettings.itemLists.push( _listSettings.orientationOCSSettings );

				var _speedManagerSettings = new ItemListsManagerSettings();
					_speedManagerSettings.flagsObjects.push( _flagsElements.speedModulationFlagsElement );
					_speedManagerSettings.itemLists.push( _listSettings.highSpeedSettings );
					_speedManagerSettings.itemLists.push( _listSettings.lowSpeedSettings );
					_speedManagerSettings.itemLists.push( _listSettings.progrSpeedSettings );
					_speedManagerSettings.itemLists.push( _listSettings.jointSpeedSettings );

				var _systemManagerSettings = new ItemListsManagerSettings();
					_systemManagerSettings.flagsObjects.push( _flagsElements.systemFlagsElement );
					_systemManagerSettings.flagsObjects.push( _flagsElements.statusFlagsElement );


				var _jointManagerSettings = new ItemListsManagerSettings();
					_jointManagerSettings.itemLists.push( _listSettings.jointListSettings )
					_jointManagerSettings.itemLists.push( _listSettings.jointSectorSettings1 )
					_jointManagerSettings.itemLists.push( _listSettings.jointSectorSettings7 );

				var _cellManagerSettings = new ItemListsManagerSettings();
					_cellManagerSettings.indexPadding = 2;
					_cellManagerSettings.flagsObjects.push( _flagsElements.cellFlagsElement );
					_cellManagerSettings.flagsObjects.push( _flagsElements.cellLayoutElement );
					_cellManagerSettings.itemLists.push( _listSettings.wallCornersSettings );
					_cellManagerSettings.itemLists.push( _listSettings.forbiddenVolumeSettings ); 

				var _toolManagerSettings = new ItemListsManagerSettings();
					_toolManagerSettings.itemLists.push( _listSettings.monitoringPointsSettings );
					_toolManagerSettings.itemLists.push( _listSettings.axisMonitoringSettings );
					_toolManagerSettings.itemLists.push( _listSettings.elbowMonitoringSettings );
					_toolManagerSettings.itemLists.push( _listSettings.toolset1Settings );
					_toolManagerSettings.itemLists.push( _listSettings.toolset2Settings );

				var _functionalSpaceAManagerSettings = new ItemListsManagerSettings();
					_functionalSpaceAManagerSettings.itemLists.push( _listSettings.functionalSpaceASettings );

				var _functionalSpaceBManagerSettings = new ItemListsManagerSettings();
					_functionalSpaceBManagerSettings.itemLists.push( _listSettings.functionalSpaceBSettings );

				var _brakeManagerSettings = new ItemListsManagerSettings();
					_brakeManagerSettings.flagsObjects.push( _flagsElements.brakeFlagsElement );

				var _safeioManagerSettings = new ItemListsManagerSettings();
					_safeioManagerSettings.flagsObjects.push( _flagsElements.safeOutputFlagsElement );

				return {
					volumesManagerSettings: _volumesManagerSettings,
					speedManagerSettings: _speedManagerSettings,
					systemManagerSettings: _systemManagerSettings,
					jointManagerSettings: _jointManagerSettings,
					cellManagerSettings: _cellManagerSettings,
					toolManagerSettings: _toolManagerSettings,
					functionalSpaceAManagerSettings: _functionalSpaceAManagerSettings,
					functionalSpaceBManagerSettings: _functionalSpaceBManagerSettings,
					brakeManagerSettings: _brakeManagerSettings,
					safeioManagerSettings: _safeioManagerSettings,
					OCSManagerSettings: _OCSManagerSettings
				};
			}();
				
			return {
				volumesManagerSettings: _managersSettings.volumesManagerSettings,
				speedManagerSettings: _managersSettings.speedManagerSettings,
				systemManagerSettings: _managersSettings.systemManagerSettings,
				jointManagerSettings: _managersSettings.jointManagerSettings,
				cellManagerSettings: _managersSettings.cellManagerSettings,
				toolManagerSettings: _managersSettings.toolManagerSettings,
				functionalSpaceAManagerSettings: _managersSettings.functionalSpaceAManagerSettings,
				functionalSpaceBManagerSettings: _managersSettings.functionalSpaceBManagerSettings,
				brakeManagerSettings: _managersSettings.brakeManagerSettings,
				safeioManagerSettings: _managersSettings.safeioManagerSettings,
				OCSManagerSettings: _managersSettings.OCSManagerSettings
			};
		}();

		var ItemListsManager = function(settings) {

			var ItemList = function(settings) {

				var Item = function(settings) {

					var _settings = {

						showFlagsInDialog: 	settings.showFlagsInDialog,
						isNameEditable:     settings.isNameEditable,
						showValuesInDialog: settings.showValuesInDialog,
						showTableType: 	    settings.showTableType,
						extraParams:		settings.extraParams,
						showIndex:          settings.showIndex,
						uId: 				settings.uId,
						itemPrefixName: 	settings.itemPrefixName,
						enableDeleteButton: settings.enableDeleteButton,
						flagsObject: 		settings.flagsObject,
						valueBuilder: 		settings.valueBuilder,
						flagsBuilder: 		settings.flagsBuilder,
						objectJSON: 		settings.objectJSON,
						SetUid:			function(newId){ settings.uId = newId; }
					};

					var _valueManagerSettings = undefined;
					var _flagsManagerSettings = undefined;

					var _valueManager = undefined;
					var _flagsManager = undefined;

					var _itemName = _settings.itemPrefixName; // + " " + (_settings.uId + 1).toString();

					var _htmlTitleElement;
					var _menurowButton;
					var _menurowDeleteButton;

					var _htmlDialog;
					var _htmlMenuRow;

					var _callbacks = {
						onItemChangeCallback: 	undefined,
						onItemRemoveCallback: 	undefined
					};
					
					function setValuesClickFunction(){
						// Update values and flags
						if( _valueManager != undefined  && settings.showValuesInDialog) {
							_valueManager.UpdateValues();
						}
						_flagsManager.UpdateValues();

						// Update item name
						_itemName = $(_htmlTitleElement).val();
//						$(_menurowButton).val( _itemName + " id:" + (_settings.uId + 1).toString() );

						// Call callback if required
						if( _callbacks.onItemChangeCallback != undefined ) {

							_callbacks.onItemChangeCallback( _settings.uId );
						}

						var name = _itemName;
						if( _valueManagerSettings != undefined  && settings.showValuesInDialog && _valueManagerSettings.hasOwnProperty("location")){
							if ( _valueManagerSettings.location.valuesArray.length === 2 ) {

								// Is a 2d point
								name = '(' + _valueManagerSettings.location.valuesArray[0].val.toString() + ', ' + _valueManagerSettings.location.valuesArray[1].val.toString() + ')';
							}
						}
						$(_menurowButton).val(name);
					}

					function privateAddDialogToDOM() {

						function appendTitle(content) {

							var initialTitle = "";
							_htmlTitleElement = $('<input type="text" id="txt_title" value="' + _itemName + '" class="' + _cssClass.dialog_title + '"/>')
							.focusin( function(sender){
								initialTitle = $(this).val();
							})
							.focusout( function(sender) {
								var txtValue = $(this).val();
								if(_settings.isNameEditable){
									var isValid = _validator.ValidateTitle(txtValue);
									if(!isValid ){
										_utility.MessageBox("Info", "Invalid name", true).Show();
										// alert('Invalid name');
										$(this).val(initialTitle);
										$(this).preventFocus();
									}
								}
							})
							.prop("readonly", !_settings.isNameEditable);
							
							if(_settings.isNameEditable){
								_htmlTitleElement.css('text-decoration', 'underline');
							}

							$(content).append( _htmlTitleElement );
						};

						function appendFlags(content) {

							if( _flagsManager != undefined && _settings.showFlagsInDialog ) {

								$(content).append( _flagsManager.getHtml() );
							}
						};

						function appendValues(content) {

							if( _valueManager != undefined  && _settings.showValuesInDialog ) {

								$(content).append( _valueManager.getHtml() );
							}
						};

						function appendBottomButtons(content) {

							content
								.append( $('<input id="setBtnId" type="button" value="Set" class="' + _cssClass.dialog_button + '"/>') 

										.click(function () {

											
											setValuesClickFunction();
//											// Update values and flags
//											if( _valueManager != undefined  && settings.showValuesInDialog) {
//												_valueManager.UpdateValues();
//											}
//											_flagsManager.UpdateValues();
//
//											// Update item name
//											_itemName = $(_htmlTitleElement).val();
//											$(_menurowButton).val( _itemName );
//
//											// Call callback if required
//											if( _callbacks.onItemChangeCallback != undefined ) {
//
//												_callbacks.onItemChangeCallback( _settings.uId );
//											}
//
//											var name = _itemName;
//											if( _valueManagerSettings != undefined  && settings.showValuesInDialog && _valueManagerSettings.hasOwnProperty("location")){
//												if ( _valueManagerSettings.location.valuesArray.length === 2 ) {
//
//													// Is a 2d point
//													name = '(' + _valueManagerSettings.location.valuesArray[0].val.toString() + ', ' + _valueManagerSettings.location.valuesArray[1].val.toString() + ')';
//												}
//											}
//											$(_menurowButton).val(name);

											// Close dialog
											$(_htmlDialog).removeClass(_cssClass.dialog_shown);
											//$( 'body' ).css({
											//	"overflow": "hidden"
											//});
										})
								)
								.append(

									$('<input type="button" value="Cancel" class="' + _cssClass.dialog_button + '"/>') 

										.click( function () {

											_flagsManager.WriteValuesIntoForm();
											
											// Close dialog
											$(_htmlDialog).removeClass(_cssClass.dialog_shown);
											//$( 'body' ).css({
											//	"overflow": "hidden"
											//});
										})
								)
							;
						};

						var dialogContent = $('<div class="' + _cssClass.dialog_content + '"/>');

						appendTitle(dialogContent);
						appendFlags(dialogContent);
						appendValues(dialogContent);
						appendBottomButtons(dialogContent);

						_htmlDialog = $('<div class="' + _cssClass.dialog_hidden + '">')
							.append( dialogContent )
						;

						$('body').append(_htmlDialog);
					};
					
					//TSK1357: compacting items id
					function updateMenuRowName(){
						
						var name = _itemName;
						if( _valueManagerSettings != undefined  && settings.showValuesInDialog && _valueManagerSettings.hasOwnProperty("location")){
							if ( _valueManagerSettings.location.valuesArray.length === 2 ) {

								// Is a 2d point
								name = '(' + _valueManagerSettings.location.valuesArray[0].val.toString() + ', ' + _valueManagerSettings.location.valuesArray[1].val.toString() + ')';
							}
						}	
						//$(_menurowButton).val(name);
						if(_settings.showIndex ){
							$(this.getHtmlRowElement()).find("."+ _cssClass.menu_rowindex).val(parseInt(_settings.uId) + 1);
						}
						
						$(this.getHtmlRowElement()).find("."+ _cssClass.menu_rowbutton).val( name );						
						
					};

					function privateBuildMenuRow() {

						var name = _itemName;
						
						if( _valueManagerSettings != undefined  && _settings.showValuesInDialog && _valueManagerSettings.hasOwnProperty("location")){

							if ( _valueManagerSettings.location.valuesArray.length === 2 ) {

								// Is a 2d point
								name = '(' + _valueManagerSettings.location.valuesArray[0].val.toString() + ', ' + _valueManagerSettings.location.valuesArray[1].val.toString() + ')';
							}
						}

						_menurowButton = $('<input type="button" class="' + _cssClass.menu_rowbutton + '" value="' + name  + '">' )

							.click( function ( event ) {

								// Sync form with actual values and flags
								if( _valueManager != undefined  && _settings.showValuesInDialog){
									_valueManager.WriteValuesIntoForm();
								}
								_flagsManager.WriteValuesIntoForm();

								// Sync dialog title with actual item name
								$(_htmlTitleElement).val( _itemName );

								$(_htmlDialog).addClass(_cssClass.dialog_shown);
								//$( 'body' ).css({
								//	"overflow": "hidden"
								//});
							});

						_menurowDeleteButton = $('<input type="button" class="' + _cssClass.menu_rowdeletebutton + '">' )
										
							.click( function ( event ) {

								if( _callbacks.onItemRemoveCallback != undefined ) {

									_callbacks.onItemRemoveCallback( _settings.uId );						
								}
							})
						;

						_menurowIndex = $('<input type="button" disabled class="' + _cssClass.menu_rowindex + '" value="' + (parseInt(_settings.uId) + 1).toString() + '">' );

						//handle a 3 columns table if both index and delete button are required
						if (_settings.enableDeleteButton && _settings.showIndex){
							
							_htmlMenuRow = $('<tr>')
								.append( $('<td>').append( _menurowButton ) )
								.append( $('<td>').append( _menurowIndex ) )
								.append( $('<td>').append( _menurowDeleteButton ) )
							;
							
						} 
						else if ( _settings.enableDeleteButton ) {
							
							_htmlMenuRow = $('<tr>')
								.append( $('<td>').append( _menurowButton ) )
								.append( $('<td>').append( _menurowDeleteButton ) )
							;

						} 
						else if ( _settings.showIndex ) {
							
							_htmlMenuRow = $('<tr>')
								.append( $('<td>').append( _menurowButton ) )
								.append( $('<td>').append( _menurowIndex ) )
							;

						}
						else {

							_htmlMenuRow = $('<tr>')
								.append( $('<td colspan="2">').append( _menurowButton ) )
							;
						}
					};

					function privateInitialize() {

						if( _settings.objectJSON != undefined ) {
							_itemName = _settings.objectJSON.name;
						}

						if( _settings.showValuesInDialog){
							if(_settings.showTableType == "Joint"){
								// tabella dei valori custom per set giunti
								_valueManagerSettings = new _settings.valueBuilder();
								_valueManager = new _htmlManagers.JointTableHtmlManager( _valueManagerSettings );
								// _robot.SaveJointValueManager(_valueManager);
								if( _settings.objectJSON != undefined ) {
									_valueManager.ObjectJSONToData( _settings.objectJSON.value );
								}
							}else if(_settings.showTableType == "Sector"){
								// tabella dei valori custom per porzioni giunti
								var axIdx = 0;
								if( _settings.extraParams != undefined){
									axIdx = _settings.extraParams;
								}
								_valueManagerSettings = new _settings.valueBuilder(axIdx);
								_valueManager = new _htmlManagers.SectorTableHtmlManager( _valueManagerSettings );
								// _robot.SaveJointValueManager(_valueManager);
								if( _settings.objectJSON != undefined ) {
									_valueManager.ObjectJSONToData( _settings.objectJSON.value );
								}
							}else if(_settings.showTableType == "JointSpeed"){
								// tabella dei valori custom per velocità giunti
								_valueManagerSettings = new _settings.valueBuilder();
								_valueManager = new _htmlManagers.JointSpeedTableHtmlManager( _valueManagerSettings );
								if( _settings.objectJSON != undefined ) {
									_valueManager.ObjectJSONToData( _settings.objectJSON.value );
								}
							}else{
								_valueManagerSettings = new _settings.valueBuilder();
								_valueManager = new _htmlManagers.MulticolumnHtmlManager( _valueManagerSettings );
								if( _settings.objectJSON != undefined ) {
									_valueManager.ObjectJSONToData( _settings.objectJSON.value );
								}
							}
						} 

						_flagsManager = _settings.flagsObject;
						if(_flagsManager == undefined ) {
							_flagsManagerSettings = new _settings.flagsBuilder("Properties");
							_flagsManager = new _htmlManagers.SinglecolumnHtmlManager( _flagsManagerSettings, _settings.showValuesInDialog || _settings.showFlagsInDialog );
							if(_settings.objectJSON != undefined) {
								_flagsManager.ObjectJSONToData( _settings.objectJSON.flags );
							}
						}

						privateAddDialogToDOM();

						privateBuildMenuRow();
					};

					function privateEnable(enabled) {

						// $(_htmlMenuRow).prop('disabled', !enabled);
						// $(_menurowButton).prop('disabled', !enabled);
						// $(_menurowDeleteButton).prop('disabled', !enabled);

						_flagsManager.setEnabled(enabled);
						_flagsManager.WriteValuesIntoForm();

						// Call callback if required
						if( _callbacks.onItemChangeCallback != undefined ) {

							_callbacks.onItemChangeCallback( _settings.uId );
						}
					};

					function privateAlwaysActive(alwaysActive) {

						_flagsManager.setAlwaysActive(alwaysActive);
						_flagsManager.WriteValuesIntoForm();

						// Call callback if required
						if( _callbacks.onItemChangeCallback != undefined ) {

							_callbacks.onItemChangeCallback( _settings.uId );
						}
					};

					function privateDispose() {

						$(_htmlMenuRow).hide('fast', function(){ $(_htmlMenuRow).remove(); });
						$(_htmlDialog).remove();
					};
					
					function privateDisposeNoAnimation() {
						
						$(_htmlMenuRow).remove();
						$(_htmlDialog).remove();
					};
					
					function privateFlashAnimation() {
						
						$(_htmlMenuRow).hide('fast', function(){ $(_htmlMenuRow).show('fast'); });
						
					};

					//TSK1357: compacting items id
					function privateChangeId(newId) {
						this.itemId=newId;
						_settings.SetUid(newId);
						_settings.uId = newId;
					};
					
					function privateUpdateValuesFlags(){
						if( _valueManager != undefined  && settings.showValuesInDialog) {
							_valueManager.UpdateValues();
						}
						_flagsManager.UpdateValues();
					}
					
					function privateToObjectJSON() {

						var valueObject = undefined;
						if( _valueManager != undefined && _settings.showValuesInDialog){
							valueObject = _valueManager.DataToObjectJSON();
						}
						var flagsObject = _flagsManager.DataToObjectJSON();

						return {
							id: _settings.uId != undefined ? parseInt(_settings.uId) : _settings.uId,
							name: _itemName,
							value: valueObject,
							flags: flagsObject
						};
					};

					privateInitialize();

					return {

						itemId: _settings.uId,
						value: _valueManager,
						flags: _flagsManager,

						getHtmlRowElement: function() { return _htmlMenuRow; },

						IsEnabled: function (enabled) { privateEnable(enabled); },
						IsAlwaysActive: function (alwaysActive) { privateAlwaysActive(alwaysActive); },
						Dispose: privateDispose,
						DisposeNoAnimation : privateDisposeNoAnimation,
						FlashAnimation: privateFlashAnimation,
						ChangeId: privateChangeId,
						UpdateMenuRow: updateMenuRowName,
						SetValueClick: setValuesClickFunction,
						UpdateValuesFlags: privateUpdateValuesFlags,
												
						// Events setters
						setItemChangeCallback: function ( callback ) { _callbacks.onItemChangeCallback = callback; },
						setItemRemoveCallback: function ( callback ) { _callbacks.onItemRemoveCallback = callback; },

						ToObjectJSON: privateToObjectJSON
					};
				};

				var _settings = settings;

				var _items = {};

				var _enableCheckbox = undefined;
				var _alwaysActiveCombobox = undefined;

				var _callbacks = {
					onSomeItemAddedCallback: undefined,
					onSomeItemChangedCallback: undefined,
					onSomeItemRemovedCallback: undefined
				};

				var _htmlTable;

				var _uIdManager = function () {

					var _itemsUIds = [];

					function privateAllocFirstFreeUId() {

						for ( var i = 0; i < _itemsUIds.length; i++ ) {

							if ( _itemsUIds[i] === 0 ) {

								_itemsUIds[i] = 1;

								return i;
							}
						}

						_itemsUIds.push( 1 );

						return ( _itemsUIds.length - 1 );
					};

					function privateAllocUId( uId ) {

						while ( _itemsUIds.length < uId ) {

							_itemsUIds.push( 0 );
						}

						_itemsUIds[uId] = 1;
					};

					function privateFreeUId( uId ) {

						if ( uId < _itemsUIds.length ) {

							_itemsUIds[uId] = 0;
						}
					};
					
					function privateFreeAllUid ( ) {
						for (var i=0; i< _itemsUIds.length; i++) {
							_itemsUIds[i] = 0;
						}
					}
					
					//TSK1357: compacting items id
					function privateCompactUId( ) {

						for(var i = 0; i < _itemsUIds.length; i++  ) {

							if ( _itemsUIds[i] === 0 ) {
								_itemsUIds.splice(i, 1);
							}
						}
					};

					return {

						AllocFirstFreeUId: 	privateAllocFirstFreeUId,
						AllocUId: 			privateAllocUId,
						FreeUId: 			privateFreeUId,
						FreeAllUid:			privateFreeAllUid,
						CompactUId:			privateCompactUId
					};
				}();

				function privateInitialize() {

					function privateBuildAddButton() {
						var addButton=undefined;
						if(_settings.enableAddFunctionality){
							addButton = $( '<input type="button" class="' + _cssClass.menu_button + '" value="' + _settings.buttonText + '" />' )

								.click( function (event) { 

									privateAddItem(); 
								} )
								//.prop('disabled', !_settings.enableAddFunctionality)
								.prop('hidden', _settings.buttonText=="")
								.css( 'background-image', 'url(\'../images/environments/add.png\')')
								.css( 'background-position', 'left')
								.css( 'background-repeat', 'no-repeat');	
						}else{
							addButton = $( '<input type="button" class="' + _cssClass.title_button + '" value="' + _settings.buttonText + '" />' )

								.prop('disabled', !_settings.enableAddFunctionality)
								.prop('hidden', _settings.buttonText=="")
							;	
						}
						return addButton;
					};
					
					//funzionalita che permette di mostrare un tasto di info accanto al titolo della funzionalità
					function privateBuildInfoButton(){
						var infoButton = undefined;
						
						infoButton = $( '<input type="button" class="' + _cssClass.info_button + '" value="i" />' )

							.click( function (event) { 
								if(_settings.infoFunctionalityText != undefined){
									//showInfoWindow
									_utility.MessageBox("Info", _settings.infoFunctionalityText, true).Show();	
								}
							} ).prop('hidden', _settings.infoFunctionalityText==undefined);	
						
						return infoButton;
					};
					
					//funzionalita che permette di mostrare un tasto opzionale sotto l'add button
					function privateBuildExtraButton(buttonText) {
						var extraButton=undefined;
		
							extraButton = $( '<input type="button" class="' + _cssClass.menu_button + '" value="' + buttonText + '" />' )

								.click( function (event) { 
									
									if ( _settings.callbacks.onExtraButtonPressedCallback != undefined ) {
										
										 _settings.callbacks.onExtraButtonPressedCallback( protectedGetItemListFromListId(_settings.uId) );
									}
								} )

								.prop('hidden', buttonText=="");	
						
						return extraButton;
					};
					
					function privateBuildEnableCheckboxLine() {

						_enableCheckbox = $( '<input type="checkbox" class="' + _cssClass.menu_button + '" checked=false style="vertical-align:bottom" />' )

							.change( function() {
								if($.isEmptyObject(_items)){
									this.checked = false;
								} else {
								
									for ( var item in _items ) {
	
										if ( _items.hasOwnProperty(item) ) {
	
											_items[item].IsEnabled( this.checked );
										}
									}
								}
							});

						var line = $('<div class="' + _cssClass.dialog_formcell_100 + '">')

							.append( $('<div class="' + _cssClass.dialog_formcell_50 + ' ' + _cssClass.dialog_formcell_left  + '">' )

								.append( "Enabled" )
							)
							.append( $('<div class="' + _cssClass.dialog_formcell_50 + ' ' + _cssClass.dialog_formcell_right  + '">' )

								.append(_enableCheckbox)
							)
						;

						return line;
					};

					function privateBuildAlwaysActiveComboboxLine() {

						_alwaysActiveCombobox = $('<select />')
											.append( '<option value="false">RS Input</option>' )
											.append( '<option value="true">Always</option>' )
											.css("width", "100%")
											.change( function() {

												for ( var item in _items ) {

													if ( _items.hasOwnProperty(item) ) {

														//TSK3035 problema durante la selezione di un valore booleano
														var alwaysAct = _jsonUtil.getHtmlToJsonValue( this );
														_items[item].IsAlwaysActive( alwaysAct );
													}
												}
											})
						;

						var line = $('<div class="' + _cssClass.dialog_formcell_100 + '">')

							.append( $('<div class="' + _cssClass.dialog_formcell_50 + ' ' + _cssClass.dialog_formcell_left  + '">' )

								.append( "Activated by" )
							)
							.append( $('<div class="' + _cssClass.dialog_formcell_50 + ' ' + _cssClass.dialog_formcell_right  + '">' )

								.append(_alwaysActiveCombobox)
							)
						;

						return line;
					};
					
					function privateBuildTable() {
						var table = $('<table class="scr_table" />');
						if (_settings.itemSettings.enableDeleteButton && _settings.itemSettings.showIndex){
							table.append('<col width="70%">');
							table.append('<col width="15%">');
							table.append('<col width="15%">');
						}else{
							table.append('<col width="80%">');
							table.append('<col width="20%">');
						;
						}
						return table;
					};

					_htmlTable = privateBuildTable();
					
					// Append add button
					var colspan=2;
					var appendInfo = _settings.infoFunctionalityText != undefined;
					if (_settings.itemSettings.enableDeleteButton && _settings.itemSettings.showIndex){
						colspan = 3;
					}
					
					_htmlTable.append( $( '<tr>' )
						.append( $( '<td>' )
							.attr('colSpan', appendInfo ? colspan-1 : colspan)
							.append( privateBuildAddButton() )
						)
						.append( appendInfo ? $( '<td align="center">' ).append( privateBuildInfoButton() ) : "")
					);
					
					if(_settings.showExtraButtonText != undefined && _settings.callbacks.onExtraButtonPressedCallback != undefined ){
						_htmlTable.append( $( '<tr>' )
								.append( $( '<td>' )
									.attr('colSpan', colspan)
									.append( privateBuildExtraButton(_settings.showExtraButtonText) )
								)
							);
					}

					// Append enable children checkbox
					if( _settings.showEnableCheckbox ) {

						_enableCheckboxLine = privateBuildEnableCheckboxLine();

						enableCheckBoxEnable(false);
						
						_htmlTable.append( $( '<tr>' )
							.attr('colspan', colspan)
							.append( $( '<td>' )
								.append( _enableCheckboxLine )
							)
						);
					}

					// Append always active children combobox
					if( _settings.showAlwaysActiveCombobox ) {

						_alwaysActiveComboboxLine = privateBuildAlwaysActiveComboboxLine();
						$(_alwaysActiveComboboxLine).val("false");

						_htmlTable.append( $( '<tr>' )
							.attr('colspan', colspan)
							.append( $( '<td>' )
								.append( _alwaysActiveComboboxLine )
							)
						);
					}
				};

				function enableCheckBoxEnable(enable) {
					if(_enableCheckbox != undefined){
						if (enable && !$.isEmptyObject(_items)){
							//abilito la checkbox solo se la lista di elementi non è vuota
							_enableCheckbox[0].disabled = !enable;
						} else if (!enable && $.isEmptyObject(_items)){
							//disabilito la checkbox se la lista degli elementi è vuota
							_enableCheckbox[0].checked = false;
							_enableCheckbox[0].disabled = !enable;
						}
					}
				};
				
				function privateAddItem(itemObjectJSON, notifyCallback) {

					function privateBuildNewItemSettings(itemObjectJSON) {

						var itemSettings = _settings.itemSettings;							

						if ( itemObjectJSON == undefined ) {
							
							itemSettings.uId = _uIdManager.AllocFirstFreeUId();
							itemSettings.objectJSON = undefined;
						
						} else {

							_uIdManager.AllocUId( itemObjectJSON.id );

							itemSettings.uId  = itemObjectJSON.id;
							itemSettings.objectJSON = itemObjectJSON;
						}

						return itemSettings;
					};

					function privateBuildNewItem(itemSettings) {

						_items[itemSettings.uId] = new Item( itemSettings );
						_items[itemSettings.uId].setItemChangeCallback( privateHandleItemChange );
						_items[itemSettings.uId].setItemRemoveCallback( privateHandleItemRemove );

						$(_htmlTable).append( _items[itemSettings.uId].getHtmlRowElement() );
						$( _items[itemSettings.uId].getHtmlRowElement()).goTo(); // scrolla la view all'elemento aggiunto
						
					};

					if ( Object.keys( _items ).length >= _settings.maxItemsCount ) {

						_utility.MessageBox("Info", "Max items quantity already reached", true).Show();
						// alert( "Max items quantity already reached!" );

						return;
					}

					if ( _settings.availableItemSpot.value == 0 ) {

						_utility.MessageBox("Info", "Max total items quantity already reached", true).Show();
						// alert( "Max total items quantity already reached" );

						return;
					}

					var newItemSettings = privateBuildNewItemSettings(itemObjectJSON);

					if( !_items.hasOwnProperty( newItemSettings.uId ) ) {

						privateBuildNewItem( newItemSettings );
						_settings.availableItemSpot.value--;


						if(notifyCallback == undefined || notifyCallback !== false){
							if ( _settings.callbacks.onSomeItemAddedCallback != undefined ) {
	
								_settings.callbacks.onSomeItemAddedCallback( protectedGetItemListFromListId(_settings.uId), _items[newItemSettings.uId] );
							}
						}
						
						if ( _settings.showEnableCheckbox ) {

							//TSK2038 errore sulla scrittura del campo in json, veniva scritto come stringa
							var isChecked = _jsonUtil.getHtmlToJsonValue(_enableCheckbox);

							_items[newItemSettings.uId].IsEnabled( isChecked );
							
							enableCheckBoxEnable(true);
						}

						if ( _settings.showAlwaysActiveCombobox ) {

							var alwaysActive = _jsonUtil.getHtmlToJsonValue(_alwaysActiveCombobox);

							_items[newItemSettings.uId].IsAlwaysActive( alwaysActive );
						}
					}
				};

				function privateRemoveItem( uId ) {

					if( _items.hasOwnProperty( uId ) ) {
						
						_uIdManager.FreeUId( uId );
						//TSK1357: compacting items id
						//compacting IDs list
						
						//_uIdManager.CompactUId();

						_items[uId].Dispose();

						_settings.availableItemSpot.value++;

						var removedItem = _items[uId];
						
						delete _items[uId];
						
						if ( _settings.callbacks.onSomeItemRemovedCallback !== undefined ) {
							
							_settings.callbacks.onSomeItemRemovedCallback( protectedGetItemListFromListId(_settings.uId), removedItem );
						}

						//compactItems();
					
						//A.R: this part is for updating monitoring points label on the 3d scene.
						//in the future should be removed and handled in a unique manner
						if(_settings.uId === "MonitoringPoints" || _settings.uId === "WallCorners" ){ //TODO: vedere se giusto richiamare anche per corners
							if ( _settings.callbacks.onSomeItemChangedCallback !== undefined ) {
								
								_settings.callbacks.onSomeItemChangedCallback( protectedGetItemListFromListId(_settings.uId), removedItem );
							}
						}
					}
					
					enableCheckBoxEnable(false);
					
				};

				function privateHandleItemChange( uId ) {

					if ( _settings.callbacks.onSomeItemChangedCallback !== undefined ) {
				
						_settings.callbacks.onSomeItemChangedCallback( protectedGetItemListFromListId(_settings.uId), _items[uId] );
					}
				};

				function privateHandleItemRemove( uId ) {

					privateRemoveItem( uId );

				};
				
				//TSK1357: compacting items id
				function compactItems(){
					var i=0;
					for ( var item in _items ) {

						if ( _items.hasOwnProperty(item) ) {
							//compacting items list
							
							var newItm = _items[item];
							delete _items[item];								
							_items[i] = newItm;
							
							//updating items ids
							_settings.itemSettings.uId=i;
							_items[i].ChangeId(i);
						
							//updating menu rows
							_items[i].UpdateMenuRow();

							i++;
						}
					}
				}

				function privateGetItemsAsArray() {

					var itemsKeyArray = Object.keys(_items);
					var itemsArray = [];

					for ( var i=0; i < itemsKeyArray.length; i++ ) {

						itemsArray.push( _items[ itemsKeyArray[i] ] );
					}

					return itemsArray;
				};

				function privateGetItemsAsJsonArray() {

					var jsonArray = [];

					var itemsArray = privateGetItemsAsArray();

					for( var i=0; i < itemsArray.length; i++ ) {

						jsonArray.push( itemsArray[i].ToObjectJSON() );
					}

					if ( _settings.filterFunction != undefined && typeof(_settings.filterFunction) === 'function') {

						jsonArray = _settings.filterFunction( jsonArray );
					}

					return jsonArray;
				};

				function privateToObjectJSON() {
					
					var jsonObject = {};
					jsonObject[_settings.uId] = privateGetItemsAsJsonArray();

					return jsonObject;
				};

				function privateFromArrayJSON(arrayJSON) {

					if ( arrayJSON.length > 0 ) {

						if ( _settings.showEnableCheckbox && arrayJSON[0].hasOwnProperty('flags') && arrayJSON[0].flags.hasOwnProperty('enabled') ) {

							$(_enableCheckbox).prop('checked', arrayJSON[0].flags.enabled );
						}

						if ( _settings.showAlwaysActiveCombobox  && arrayJSON[0].hasOwnProperty('flags') && arrayJSON[0].flags.hasOwnProperty('alwaysActive')) {

							$(_alwaysActiveCombobox).val( arrayJSON[0].flags.alwaysActive.toString() );
						}

						for (var i=0; i < arrayJSON.length; i++ ) {

							privateAddItem( arrayJSON[i] );
						}
					}
				};
				
				//ricostruisce la lista di item a partire da un JSON Array sostituendo tutti gli elementi precedenti
				function privUpdateFromArrayJSON(arrayJSON) {
					
					if ( arrayJSON.length > 0 ) {

						if ( _settings.showEnableCheckbox && arrayJSON[0].hasOwnProperty('flags') && arrayJSON[0].flags.hasOwnProperty('enabled') ) {

							$(_enableCheckbox).prop('checked', arrayJSON[0].flags.enabled );
						}

						if ( _settings.showAlwaysActiveCombobox  && arrayJSON[0].hasOwnProperty('flags') && arrayJSON[0].flags.hasOwnProperty('alwaysActive')) {

							$(_alwaysActiveCombobox).val( arrayJSON[0].flags.alwaysActive.toString() );
						}

						//flushing uids
						_uIdManager.FreeAllUid();
						//remove all elements
						for ( var item in _items ) {

							if ( _items.hasOwnProperty(item) ) {
		
								_items[item].DisposeNoAnimation();
		
								_settings.availableItemSpot.value++;
								
								delete _items[item];
							}
						}
						
						for (var i=0; i < arrayJSON.length; i++ ) {
							var notifyCallback = false;
							//add new object to the internal list
							privateAddItem( arrayJSON[i], notifyCallback);
						}
						
						//fa lampeggiare gli elementi aggiunti per rendere evidente la modifica
						for ( var item in _items ) {
							_items[item].FlashAnimation();
						}
					}
				};
				
				privateInitialize();

				return {

					getHtml: function() { return _htmlTable; },
					getColor: function() { return _settings.color; },

					getItemsAsJsonArray: privateGetItemsAsJsonArray,
					ToObjectJSON: privateToObjectJSON,
					FromArrayJSON: privateFromArrayJSON,
					UpdateFromArrayJSON: privUpdateFromArrayJSON,

					// Events setters
					setSomeItemAddedCallback:   function ( callback ) { _callbacks.onSomeItemAddedCallback   = callback; },
					setSomeItemChangedCallback: function ( callback ) { _callbacks.onSomeItemChangedCallback = callback; },
					setSomeItemRemovedCallback: function ( callback ) { _callbacks.onSomeItemRemovedCallback = callback; }
				};
			};

			var _settings = settings;
			var _itemLists = {};
			var _flagsObjects = {};
			var _htmlElementsArray = [];
			
			//TSK1357: check number of elements of subcategories
			var privateCheckMinMaxNumber = function() {
				for(var n = 0; n < _settings.itemLists.length; n++){
					var itemLength= _itemLists[_settings.itemLists[n].uId].getItemsAsJsonArray().length;
					if(itemLength > 0){
						if(_settings.itemLists[n].minItemsCount != undefined && _settings.itemLists[n].maxItemsCount != undefined){
							if(itemLength < _settings.itemLists[n].minItemsCount || itemLength > _settings.itemLists[n].maxItemsCount ){								
								return false;
							}
						}
					}
				}
				
				return true;
			};
			
			var privateUpdateTotalIndex = function() {
				
				var count = 0;
				if(_settings.indexPadding != undefined){
					count = count+_settings.indexPadding; 
				}
				$(".scr_tot_index").remove();
				
				for(var n = 0; n< _settings.itemLists.length; n++){
//					_htmlElementsArray[ _itemLists[_settings.itemLists[i].uId].getHtml() ];
					ItemList.Item.itemId;
					var html= $( _itemLists[_settings.itemLists[n].uId].getHtml());
					var childrens = html.find(".scr_rowbutton");
					for ( var v = 0; v < childrens.length ; v++){
						count++;
						$(childrens[v]).before('<div class="scr_tot_index" >'+count+'</div>');
						//style="width:10%; margin:4px 0px; text-align: center; border-radius: 10px; background: #f9b110; float:left;"
						$(childrens[v]).css("width", "90%");
						$(childrens[v]).css("float", "right");
							
					}
				}
			};
			
			var protectedGetItemListFromListId = function(uId) {

				if(_itemLists.hasOwnProperty(uId)) {
					return _itemLists[uId];
				}
			};

			function privateInitialize() {

				function privateBuildItemLists() {

					for ( var i = 0; i < _settings.itemLists.length; i++ ) {

						if ( !_itemLists.hasOwnProperty( _settings.itemLists[i].uId ) ) {

							_settings.itemLists[i].availableItemSpot = _settings.maxTotalItems;

							_itemLists[_settings.itemLists[i].uId] = new ItemList( _settings.itemLists[i] );

							_htmlElementsArray.push( _itemLists[_settings.itemLists[i].uId].getHtml() );
						}
					}
				};

				function privateBuildFlagsTables() {

					for ( var i = 0; i < _settings.flagsObjects.length; i++ ) {

						if ( !_flagsObjects.hasOwnProperty( _settings.flagsObjects[i].uId ) ) {

							_flagsObjects[_settings.flagsObjects[i].uId] = _settings.flagsObjects[i];

							_htmlElementsArray.push( _flagsObjects[_settings.flagsObjects[i].uId].getHtml() );
						}
					}
				};

				privateBuildFlagsTables();
				privateBuildItemLists();
			};

			function privateToObjectJSON() {

				var jsonObject = {};

				var lists = Object.keys(_itemLists);

				for(var i=0; i < lists.length; i++ ) {

					jsonObject[lists[i]] = _itemLists[lists[i]].getItemsAsJsonArray();
				}

				var flags = Object.keys(_flagsObjects);

				for(var i=0; i < flags.length; i++ ) {

					jsonObject[flags[i]] = _flagsObjects[flags[i]].DataToObjectJSON();
				}

				return jsonObject;
			};

			function privateFromObjectJSON(objectJSON) {

				for ( var prop in objectJSON ) {

					if ( objectJSON.hasOwnProperty(prop) ) {

						if ( _itemLists.hasOwnProperty(prop) ) {

							_itemLists[prop].FromArrayJSON( objectJSON[prop] );
						}

						if ( _flagsObjects.hasOwnProperty(prop) ) {

							_flagsObjects[prop].ObjectJSONToData( objectJSON[prop] );
						}
					}
				}
			};

			privateInitialize();

			return {

				getHtml: function() { return _htmlElementsArray; },
				updateTotalIndex: privateUpdateTotalIndex,
				ToObjectJSON: privateToObjectJSON,
				FromObjectJSON: privateFromObjectJSON,
				CheckMinMaxNumber: privateCheckMinMaxNumber
			};
		};

		var _volumesManager = new ItemListsManager( _settings.volumesManagerSettings );
		var _speedManager = new ItemListsManager( _settings.speedManagerSettings );
		var _systemManager = new ItemListsManager( _settings.systemManagerSettings );
		var _jointManager = new ItemListsManager( _settings.jointManagerSettings );
		var _cellManager = new ItemListsManager( _settings.cellManagerSettings );
		var _toolManager = new ItemListsManager( _settings.toolManagerSettings );
		var _functionalSpaceAManager = new ItemListsManager( _settings.functionalSpaceAManagerSettings );
		var _functionalSpaceBManager = new ItemListsManager( _settings.functionalSpaceBManagerSettings );
		var _brakeManager = new ItemListsManager( _settings.brakeManagerSettings );
		var _safeioManager = new ItemListsManager( _settings.safeioManagerSettings );
		var _OCSManager = new ItemListsManager( _settings.OCSManagerSettings );
		
		function privateToObjectJSON() {

			var jsonObject = {};
			var managersArray = [ _volumesManager, _speedManager, _systemManager, _jointManager, _cellManager, _toolManager, _functionalSpaceAManager, _functionalSpaceBManager, _brakeManager, _safeioManager, _OCSManager ];

			for ( var i=0; i < managersArray.length; i++ ) {

				var tmpObj = managersArray[i].ToObjectJSON();

				for (var attrname in tmpObj) {

					if(tmpObj.hasOwnProperty(attrname)) {

						jsonObject[attrname] = tmpObj[attrname];
					}
				}
			}

			return jsonObject;
		};

		function privateFromObjectJSON(objectJSON) {
			
			_volumesManager.FromObjectJSON( objectJSON );
			_speedManager.FromObjectJSON( objectJSON );
			_systemManager.FromObjectJSON( objectJSON );
			_jointManager.FromObjectJSON( objectJSON );
			_cellManager.FromObjectJSON( objectJSON );
			_toolManager.FromObjectJSON( objectJSON );
			_functionalSpaceAManager.FromObjectJSON( objectJSON );
			_functionalSpaceBManager.FromObjectJSON( objectJSON );
			_brakeManager.FromObjectJSON( objectJSON );
			_safeioManager.FromObjectJSON( objectJSON );
			_OCSManager.FromObjectJSON( objectJSON );

			_navigator.setSomethingToSave(false);
		};

		return {
			volumesManager: _volumesManager,
			speedManager: _speedManager,
			systemManager: _systemManager,
			jointManager: _jointManager,
			cellManager: _cellManager,
			toolManager: _toolManager,
			functionalSpaceAManager: _functionalSpaceAManager,
			functionalSpaceBManager: _functionalSpaceBManager,
			brakeManager: _brakeManager,
			safeioManager: _safeioManager,
			OCSManager: _OCSManager,
			ToObjectJSON: privateToObjectJSON,
			FromObjectJSON: privateFromObjectJSON
		};
	}();

	var hasSafeAxis =  (_robot.HasSafeAxis()); //Se ARM_SAFE_MASK almeno un bit su, abilitare Configuration/ JOINTS, SPEED, TOOL, BRAKE.
	var isKeyenSafe =  (_robot.IsSystemSafeKeyen() && hasSafeAxis); //Se keyen robosafe Cartesian, abilitare tutto il resto (Configuration/ CELL, DYNAMIC AREA, FUNCTIONAL AREA 1-2)
	
	//VLMU TODO
	var threedview_container = $('<div class="' + _cssClass.threedview_container + '" >').append( $('<div class="' + _cssClass.threedview_loadingtext + '"><p>Loading...</p></div>') );

	$(threedview_container).empty();

	var editor = undefined;

	var _navigator = new Navigator(threedview_container);
	
	
	if (!readonly) {
		
		_navigator.addPage("System", _managers.systemManager.getHtml(),threedview_container , true , '../images/environments/system.png');
		_navigator.addPage("Joint spaces", _managers.jointManager.getHtml(),threedview_container , hasSafeAxis , '../images/environments/joint_spaces.png' );
		_navigator.addPage("Cell", _managers.cellManager.getHtml(),threedview_container , isKeyenSafe , '../images/environments/cell.png');
		_navigator.addPage("Dynamic Volumes", _managers.volumesManager.getHtml(),threedview_container , isKeyenSafe, '../images/environments/dynamic_volumes.png');
		_navigator.addPage("Functional Spaces A", _managers.functionalSpaceAManager.getHtml(),threedview_container , isKeyenSafe ,'../images/environments/functional_spaces_a.png');
		_navigator.addPage("Functional Spaces B", _managers.functionalSpaceBManager.getHtml(),threedview_container , isKeyenSafe , '../images/environments/functional_spaces_b.png');
		_navigator.addPage("Speed", _managers.speedManager.getHtml(),threedview_container , hasSafeAxis , '../images/environments/speed.png');
		_navigator.addPage("Monitoring Points", _managers.toolManager.getHtml(), threedview_container , hasSafeAxis , '../images/environments/monitoring_points.png');
		_navigator.addPage("Brake", _managers.brakeManager.getHtml(),threedview_container , hasSafeAxis , '../images/environments/brake.png');
		_navigator.addPage("Safe Outputs", _managers.safeioManager.getHtml(),threedview_container, hasSafeAxis , '../images/environments/safe_outputs.png');
		_navigator.addPage("Tool Orientation", _managers.OCSManager.getHtml(),threedview_container , isKeyenSafe , '../images/environments/tool_orientation.png');
		_navigator.addSpace();
		
		
		
		_navigator.addCustomButton( "Import/Export", function() {
			
				_robot.UpdateStatus();
				_popupUtility.UploadFileBox().Show();
				
			} , hasSafeAxis, '../images/environments/import_export.png' );	
		
		
        
		_navigator.addSaveButton( "Save", function() {
        
			_robot.UpdateStatus();
			
			if (isSaveInProgress(true)){
			  return;
			}
        
			var message = 'Are you sure you want to save this configuration?';
			//TSK2076 warning if SL is in Recovery mode
			if(!isSafeOperational() || isRecovery()){
				message += '<p style="color:red;">Attention!</br>The robot is in RECOVERY mode,</br>'+
					'the safety features will be actually enabled only in NORMAL mode.</p>';
			}
			
			_utility.ConfirmBox('Save', message, function() {
				if (_robot.CanDownload())
				{
					//TSK1357: check number of elements of subcategories
					if(_configurationManager.CheckCrcAndDynamicCoherence() && _configurationManager.CanSaveConfig()){
						var msg = _utility.MessageBox("Info", "Parameters download in progress...", false);
						msg.Show();
		
						_configurationManager.Save();
		
						setTimeout(function() {
							
							$.ajax({		
								type: "POST",
								url: 'run?cartesian_run',						
		
								success: function(data) {
									msg.Hide();
									_robot.WaitReboot();
								}
							});
		
						}, 500);
					}
				}
			}).Show();
		}, '../images/environments/save.png' );
	}

	$('#' + containerId).append( _navigator.layout );

	
	$(window).on('beforeunload', function(){
		//check if "comau.js" is not trying to redirect
		if(_navigator.getSomethingToSave() && !isTimeoutRedirecting()) {

			return 'You have pending unsaved changes. Leaving, reloading or closing this page you will loose all unsaved changes.';

		} else {

			return undefined;
		}
	});

	var startProcedure = function() {
		_robot.WaitJson(); //show the popup of "waiting data loading"

		_configurationManager.Load(function() {
			//this function is passed as callback of the load() function. 
			//it's called when the cartesian.json file is loaded
			if(_configurationManager.IsDataLoaded()){
				
				var data =_configurationManager.GetLoadedData();
				
				_robot.CheckData(data);

				_managers.FromObjectJSON(data); 

				_robot.NotifyTooManyActiveOBD();
				
				if (editor != undefined) 
					editor.onWindowResize();
			}else{
				console.log("data not correctly loaded");
				_utility.MessageBox("Info", "Data not loaded, please reload the page", false).show();
			}
		});

	};


	//VlMu_threeDView.setReadyToStartCallback( startProcedure );

	if(!_robot.IsTPConnected()){
		// caricare l'ambiente 3D solo se l'applicazione è visuializzata da PC
		editor = new Editor(threedview_container[0]);
		editor.loadRobotModel("../../view/models");
	}

	startProcedure();	
};
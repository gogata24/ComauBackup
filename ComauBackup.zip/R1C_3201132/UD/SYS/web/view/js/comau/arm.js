var ArmModel = function (modelFolder, armIndex, scene) {
    this.modelFolder = modelFolder;
    this.armIndex = armIndex;

    this.links = new Array();
    this.frames = new Array();
    this.origins = new Array();

    this.joints = [0,0,0,0,0,0];
    
    this.flagenode = null;
    this.scene = scene;

    this.id = null;

    this.baseFrame = null;
    this.armFrame = null;
    this.userFrame = null;
    this.toolFrame = null;
    this.elbowFrame = null;
    this.flangeFrame = null;

    this.hasRail = false;

    this.arm_jntp = null
    this.ax_len = null
    this.ax_ofst = null
    this.arm_base = null
    this.strk_end_sys_n = null
    this.strk_end_sys_p = null
    this.fl_ax_cnfg = null
    this.a_along_2d = null
    this.rb_variant = null

    this.updateFast = new Date();
    this.updateSlow = new Date();

    this.debug = false;
}

ArmModel.prototype = {
    constructor: ArmModel,

    loadFile: function (tran, node, filename) {

        var loader = new THREE.ColladaLoader();

        loader.load(filename + '.dae', function (model) {
            //console.log(model);	
			var dae = model.scene;
			
			node.add( dae );
			dae.matrixAutoUpdate = false;    
            dae.matrix.copy(tran);		
        });

    },
    // sync
    initContent: function() {
		
		var armdata = this.getArmData();
		this.initContentByName(armdata);

        //var codid = this.getModelId();
        //var idxcod = codid.indexOf('_');
        //var codmod = codid.substr(0, idxcod) + "_00" + codid.substr(idxcod + 3, idxcod + 6);       
        //this.initContentByName(codmod);

        this.updateFlAxCnfg(); // Name
        this.updateAaLong2d(); // Linear Axis
        this.updateRbVariant() // Integrated Rail

        var idxfl = this.fl_ax_cnfg[6].indexOf('_');
        var cnfstr = this.fl_ax_cnfg[6].substr(0, idxfl)

        if ((cnfstr == "RAIL") && (this.a_along_2d[1][6] == 1) && (this.rb_variant & 0x00100000)) {
            this.hasRail = true;

            this.updateAxLen();
            this.updateAxOfst();
            this.updateStrkEndSysN();
            this.updateStrkEndSysP();

            this.initRail()
        }
    },
    
    initRail: function() {

        var railThickness = 0.05
        var pedestalRadius = 0.5
        var railLength = Math.abs(this.strk_end_sys_p[6] - this.strk_end_sys_n[6])/1000.0 + 1.0

        if (railLength > 1.0) {

            var railGeometry = new THREE.BoxGeometry(railLength , 1.0, railThickness);
            //var railMaterial = new THREE.MeshBasicMaterial( { color: 0xff0000, transparent: true, opacity: 0.4 } );
            var railMaterial = new THREE.MeshPhongMaterial({
                color: 0x7a7a7a,
                flatShading: true,
                transparent: true,
                opacity: 0.7 
            });
            var railMesh = new THREE.Mesh( railGeometry, railMaterial );

            var railMat = new THREE.Matrix4();          
            railMat.setPosition(new THREE.Vector3(this.strk_end_sys_n[6]/1000.0 + railLength/2.0 - pedestalRadius, 0, -railThickness/2));
            railMesh.matrixAutoUpdate = false;
            railMesh.matrix.copy(railMat);
        
            this.baseFrame.getNode().add(railMesh)
        }

        if (this.ax_len[6] > 0.0) {
            var pedestalGeometry = new THREE.CylinderGeometry(pedestalRadius, pedestalRadius, this.ax_len[6]/1000.0, 32);
            //var pedestalMaterial = new THREE.MeshBasicMaterial( { color: 0xff0000, transparent: false, opacity: 0.4 } );
            var pedestalMaterial = new THREE.MeshPhongMaterial({
                color: 0x7a7a7a,
                flatShading: true,
                transparent: true,
                opacity: 0.7 
            });
            var pedestalMesh = new THREE.Mesh( pedestalGeometry, pedestalMaterial );

            var pedestalMat = new THREE.Matrix4();
            pedestalMat.makeRotationAxis(new THREE.Vector3(1, 0, 0),  Math.PI / 2.0);      
            pedestalMat.setPosition(new THREE.Vector3(0, 0, -this.ax_len[6]/2000.0));
            pedestalMesh.matrixAutoUpdate = false;
            pedestalMesh.matrix.copy(pedestalMat);

            this.armFrame.getNode().add(pedestalMesh)
            }
    },

    initContentByName: function(armdata) {    

        this.id = armdata;

        if (this.id == undefined)
            return;

        if (this.id.type == "Antropomorfo")
        {      
            this.frames.push( new THREE.Matrix4() );
            for (var i = 0; i < 7; i++)
            {
                this.frames.push( this.dh( this.id.dh_a[i],  this.id.dh_alpha[i],  this.id.dh_d[i],  this.id.dh_theta[i]) );

                var link = new THREE.Group();
                link.name = 'Link' + i;
                
                if (this.debug) {
                    var axisHelper = new THREE.AxesHelper( 0.2 );
                    axisHelper.name = "Axis";
                    link.add(axisHelper);  
                }

                link.matrixAutoUpdate = false;

                this.links.push(link);
            }

            this.links[0].add(this.links[1]);
            this.links[1].add(this.links[2]);
            this.links[2].add(this.links[3]);
            this.links[3].add(this.links[4]);
            this.links[4].add(this.links[5]);
            this.links[5].add(this.links[6]);

            for (var i = 0; i < 6; i++) {
                this.setJoint(this.id.cal_sys[i], i );
            }

            for (var i = 0; i < 7; i++) {
                this.origins[i] = new THREE.Matrix4(); 
            } 

            var invM = new Array();
            for (var i = 0; i < 7; i++) {
                invM.push( new THREE.Matrix4().getInverse(this.links[i].matrix, false) ); 
            }
   
            this.origins[0].copy( invM[0]);
            this.origins[1].copy( invM[0].clone().premultiply(invM[1]));
            this.origins[2].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2]));
            this.origins[3].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2].clone()).premultiply(invM[3]));
            this.origins[4].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2].clone()).premultiply(invM[3].clone()).premultiply(invM[4]));
            this.origins[5].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2].clone()).premultiply(invM[3].clone()).premultiply(invM[4].clone()).premultiply(invM[5].clone()));
            this.origins[6].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2].clone()).premultiply(invM[3].clone()).premultiply(invM[4].clone()).premultiply(invM[5].clone()).premultiply(invM[6]));

            for (var i = 0; i < 7; i++) {
                this.loadFile(this.origins[i], this.links[i], this.modelFolder + '/' + this.armIndex + '/l' + i);
            }    
            
            //this.toolFrame = new Frame("/ArmVars/" + this.armIndex + "/$TOOL", this.links[6], size.z/5);
            
            // B&D elbow frame
            var axisX = new THREE.Matrix4();
            axisX.makeRotationAxis(new THREE.Vector3(1, 0, 0), Math.PI/2);

            var axisZ = new THREE.Matrix4();
            axisZ.makeRotationAxis(new THREE.Vector3(0, 0, 1), Math.PI/2);

            var rot = axisZ.premultiply(axisX);

            var tr = new THREE.Vector3();
            tr.setFromMatrixPosition( invM[3] );           

            var height = new THREE.Vector3();
            height.setFromMatrixPosition( this.links[2].matrix );
            var scale =  Math.max(Math.abs(height.x), Math.abs(height.y), Math.abs(height.z));

            this.elbowFrame = new Frame("Elbow", this.links[3], scale/2);

            var elbowNode = this.elbowFrame.getNode();
            elbowNode.matrix.copy(rot);
            elbowNode.matrix.setPosition(tr);


            this.flageFrame = new Frame("Flange", this.links[6], scale/2); 
        }
        else if (this.id.type == "Parallelogramma")
        {
            this.frames.push( new THREE.Matrix4() );
            for (var i = 0; i < 9; i++) {
                this.frames.push( this.dh( this.id.dh_a[i],  this.id.dh_alpha[i],  this.id.dh_d[i],  this.id.dh_theta[i]) );

                var link = new THREE.Group();
                link.name = 'Link' + i;

                if (this.debug) {
                    var axisHelper = new THREE.AxesHelper( 0.2 );
                    axisHelper.name = "Axis";
                    link.add(axisHelper);  
                }

                link.matrixAutoUpdate = false;

                this.links.push(link);
            }

            this.links[0].add(this.links[1]);

            this.links[1].add(this.links[2]);
            this.links[1].add(this.links[3]);

            this.links[3].add(this.links[7]);
            this.links[7].add(this.links[8]);
            this.links[8].add(this.links[4]);
            this.links[4].add(this.links[5]);
            this.links[5].add(this.links[6]);

            for (var i = 0; i < 6; i++) {
                this.setJoint(this.id.cal_sys[i], i );
            }

            var invM = new Array();
            for (var i = 0; i < 9; i++) {
                invM.push( new THREE.Matrix4().getInverse(this.links[i].matrix, false) ); 
                this.origins[i] = new THREE.Matrix4();     
            }
            
            this.origins[0].copy( invM[0]);
            this.origins[1].copy( invM[0].clone().premultiply(invM[1]));
            this.origins[2].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2]));
            this.origins[3].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3]));
            this.origins[7].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[7]));
            this.origins[8].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[7].clone()).premultiply(invM[8]));
            this.origins[4].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[7].clone()).premultiply(invM[8]).premultiply(invM[4]));
            this.origins[5].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[7].clone()).premultiply(invM[8]).premultiply(invM[4]).premultiply(invM[5]));
            this.origins[6].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[7].clone()).premultiply(invM[8]).premultiply(invM[4]).premultiply(invM[5]).premultiply(invM[6]));

            for (var i = 0; i < 9; i++)
            {
                this.loadFile(this.origins[i], this.links[i], this.modelFolder + '/' + this.armIndex +  '/l' + i);
            }

            //this.toolFrame = new Frame("/ArmVars/" + this.armIndex + "/$TOOL", this.links[6], size.z/5); 

            // B&D elbow frame
            var axisX = new THREE.Matrix4();
            axisX.makeRotationAxis(new THREE.Vector3(1, 0, 0), Math.PI/2);

            var axisZ = new THREE.Matrix4();
            axisZ.makeRotationAxis(new THREE.Vector3(0, 0, 1), Math.PI/2);

            var rot = axisZ.premultiply(axisX);

            var tr = new THREE.Vector3();
            var mat = invM[8].clone().multiply(invM[7].clone()).multiply(invM[3].clone()).multiply(this.links[2].matrix.clone());
            tr.setFromMatrixPosition( mat );  

            var height = new THREE.Vector3();
            height.setFromMatrixPosition( this.links[2].matrix );
            var scale =  Math.max(Math.abs(height.x), Math.abs(height.y), Math.abs(height.z));
            
            this.elbowFrame = new Frame("Elbow", this.links[8], scale/2);

            var elbowNode = this.elbowFrame.getNode();
            elbowNode.matrix.copy(rot);
            elbowNode.matrix.setPosition(tr);

            this.flageFrame = new Frame("Flange", this.links[6], scale/2);
        }
        else if (this.id.type == "DoppioParallelogramma") {
            this.frames.push( new THREE.Matrix4() );
            for (var i = 0; i < 12; i++) {
                this.frames.push( this.dh( this.id.dh_a[i],  this.id.dh_alpha[i],  this.id.dh_d[i],  this.id.dh_theta[i]) );

                var link = new THREE.Group();
                link.name = 'Link' + i;

                if (this.debug) {
                    var axisHelper = new THREE.AxesHelper( 0.2 );
                    axisHelper.name = "Axis";
                    link.add(axisHelper);  
                }

                link.matrixAutoUpdate = false;

                this.links.push(link);
            }

            this.links[0].add(this.links[1]);

            this.links[1].add(this.links[2]);
            this.links[1].add(this.links[3]);
            this.links[1].add(this.links[8]);

            this.links[3].add(this.links[5]);
            this.links[5].add(this.links[6]);
            this.links[6].add(this.links[7]);
            this.links[7].add(this.links[4]);

            this.links[8].add(this.links[9]);
            this.links[9].add(this.links[10]);
            this.links[10].add(this.links[11]);

            for (var i = 0; i < 6; i++) {
                this.setJoint(this.id.cal_sys[i], i );
            }

            var invM = new Array();
            for (var i = 0; i < 12; i++) {
                invM.push( new THREE.Matrix4().getInverse(this.links[i].matrix, false) ); 
                this.origins[i] = new THREE.Matrix4();     
            }
            
            this.origins[0].copy( invM[0]);
            this.origins[1].copy( invM[0].clone().premultiply(invM[1]));
            this.origins[2].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[2]));
            this.origins[3].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3]));

            this.origins[5].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[5]));
            this.origins[6].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[5].clone()).premultiply(invM[6]));
            this.origins[7].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[5].clone()).premultiply(invM[6].clone()).premultiply(invM[7]));
            this.origins[4].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[3].clone()).premultiply(invM[5].clone()).premultiply(invM[6].clone()).premultiply(invM[7].clone()).premultiply(invM[4]));
           
            this.origins[8].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[8]));
            this.origins[9].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[8].clone()).premultiply(invM[9]));
            this.origins[10].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[8].clone()).premultiply(invM[9].clone()).premultiply(invM[10]));
            this.origins[11].copy( invM[0].clone().premultiply(invM[1].clone()).premultiply(invM[8].clone()).premultiply(invM[9].clone()).premultiply(invM[10].clone()).premultiply(invM[11]));
            
            for (var i = 0; i < 12; i++)
            {
                this.loadFile(this.origins[i], this.links[i], this.modelFolder + '/' + this.armIndex + '/l' + i);
            }

            //this.toolFrame = new Frame("/ArmVars/" + this.armIndex + "/$TOOL", this.links[7], size.z/5); 

            // B&D elbow frame
            var axisY = new THREE.Matrix4();
            axisY.makeRotationAxis(new THREE.Vector3(0, 1, 0), Math.PI);

            var axisZ = new THREE.Matrix4();
            axisZ.makeRotationAxis(new THREE.Vector3(0, 0, 1), Math.PI);

            var rot = axisZ.premultiply(axisY);

            var tr = new THREE.Vector3();
            var mat = (invM[10].clone()).multiply(invM[9].clone()).multiply(invM[8].clone()).multiply(this.links[2].matrix.clone());
            tr.setFromMatrixPosition( mat );  

            var height = new THREE.Vector3();
            height.setFromMatrixPosition( this.links[2].matrix );
            var scale =  Math.max(Math.abs(height.x), Math.abs(height.y), Math.abs(height.z));

            this.elbowFrame = new Frame("Elbow", this.links[10], scale/2);

            var elbowNode = this.elbowFrame.getNode();
            elbowNode.matrix.copy(rot);
            elbowNode.matrix.setPosition(tr);

            this.flageFrame = new Frame("Flange", this.links[4], scale/2);
        }
 
        this.links[0].matrixAutoUpdate = true;

        this.baseFrame = new Frame("Base", this.scene, 0.5);
        this.armFrame = new Frame("Arm", this.baseFrame.getNode(), 0.5);
        this.armFrame.getNode().add(this.links[0])
    },

    getBaseFrame: function() {
        return this.baseFrame;
    },

    getElbowFrame: function() {
        return this.elbowFrame;
    },

    getFlangeFrame: function() {
        return this.flageFrame;
    },

    getIrtpLinkR(index) {
        if (this.id.type == "Parallelogramma")
        {
            if (index == 3)
                return this.links[8];
        }
        else if (this.id.type == "DoppioParallelogramma")
        {
            if (index == 6)
                return this.links[4];
            else if (index == 5)
                return this.links[6];
            else if (index == 4)
                return undefined;
            else if (index == 3)
                return undefined;
        }

        return this.links[index];
    },

    getIrtpBackwardPntExt(index) {
        var tr = new THREE.Vector3();

        if (this.id.type == "Parallelogramma")
        {
            if (index == 3) {

                var inv8 = new THREE.Matrix4().getInverse(this.links[8].matrix, false);
                var inv7 = new THREE.Matrix4().getInverse(this.links[7].matrix, false) 
                var inv3 = new THREE.Matrix4().getInverse(this.links[3].matrix, false) 

                var mat = inv8.multiply(inv7).multiply(inv3).multiply(this.links[2].matrix.clone());
       
                tr.setFromMatrixPosition( mat );  

                return tr;
            }  
        }
        else if (this.id.type == "DoppioParallelogramma") {
            ;//TODO
        }
     
        var inv = new THREE.Matrix4().getInverse(this.links[index].matrix, false);
        tr.setFromMatrixPosition( inv ); 
      
        return tr;
    },
	
    getArmData: function() {     

        var req  = new XMLHttpRequest();

		req.overrideMimeType("application/json");
		req.open('GET', this.modelFolder + '/' + this.armIndex + '/data.json', false);    
        req.send();
                   
        if (req.status == "200") {	
			return JSON.parse(req.responseText);
        }        	
    },
	
    getModelId: function() {     

        var req  = new XMLHttpRequest();

        //FL_CNFG
        req.open("GET", "/get?sysvar=$FL_CNFG", false);		         
        req.send();
                   
        if (req.status == "200") {
			
			var plus = req.responseText.indexOf('+');

			if (plus != -1) {
				codid = req.responseText.substr(0, plus);
            }
            else
                codid = req.responseText
		
            return codid;
        }        	
    },

    updateArmPose: function() {
        var scope = this;

        if (scope.ax_len == null)
            return;

        if (scope.ax_ofst == null)
            return;
            
        if (scope.arm_jntp == null)
            return;
            
        // ArmPose == BasePose if hasRail == false
        if (this.hasRail) {
            var mat = new THREE.Matrix4(); 
        
            mat.makeRotationAxis(new THREE.Vector3(0, 0, 1), scope.ax_ofst[6] * Math.PI / 180);
                
            mat.setPosition(new THREE.Vector3(scope.arm_jntp[6][1]/1000.0, 0, scope.ax_len[6]/1000));
            
            scope.armFrame.getNode().matrixAutoUpdate = false;
            scope.armFrame.getNode().matrix.copy(mat);
        }
    },

    updateBasePose: function() {

        var scope = this;

        if (scope.arm_base == null)
            return;
        
        var mat = new THREE.Matrix4(); 
                
        var axisZ1 = new THREE.Matrix4();
        axisZ1.makeRotationAxis(new THREE.Vector3(0, 0, 1), scope.arm_base.w * Math.PI / 180);

        var axisY = new THREE.Matrix4();
        axisY.makeRotationAxis(new THREE.Vector3(0, 1, 0), scope.arm_base.p  * Math.PI / 180);

        var axisZ2 = new THREE.Matrix4();
        axisZ2.makeRotationAxis(new THREE.Vector3(0, 0, 1), scope.arm_base.r * Math.PI / 180);

        var mat = axisZ1.multiply(axisY).multiply(axisZ2);
                      

         mat.setPosition(new THREE.Vector3(scope.arm_base.x/1000, 
                        scope.arm_base.y/1000,
                        scope.arm_base.z/1000));


         scope.baseFrame.getNode().matrixAutoUpdate = false;
         scope.baseFrame.getNode().matrix.copy(mat);
    },

    updateJoints: function() {
        var scope = this;

        if (scope.arm_jntp == null)
            return;

        scope.setJoint(scope.arm_jntp[0][1], 0);
        scope.setJoint(scope.arm_jntp[1][1], 1);
        scope.setJoint(scope.arm_jntp[2][1], 2);
        scope.setJoint(scope.arm_jntp[3][1], 3);
        scope.setJoint(scope.arm_jntp[4][1], 4);
        scope.setJoint(scope.arm_jntp[5][1], 5);
    },
    // System variable sync
    updateRbVariant: function() {
        var scope = this;
    
        var req  = new XMLHttpRequest();
    
        req.open('GET', "/get?sysvar=$rb_variant", false);		         
        req.send();
    
        if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.rb_variant = json;
        }
    },

    // System variable sync
    updateAaLong2d: function() {
        var scope = this;
    
        var req  = new XMLHttpRequest();
    
        req.open('GET', "/get?sysvar=$a_along_2d", false);		         
        req.send();
    
        if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.a_along_2d = json.A_ALONG_2D;
        }
    },

    // System variable sync
    updateFlAxCnfg: function() {
        var scope = this;
    
        var req  = new XMLHttpRequest();
    
        req.open('GET', "/get?sysvar=$fl_ax_cnfg", false);		         
        req.send();
    
        if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.fl_ax_cnfg = json.FL_AX_CNFG;
        }
    },

    // System variable sync
    updateStrkEndSysP: function() {
        var scope = this;

        var req  = new XMLHttpRequest();

        req.open('GET', "/get?sysvar=$strk_end_sys_p", false);		         
        req.send();

        if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.strk_end_sys_p = json.STRK_END_SYS_P;
		}
    },

    // System variable sync
    updateStrkEndSysN: function() {
        var scope = this;

        var req  = new XMLHttpRequest();

        req.open('GET', "/get?sysvar=$strk_end_sys_n", false);		         
        req.send();

        if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.strk_end_sys_n = json.STRK_END_SYS_N;
		}
    },

    // System variable
    updateArmJntp: function() {
        var scope = this;

        //get?arm_jntp&index=1
        var req  = new XMLHttpRequest();

        req.open('GET', "/get?arm_jntp&index=" + scope.armIndex, true);		         
        
        req.onload = function () {
			var json = JSON.parse(req.responseText);
			
			if (req.status == "200") {

                scope.arm_jntp = json;
			}
		}

        req.send();
    },
    // System variable
    updateAxLen: function() {
        if (this.id == undefined)
            return;
        
        var scope = this;

        var req  = new XMLHttpRequest();

        req.open("GET", "/get?sysvar=$ax_len", false); 
        req.send();  
        		
		if (req.status == "200") {
            var json = JSON.parse(req.responseText);
            scope.ax_len = json.AX_LEN;
		}
    },
    // System variable
    updateAxOfst: function() {
        if (this.id == undefined)
            return;
        
        var scope = this;

        var req  = new XMLHttpRequest();

        req.open("GET", "/get?sysvar=$ax_ofst", false);    
        req.send();	
        	
		if (req.status == "200") { 
            var json = JSON.parse(req.responseText);
            scope.ax_ofst = json.AX_OFST;

		}
 
    },
    // System variable
    updateArmBase: function() {

        if (this.id == undefined)
            return;
        
        var scope = this;

        var req  = new XMLHttpRequest();

        req.open("GET", "get?arm_base", true);		  // Web API issue missing expression for multimple arms       
        
        req.onload = function () {
            var json = JSON.parse(req.responseText);
            			
			if (req.status == "200") {
                scope.arm_base = json
			}
		}

        req.send();
    },

    setJoint(jointDeg, index) {
		
        if (this.id == undefined)
            return;

        if (index >= 6)
            return;

        if (this.id.type == "DoppioParallelogramma"){
            if ((index == 3) || (index == 4) )
                return;

            if (index == 5)
                index = 3;
        }

        var radian = THREE.Math.degToRad( jointDeg);
        var value = this.id.dh_h[index][index] *  radian + this.id.dh_bias[index];
        this.joints[index] = value;

        var axis = new THREE.Matrix4();
        axis.makeRotationAxis(new THREE.Vector3(0, 0, 1), value);

        var frame = new THREE.Matrix4();
        frame.copy(this.frames[index + 1]);
   
        this.links[index + 1].matrix.copy( frame.premultiply(axis));


        if (this.id.type == "Antropomorfo")
        {
            ;
        }
        else if (this.id.type == "Parallelogramma")
        {
            if ((index == 1) || (index == 2))
            {
                var rad1 = this.id.dh_offset[6] + (this.id.dh_gamma[6][1] * this.joints[1] + this.id.dh_gamma[6][2] * this.joints[2]);
                var rad2 = this.id.dh_offset[7] + (this.id.dh_gamma[7][1] * this.joints[1] + this.id.dh_gamma[7][2] * this.joints[2]);
    
                var axis1 = new THREE.Matrix4();
                axis1.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad1);

                var frame7 = this.frames[7].clone();

                var axis2 = new THREE.Matrix4();
                axis2.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad2);

                var frame8 = this.frames[8].clone();

                this.links[7].matrix.copy( frame7.premultiply(axis1) );
                this.links[8].matrix.copy( frame8.premultiply(axis2) );
            }
        }
        else if (this.id.type == "DoppioParallelogramma")
        {
            if ((index == 1) || (index == 2))
            {
                var rad4 = this.id.dh_offset[4] + (this.id.dh_gamma[4][1] * this.joints[1] + this.id.dh_gamma[4][2] * this.joints[2]);
                var rad5 = this.id.dh_offset[5] + (this.id.dh_gamma[5][1] * this.joints[1] + this.id.dh_gamma[5][2] * this.joints[2]);
                var rad6 = this.id.dh_offset[6] + (this.id.dh_gamma[6][1] * this.joints[1] + this.id.dh_gamma[6][2] * this.joints[2]);

                var rad7 = this.id.dh_offset[7] + (this.id.dh_gamma[7][1] * this.joints[1] + this.id.dh_gamma[7][2] * this.joints[2]);
                var rad8 = this.id.dh_offset[8] + (this.id.dh_gamma[8][1] * this.joints[1] + this.id.dh_gamma[8][2] * this.joints[2]);
                var rad9 = this.id.dh_offset[9] + (this.id.dh_gamma[9][1] * this.joints[1] + this.id.dh_gamma[9][2] * this.joints[2]);
                var rad10 = this.id.dh_offset[10] + (this.id.dh_gamma[10][1] * this.joints[1] + this.id.dh_gamma[10][2] * this.joints[2]);

                // Primo parallelogramma
                var axis4 = new THREE.Matrix4();
                axis4.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad4);
                this.links[5].matrix.copy( this.frames[5].clone().premultiply(axis4) );

                var axis5 = new THREE.Matrix4();
                axis5.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad5);
                this.links[6].matrix.copy( this.frames[6].clone().premultiply(axis5) );

                var axis6 = new THREE.Matrix4();
                axis6.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad6);
                this.links[7].matrix.copy( this.frames[7].clone().premultiply(axis6) );

                // Secondo parallelogramma
                var axis7 = new THREE.Matrix4();
                axis7.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad7);
                this.links[8].matrix.copy( this.frames[8].clone().premultiply(axis7) );

                var axis8 = new THREE.Matrix4();
                axis8.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad8);
                this.links[9].matrix.copy( this.frames[9].clone().premultiply(axis8) );

                var axis9 = new THREE.Matrix4();
                axis9.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad9);
                this.links[10].matrix.copy( this.frames[10].clone().premultiply(axis9) );

                var axis10 = new THREE.Matrix4();
                axis10.makeRotationAxis(new THREE.Vector3(0, 0, 1), rad10);
                this.links[11].matrix.copy( this.frames[11].clone().premultiply(axis10) );
            }     
        }

    },

    getToolFrame: function() {
        return this.toolFrame;
    },   

    getUserFrame: function() {
        return this.userFrame;
    },  

    update: function() {

        endtime = new Date()
        var elapsedFast = endtime - this.updateFast; //in ms
        var elapsedSlow = endtime - this.updateSlow; //in ms

        if (elapsedSlow > 2000) {
            this.updateArmBase();
            this.updateSlow = endtime;
        }

        if (elapsedFast > 33) {
            this.updateArmJntp();
            this.updateFast = endtime;
        }

        this.updateBasePose();
        this.updateArmPose();
        this.updateJoints();
    },

    dh(a, alpha, d, theta) {
		var ct, st, ca, sa;
		ct = Math.cos(theta);
		st = Math.sin(theta);
		sa = Math.sin(alpha);
		ca = Math.cos(alpha);

        var m = new THREE.Matrix4();

        m.set(  ct, st, 0, 0,
			    -st * ca, ct*ca, sa, 0,
			    st*sa, -ct * sa, ca, 0,
			    a*ct, a*st, d, 1);

        return m.transpose();
    }

}
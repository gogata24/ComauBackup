var Editor = function(dom, control = false) {

    var container = dom;
    var scene, camera, renderer, labelRenderer, mesh, orbit, world, arm, path, options;
    var frustumSize = 10;


    var cubes = new Map();
    var toolSetPoints = [];
    var toolMonitoringPoints = [];
    var elbowMonitoringPoints = [];
    var kinematicMonitoringPoints = [];
	
    var wallsPlanes = [];
	var wallVisibility = true;

    var wallsPlanesMinZ = 0;
    var wallsPlanesMaxZ = 0;
    var fixWallCornersUpdate = undefined; // TTP bugfix - wrong order update

    init();

    animate();

    onWindowResize();
    
    function init() {			

		THREE.Cache.enabled = false;//TSK-4686
		
        var aspect = container.offsetWidth / container.offsetHeight;
        camera = new THREE.OrthographicCamera( frustumSize * aspect / - 2, frustumSize * aspect / 2, frustumSize / 2, frustumSize / - 2, 1, 2000 );
        camera.position.z = 10;
        camera.position.x = 10;
        camera.position.y = 10;

        scene = new THREE.Scene();
        
		scene.background = new THREE.Color( 0xadedede );
        //scene.fog = new THREE.Fog( 0xa0a0a0, 1, 500 );
        //
        world = new THREE.Group();
        world.type = 'World';
        world.rotation.x = -90 * ( Math.PI / 180 );   
        scene.add(world);

        var worldFrame  = new Frame("", world, 1);

        var hemiLight = new THREE.HemisphereLight( 0x7d7d7d, 0x7d7d7d );
        hemiLight.position.set( 0, 20, 0 );
        scene.add( hemiLight );
            
        var directionalLight = new THREE.DirectionalLight( 0x7d7d7d );
        directionalLight.position.set( 0, 20, 10 );
        directionalLight.castShadow = true;
        directionalLight.shadow.camera.top = 18;
        directionalLight.shadow.camera.bottom = -10;
        directionalLight.shadow.camera.left = - 12;
        directionalLight.shadow.camera.right = 12;			
        scene.add( directionalLight );
        
        // ground
        var grid = new THREE.GridHelper( 20, 20, 0x444444, 0x888888 );
        scene.add( grid );

		if (control) {
			// path
			path = new Path3d();
			scene.add(path.getNode());
		}
            
        labelRenderer = new THREE.CSS2DRenderer();
        labelRenderer.setSize( window.innerWidth, window.innerHeight );
        labelRenderer.domElement.style.position = 'absolute';
        labelRenderer.domElement.style.top = 0;
        container.appendChild( labelRenderer.domElement );

        renderer = new THREE.WebGLRenderer( { antialias: true } );
        renderer.setPixelRatio( window.devicePixelRatio );
        renderer.setSize( window.innerWidth, window.innerHeight );
        renderer.shadowMap.enabled = true;
        container.appendChild( renderer.domElement );
            
        //
        orbit = new THREE.OrbitControls( camera, labelRenderer.domElement );
        //orbit = new THREE.OrbitControls( camera, renderer.domElement );
        //orbit = new THREE.OrbitControls( camera);
        orbit.update();
        orbit.addEventListener( 'change', render );
        orbit.screenSpacePanning = true;
        orbit.minPolarAngle = 0; // radians
        orbit.maxPolarAngle = Math.PI/2; // radians
        
        if (control) {
            var clearfunc = {clear:function(){path.clear();}}
            var gui = new dat.GUI();

            options = {
                Draw: false,
                Clear: function() {
                  path.clearPath()
                }
            };

            var tcpFolder = gui.addFolder('Flange');

            tcpFolder.add(options, 'Draw');
            tcpFolder.add(options, 'Clear'); 
        }
        
        window.addEventListener( 'resize', onWindowResize, false );
		
        onWindowResize();
    }

    function onWindowResize() {
        var aspect = container.offsetWidth / container.offsetHeight;

        camera.left = - frustumSize * aspect / 2;
        camera.right = frustumSize * aspect / 2;
        camera.top = frustumSize / 2;
        camera.bottom = - frustumSize / 2;
        camera.updateProjectionMatrix();
                
        renderer.setSize( container.offsetWidth, container.offsetHeight );
        labelRenderer.setSize( container.offsetWidth, container.offsetHeight );
    }

    function animate() {
        requestAnimationFrame( animate );    
   
		if (arm != undefined) {
            arm.update();
			
			if (control) {
				if (options.Draw) {
					var flangeNode = arm.getFlangeFrame().getNode();
					var m = flangeNode.matrixWorld;
					var position = new THREE.Vector3();
					var rotation = new  THREE.Quaternion();
					var scale = new THREE.Vector3();
					m.decompose ( position, rotation, scale );
					path.addPoint(new THREE.Vector3(position.x, position.y, position.z) );
				}
			}
            
        }

        
        render();			
    }

    function render() {
        renderer.render( scene, camera );	
        labelRenderer.render( scene, camera );			
    }

    function getRenderer() {
        return renderer;
    }

    function fitCameraToObject ( object, offset) {
        offset = offset || 1.25;
        const boundingBox = new THREE.Box3();
        // get bounding box of object - this will be used to setup controls and camera
        boundingBox.setFromObject( object );
        const center = boundingBox.getCenter();
        const size = boundingBox.getSize();
        // get the max side of the bounding box (fits to width OR height as needed )
        const maxDim = Math.max( size.x, size.y, size.z );
        const fov = camera.fov * ( Math.PI / 180 );
        let cameraZ = Math.abs( maxDim / 4 * Math.tan( fov * 2 ) );
        cameraZ *= offset; // zoom out a little so that objects don't fill the screen
        camera.position.z = cameraZ;
        camera.position.x = cameraZ; // iso view
        camera.position.y = cameraZ; // iso view
        const minZ = boundingBox.min.z;
        const cameraToFarEdge = ( minZ < 0 ) ? -minZ + cameraZ : cameraZ - minZ;
        camera.far = cameraToFarEdge * 3;
        camera.updateProjectionMatrix();
        if ( orbit ) {
            // set camera to rotate around center of loaded object
            orbit.target = center;
            // prevent camera from zooming out far enough to create far plane cutoff
            orbit.maxDistance = cameraToFarEdge * 2;
            orbit.update();
            orbit.saveState();
        } else {
            camera.lookAt( center )
        }
    }
         
    function loadRobotModel(folderPath) {
        arm = new ArmModel(folderPath, 1, world);
        
        arm.initContent();
        
        //arm.initContentByName('undefined');

        //arm.initContentByName('RACER_00111');
        //arm.initContentByName('NP_00003'); // PAL Active
        //arm.initContentByName('NP_00002'); // PAL Passive

        //arm.initContentByName('NJ4_00015'); // Polso Cavo

        //arm.initContentByName('NJ3_00001'); // Pirelli
        //arm.initContentByName('NJ3_00101'); // Pirelli eMt

        if (arm.getBaseFrame() != undefined) {
            var armPos = arm.getBaseFrame().getNode().position;
            camera.lookAt(armPos.x, armPos.y, armPos.z);
        }
        
        setInterval(updateCubeStatus, 1000);

        //fitCameraToObject(arm.getBaseFrame().getNode(), 80);
    }

    // Label
    function createLabel(text) {
        var div = document.createElement( 'div' );
        div.className = 'label';
        div.textContent = text;
        div.style.marginTop = '-1em';
        
        var label = new THREE.CSS2DObject( div );

        return label;
    }

    // Cubes Geometry
    function addCube(category, itemJson) {

        var scale = Math.min(itemJson.value.width/1000, itemJson.value.height/1000, itemJson.value.depth/1000);
        scale =  Math.max(scale*0.5, 0.1);
        var frame = new Frame("Cube", world, scale);


        var geometry = new THREE.BoxGeometry( itemJson.value.width/1000, itemJson.value.depth/1000, itemJson.value.height/1000);
        var material = buildTexturedMaterial(itemJson.name, itemJson.color);

        var cube = new THREE.Mesh( geometry, material );

        if ((itemJson.flags.alwaysActive == undefined) || (itemJson.flags.alwaysActive))
            cube.name = "Cube";
        else    
            cube.name = "CubeIN";

        var mat = new THREE.Matrix4(); 

        mat.makeRotationFromEuler ( new THREE.Euler( itemJson.value.roll * Math.PI / 180,
                                                     itemJson.value.pitch  * Math.PI / 180,
                                                     itemJson.value.yaw * Math.PI / 180, 'ZYX' ));
                                                     
        mat.setPosition(new THREE.Vector3(itemJson.value.x/1000, 
                                          itemJson.value.y/1000,
                                          itemJson.value.z/1000));

        frame.getNode().matrixAutoUpdate = false;    
        frame.getNode().matrix.copy(mat);


        var matPivot = new THREE.Matrix4(); 

        matPivot.setPosition(new THREE.Vector3(itemJson.value.width/2000,
                                               itemJson.value.depth/2000,
                                               itemJson.value.height/2000 ));
        cube.matrixAutoUpdate = false;    
        cube.matrix.copy(matPivot);

        if (!itemJson.flags.enabled) {
            frame.getNode().visible = false;
        }
        else {
            frame.getNode().visible = true;
        }

        frame.getNode().add(cube);
        world.add(frame.getNode());

        frame.getNode().name = category;
        cubes.set(category + itemJson.id.toString(), frame.getNode());
    }

    function updateCube(category, itemJson) {
        var cube = cubes.get(category + itemJson.id.toString());
        world.remove(cube);
        cubes.delete(category + itemJson.id.toString());
        addCube(category, itemJson);
    }

    function updateCubeStatus() {
        var req  = new XMLHttpRequest();

        req.open("GET", "get?sysvar=$SL_IN_ABOO", true);
        
        req.onload = function () {
            var json = JSON.parse(req.responseText);
            			
			if (req.status == "200") {
                
                for (var i = 177; i < 188; i++) {
                    var cube = cubes.get(i - 177);
                    if (cube != undefined) {
                        cube.children.forEach(element => {
                            if (element.name == "CubeIN") {
                                var flag = json["SL_IN_ABOO"][i];

                                if (flag)
                                    element.material.opacity = 0.3;
                                else
                                    element.material.opacity = 1;
                            }
                        });
                    }
                }
            }
		}

        req.send();
    }

    function removeCube(category, itemJson) {
        var cube = cubes.get(category + itemJson.id.toString());
        world.remove(cube);
        cubes.delete(category + itemJson.id.toString());
    }

    function showCubes(category) {
        for (var cube of cubes.values()) {
            if (cube.name == category)
                cube.visible = true;
        }
    }

    function hideCubes(category) {
        for (var cube of cubes.values()) {
            if (cube.name == category)
                cube.visible = false;
        }
    }
	
	function showWalls() {
        for (var wall of wallsPlanes) {
			wall.visible = true;
        }
		
		wallVisibility = true;
    }
	
	function hideWalls() {
        for (var wall of wallsPlanes) {
			wall.visible = false;
        }
		
		wallVisibility = false;
    }
	
	function areWallVisible() {
		return wallVisibility
    }
	

    function buildTexturedMaterial(text, backColor) {

        // create a canvas element
        var canvas = document.createElement('canvas');
        var context = canvas.getContext('2d');
        context.font = "40px Arial";

        var textureEdge = context.measureText(text).width;

        canvas.width = textureEdge * 1.5;
        canvas.height = textureEdge * 1.5;
        context = canvas.getContext("2d");
        context.font = "40pt Arial";

        context.textAlign = "center";
        context.textBaseline = "middle";
        context.fillStyle = backColor;
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.fillStyle = 'black';
        context.fillText(text, canvas.width / 2, canvas.height / 2);
        context.lineWidth=5;
        context.beginPath();
        context.moveTo(0,0);
        context.lineTo(canvas.width,0);
        context.lineTo(canvas.width,canvas.height);
        context.lineTo(0,canvas.height);
        context.closePath();
        context.stroke();

        // canvas contents will be used for a texture
        var texture = new THREE.Texture(canvas);
        texture.needsUpdate = true;

        var material = new THREE.MeshBasicMaterial( {map: texture, transparent: true} );

        return material;
    };
    

    // Monitoring Points
    function updateToolsetPoints(groupId, itemsJson, color) {
        
        var filtered = toolSetPoints.filter(function(element){
            if (element.name == groupId.toString()) {
                arm.getFlangeFrame().getNode().remove(element);
                return false;
            }

            return true;
        });

        toolSetPoints = filtered;

        if (itemsJson.length === 2) {
            if (!itemsJson[0].flags.enabled)
                return;
			
			var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });
			
			if (itemsJson[0].value.radius > 0.0) {
				
				var sphereGeom1 = new THREE.SphereGeometry(itemsJson[0].value.radius/1000, 32, 32); 
				var sphereMesh1 = new THREE.Mesh(sphereGeom1, material);
				sphereMesh1.position.set(itemsJson[0].value.x/1000, itemsJson[0].value.y/1000, itemsJson[0].value.z/1000);
				sphereMesh1.name = groupId.toString();

				arm.getFlangeFrame().getNode().add(sphereMesh1);

				toolSetPoints.push(sphereMesh1);
				
				 var label1 = createLabel(groupId.toString() + '.1');
				label1.position.set(itemsJson[0].value.x/1000, itemsJson[0].value.y/1000, itemsJson[0].value.z/1000);
				label1.name = groupId.toString();
				arm.getFlangeFrame().getNode().add(label1);
				toolSetPoints.push(label1);
			}
			
			if (itemsJson[1].value.radius > 0.0) {
				
				var sphereGeom2 = new THREE.SphereGeometry(itemsJson[1].value.radius/1000, 32, 32);
				var sphereMesh2 = new THREE.Mesh(sphereGeom2, material);
				sphereMesh2.position.set(itemsJson[1].value.x/1000, itemsJson[1].value.y/1000, itemsJson[1].value.z/1000);
				sphereMesh2.name = groupId.toString();

				arm.getFlangeFrame().getNode().add(sphereMesh2);

				toolSetPoints.push(sphereMesh2);

				var label2 = createLabel(groupId.toString() + '.2');
				label2.position.set(itemsJson[1].value.x/1000, itemsJson[1].value.y/1000, itemsJson[1].value.z/1000);
				label2.name = groupId.toString();
				arm.getFlangeFrame().getNode().add(label2);
				toolSetPoints.push(label2);
			}
        }
    }

    function createCylinderMesh(pointX, pointY, radius, material) {

        var direction = new THREE.Vector3().subVectors(pointY, pointX);
        var orientation = new THREE.Matrix4();
        orientation.lookAt(pointX, pointY, new THREE.Object3D().up);
        /* rotation around axis X by -90 degrees 
        * matches the default orientation Y 
        * with the orientation of looking Z */
        var rot90 = new THREE.Matrix4();
        rot90.set(1,0,0,0,
            0,0,1,0, 
            0,-1,0,0,
            0,0,0,1);
        orientation.multiply(rot90);            

        if ( direction.length() != 0) {
            var cylinderGeometry = new THREE.CylinderGeometry(radius/1000, radius/1000, direction.length(), 32, 1);
            var cylinderMesh = new THREE.Mesh(cylinderGeometry, material);
            cylinderMesh.applyMatrix(orientation);
            // position based on midpoints - there may be a better solution than this
            cylinderMesh.position.x = (pointY.x + pointX.x) / 2;
            cylinderMesh.position.y = (pointY.y + pointX.y) / 2;
            cylinderMesh.position.z = (pointY.z + pointX.z) / 2;

            return cylinderMesh;
        }

        return undefined;
    }

    function updateToolsetPointsVisibility(groupId, isVisible) {

    } 

    function updateMonitoringPoints(itemsJson, color) {

        toolMonitoringPoints.forEach(element => {
            arm.getFlangeFrame().getNode().remove(element);
        });
        toolMonitoringPoints = [];

        for ( var i = 0; i < itemsJson.length; i++ ) {
            var label = createLabel((itemsJson[i].id + 1).toString());
            label.position.set(itemsJson[i].value.x/1000, itemsJson[i].value.y/1000, itemsJson[i].value.z/1000 );

            toolMonitoringPoints.push(label);
            arm.getFlangeFrame().getNode().add( label );
        }

        var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });

        if (itemsJson.length == 0)
            return;

        var lastElement = {"value":{"x":0, "y":0, "z":0}};

        itemsJson.forEach(element => {
            
            var pointX = new THREE.Vector3(lastElement.value.x/1000, lastElement.value.y/1000, lastElement.value.z/1000);
            var pointY = new THREE.Vector3(element.value.x/1000, element.value.y/1000, element.value.z/1000);
            var radius = element.value.radius;

            var cylinderMesh = createCylinderMesh(pointX, pointY, radius, material);

            if (cylinderMesh != undefined) {
                arm.getFlangeFrame().getNode().add(cylinderMesh);
                toolMonitoringPoints.push(cylinderMesh);
            }

            var sphereGeom;
            var sphereMesh;

            sphereGeom = new THREE.SphereGeometry(element.value.radius/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(lastElement.value.x/1000, lastElement.value.y/1000, lastElement.value.z/1000);
            sphereMesh.name = lastElement.name;

            arm.getFlangeFrame().getNode().add(sphereMesh);
            toolMonitoringPoints.push(sphereMesh);


            sphereGeom = new THREE.SphereGeometry(element.value.radius/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(element.value.x/1000, element.value.y/1000, element.value.z/1000);
            sphereMesh.name = element.name;

            arm.getFlangeFrame().getNode().add(sphereMesh);
            toolMonitoringPoints.push(sphereMesh);

            lastElement = element;
        });
    }

    function updateElbowMonitoringPoints(itemsJson, color) {

        elbowMonitoringPoints.forEach(element => {
            arm.getElbowFrame().getNode().remove(element);
        });
        elbowMonitoringPoints = [];

        var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });

        if (itemsJson.length == 0)
            return;

        var sphereGeom;
        var sphereMesh;
        var cylinderMesh;

        if (itemsJson[0].value.radius1 > 0) {
            sphereGeom = new THREE.SphereGeometry(itemsJson[0].value.radius1/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(0, 0, 0);

            arm.getElbowFrame().getNode().add(sphereMesh);
            elbowMonitoringPoints.push(sphereMesh);

            sphereGeom = new THREE.SphereGeometry(itemsJson[0].value.radius1/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(itemsJson[0].value.x1/1000, itemsJson[0].value.y1/1000, itemsJson[0].value.z1/1000);

            arm.getElbowFrame().getNode().add(sphereMesh);
            elbowMonitoringPoints.push(sphereMesh);

            var pointX = new THREE.Vector3(0, 0, 0);
            var pointY = new THREE.Vector3(itemsJson[0].value.x1/1000, itemsJson[0].value.y1/1000, itemsJson[0].value.z1/1000);
            var radius = itemsJson[0].value.radius1;

            cylinderMesh = createCylinderMesh(pointX, pointY, radius, material);

            if (cylinderMesh != undefined) {

                arm.getElbowFrame().getNode().add(cylinderMesh);
                elbowMonitoringPoints.push(cylinderMesh);
            }

            var label = createLabel("Point A");
            label.position.set(itemsJson[0].value.x1/1000, itemsJson[0].value.y1/1000, itemsJson[0].value.z1/1000 );

            arm.getElbowFrame().getNode().add(label);
            elbowMonitoringPoints.push(label);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////

        if (itemsJson[0].value.radius2 > 0) {
            sphereGeom = new THREE.SphereGeometry(itemsJson[0].value.radius2/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(itemsJson[0].value.x1/1000, itemsJson[0].value.y1/1000, itemsJson[0].value.z1/1000);

            arm.getElbowFrame().getNode().add(sphereMesh);
            elbowMonitoringPoints.push(sphereMesh);

            sphereGeom = new THREE.SphereGeometry(itemsJson[0].value.radius2/1000, 32, 32); 
            sphereMesh = new THREE.Mesh(sphereGeom, material);
            sphereMesh.position.set(itemsJson[0].value.x2/1000, itemsJson[0].value.y2/1000, itemsJson[0].value.z2/1000);
        
            arm.getElbowFrame().getNode().add(sphereMesh);
            elbowMonitoringPoints.push(sphereMesh);

            var pointX = new THREE.Vector3(itemsJson[0].value.x1/1000, itemsJson[0].value.y1/1000, itemsJson[0].value.z1/1000);
            var pointY = new THREE.Vector3(itemsJson[0].value.x2/1000, itemsJson[0].value.y2/1000, itemsJson[0].value.z2/1000);
            var radius = itemsJson[0].value.radius2;

            cylinderMesh = createCylinderMesh(pointX, pointY, radius, material);

            if (cylinderMesh != undefined) {

                arm.getElbowFrame().getNode().add(cylinderMesh);
                elbowMonitoringPoints.push(cylinderMesh);
            }

            var label = createLabel("Point B");
            label.position.set(itemsJson[0].value.x2/1000, itemsJson[0].value.y2/1000, itemsJson[0].value.z2/1000 );

            arm.getElbowFrame().getNode().add(label);
            elbowMonitoringPoints.push(label);
        }
    }

    // Walls
    function updateWallsCorners(itemsJson) {

        wallsPlanes.forEach(element => {
            world.remove(element);
        });
        wallsPlanes = [];

        if ((wallsPlanesMinZ == 0) && (wallsPlanesMaxZ == 0)) {
            fixWallCornersUpdate = itemsJson;
            return;
        }

        var minZ = wallsPlanesMinZ;
        var maxZ = wallsPlanesMaxZ;

        for ( var i = 0; i < itemsJson.length; i++ ) {
            var label = createLabel((itemsJson[i].id + 1).toString());
            label.position.set(itemsJson[i].value.x/1000, itemsJson[i].value.y/1000, 0 );
			
            wallsPlanes.push(label);
            world.add( label );
        }

        if( itemsJson.length > 1 ) {
            
            var wallsGeometry = new THREE.Geometry(); 

            for ( var i = 0; i < itemsJson.length; i++ ) {
				var vdown = new THREE.Vector3(itemsJson[i].value.x/1000, itemsJson[i].value.y/1000, minZ/1000);
                var vup = new THREE.Vector3(itemsJson[i].value.x/1000, itemsJson[i].value.y/1000, maxZ/1000);
                
                wallsGeometry.vertices.push(vdown);
                wallsGeometry.vertices.push(vup);
            }

            var wallsFace;
            for ( var i = 0; i < itemsJson.length - 1; i++ ) {

                wallsFace = new THREE.Face3( i*2, i*2 + 1, i*2 + 2);
                wallsGeometry.faces.push( wallsFace );		
                
                wallsFace = new THREE.Face3( i*2 + 1, i*2 + 3, i*2 + 2);
				wallsGeometry.faces.push( wallsFace );	
            }

            wallsFace = new THREE.Face3( 0, 1, (itemsJson.length - 1)*2);
            wallsGeometry.faces.push( wallsFace );		
            
            wallsFace = new THREE.Face3( 1, (itemsJson.length - 1)*2 + 1, (itemsJson.length - 1)*2);
            wallsGeometry.faces.push( wallsFace );	


            var m = new THREE.MeshStandardMaterial({
                color: 0x000000,
				side: THREE.DoubleSide,
				depthWrite: false,
                flatShading: true,
                transparent: true,
                opacity: 0.4
            });
			//var wallsMesh = new THREE.Mesh( wallsGeometry, m );
			var wallsMesh = new THREE.Mesh( wallsGeometry, new THREE.MeshBasicMaterial( {color: 0x000000, side: THREE.DoubleSide, depthWrite: false, transparent: true, opacity: 0.4} ));
			
			
			if (!wallVisibility)
				wallsMesh.visible = false;
			
            wallsPlanes.push(wallsMesh);
            world.add(wallsMesh);
        }
    }

    function updateWallsCornersZMinMax(zmin, zmax) {
        wallsPlanesMinZ = zmin;
        wallsPlanesMaxZ = zmax;

        if (fixWallCornersUpdate != undefined) {
            updateWallsCorners(fixWallCornersUpdate);
            fixWallCornersUpdate = undefined;
        }
    }

    function updateAxisMonitoringPoints(itemsJson, color) {

        kinematicMonitoringPoints.forEach(element => {
            var index = parseInt(element.name);
            arm.getIrtpLinkR(index).remove(element);
        });

        kinematicMonitoringPoints = [];

        var material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.6 });
        var sphereGeom;
        var sphereMesh;

        var axis = [itemsJson.value.axis1,
                    itemsJson.value.axis2,
                    itemsJson.value.axis3,
                    itemsJson.value.axis4,
                    itemsJson.value.axis5,
                    itemsJson.value.axis6];

        for (var i = 0; i < axis.length; i++ ) {

            if (axis[i] > 0) {
                var irtp = arm.getIrtpLinkR(i + 1);

                if (irtp == undefined)
                    continue;

                sphereGeom = new THREE.SphereGeometry(axis[i]/1000, 32, 32); 
                sphereMesh = new THREE.Mesh(sphereGeom, material);
                sphereMesh.name = (i + 1).toString();

                irtp.add(sphereMesh);

                var label = createLabel((i + 1).toString());
                label.name = (i + 1).toString();
                irtp.add(label);

                kinematicMonitoringPoints.push(label);
                kinematicMonitoringPoints.push(sphereMesh);

                var pointX = new THREE.Vector3(0, 0, 0);
                var pointY = arm.getIrtpBackwardPntExt(i + 1);

                sphereGeom = new THREE.SphereGeometry(axis[i]/1000, 32, 32); 
                sphereMesh = new THREE.Mesh(sphereGeom, material);
                sphereMesh.name = (i + 1).toString();
                irtp.add(sphereMesh);

                sphereMesh.position.set(pointY.x, pointY.y, pointY.z);
                kinematicMonitoringPoints.push(sphereMesh);

                cylinderMesh = createCylinderMesh(pointX, pointY, axis[i], material);

                if (cylinderMesh != undefined) {
                
                    cylinderMesh.name = (i + 1).toString();
                    irtp.add(cylinderMesh);
                    kinematicMonitoringPoints.push(cylinderMesh);
                }
                
            }
        }
    }

    return {onWindowResize,
            getRenderer,
            loadRobotModel, 
            addCube, updateCube, removeCube, showCubes, hideCubes, 
            updateToolsetPoints, updateToolsetPointsVisibility,
            updateMonitoringPoints, 
            updateElbowMonitoringPoints,
            updateWallsCorners, updateWallsCornersZMinMax, showWalls, hideWalls, areWallVisible,
            updateAxisMonitoringPoints};
}

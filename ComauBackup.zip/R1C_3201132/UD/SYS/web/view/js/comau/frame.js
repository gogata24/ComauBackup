var Frame = function (name, node, scale) {
    this.label = name;

    this.arrowHelper = new THREE.Group();
    this.arrowHelper.name = "ArrowHelper";
    
    var arrowX = new THREE.ArrowHelper( new THREE.Vector3( 1, 0, 0 ), new THREE.Vector3( 0, 0, 0 ), scale, 0xff0000, 0.1, 0.06 );
    arrowX.name = "X_Axis";
    this.arrowHelper.add( arrowX );

    var arrowY = new THREE.ArrowHelper( new THREE.Vector3( 0, 1, 0 ), new THREE.Vector3( 0, 0, 0 ), scale, 0x00ff00, 0.1, 0.06 );
    arrowY.name = "Y_Axis";
    this.arrowHelper.add( arrowY );

    var arrowZ = new THREE.ArrowHelper( new THREE.Vector3( 0, 0, 1 ), new THREE.Vector3( 0, 0, 0 ), scale, 0x0000ff, 0.1, 0.06 );
    arrowZ.name = "Z_Axis";
    this.arrowHelper.add( arrowZ );

    this.arrowHelper.matrixAutoUpdate = false;

    node.add( this.arrowHelper );
}

Frame.prototype = {
    getMatrixWorld: function() {
        return this.arrowHelper.matrixWorld;
    },

    getNode: function() {
        return this.arrowHelper;
    }
}
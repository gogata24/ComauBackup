var Path3d = function () {
    this.node = new THREE.Group();

    this.lastPoint = null;
}

Path3d.prototype = {
    addPoint: function(point) {

        if (this.lastPoint == null)
        {
            this.lastPoint = point;
            return;
        }

        if ((point.x == this.lastPoint.x) &&
            (point.y == this.lastPoint.y) &&
            (point.z == this.lastPoint.z))
            return;

        var deltaX = this.lastPoint.x - point.x;
        var deltaY = this.lastPoint.y - point.y;
        var deltaZ = this.lastPoint.z - point.z;

        distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        if (distance < 0.010)
            return;

        var material  = new THREE.LineBasicMaterial();

        material.color = new THREE.Color( 1, 1, 1);

        var geo = new THREE.Geometry();
        geo.vertices.push( this.lastPoint );      
        geo.vertices.push( point );
        var line = new THREE.Line(geo, material); 
        this.node.add(line); 

        this.lastPoint = point;
    },

    clearPath: function() {
        this.node.children = [];
        this.lastPoint = null;
    },

    getNode: function() {
        return this.node;
    }
}